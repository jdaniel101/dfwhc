SELECT     s.name, t.name AS Expr1, i.name AS Expr2, c.name AS Expr3
FROM         sys.tables AS t INNER JOIN
                      sys.schemas AS s ON t.schema_id = s.schema_id INNER JOIN
                      sys.indexes AS i ON i.object_id = t.object_id INNER JOIN
                      sys.index_columns AS ic ON ic.object_id = t.object_id INNER JOIN
                      sys.columns AS c ON c.object_id = t.object_id AND ic.column_id = c.column_id
WHERE     (i.index_id > 0) AND (i.type IN (1, 2)) AND (i.is_primary_key = 0) AND (i.is_unique_constraint = 0) AND (i.is_disabled = 0) AND (i.is_hypothetical = 0) AND 
                      (ic.key_ordinal > 0)
ORDER BY ic.key_ordinal

-----------------------------------------

SELECT     t.name AS TableName, ind.name AS IndexName, ind.index_id AS IndexId, ic.index_column_id AS ColumnId, col.name AS ColumnName, ind.object_id, ind.name, 
                      ind.index_id, ind.type, ind.type_desc, ind.is_unique, ind.data_space_id, ind.ignore_dup_key, ind.is_primary_key, ind.is_unique_constraint, ind.fill_factor, 
                      ind.is_padded, ind.is_disabled, ind.is_hypothetical, ind.allow_row_locks, ind.allow_page_locks, ind.has_filter, ind.filter_definition, ic.object_id AS Expr1, 
                      ic.index_id AS Expr2, ic.index_column_id, ic.column_id, ic.key_ordinal, ic.partition_ordinal, ic.is_descending_key, ic.is_included_column, col.object_id AS Expr3, 
                      col.name AS Expr4, col.column_id AS Expr5, col.system_type_id, col.user_type_id, col.max_length, col.precision, col.scale, col.collation_name, col.is_nullable, 
                      col.is_ansi_padded, col.is_rowguidcol, col.is_identity, col.is_computed, col.is_filestream, col.is_replicated, col.is_non_sql_subscribed, col.is_merge_published, 
                      col.is_dts_replicated, col.is_xml_document, col.xml_collection_id, col.default_object_id, col.rule_object_id, col.is_sparse, col.is_column_set
FROM         sys.indexes AS ind INNER JOIN
                      sys.index_columns AS ic ON ind.object_id = ic.object_id AND ind.index_id = ic.index_id INNER JOIN
                      sys.columns AS col ON ic.object_id = col.object_id AND ic.column_id = col.column_id INNER JOIN
                      sys.tables AS t ON ind.object_id = t.object_id
WHERE     (ind.is_primary_key = 0) AND (ind.is_unique = 0) AND (ind.is_unique_constraint = 0) AND (t.is_ms_shipped = 0)
ORDER BY TableName, IndexName, IndexId, ColumnId
-----------------------------------------------------------------

SELECT OBJECT_SCHEMA_NAME(T.[object_id],DB_ID()) AS [Schema],  
  T.[name] AS [table_name], I.[name] AS [index_name], AC.[name] AS [column_name],  
  I.[type_desc], I.[is_unique], I.[data_space_id], I.[ignore_dup_key], I.[is_primary_key], 
  I.[is_unique_constraint], I.[fill_factor],    I.[is_padded], I.[is_disabled], I.[is_hypothetical], 
  I.[allow_row_locks], I.[allow_page_locks], IC.[is_descending_key], IC.[is_included_column] 
FROM sys.[tables] AS T  
  INNER JOIN sys.[indexes] I ON T.[object_id] = I.[object_id]  
  INNER JOIN sys.[index_columns] IC ON I.[object_id] = IC.[object_id] 
  INNER JOIN sys.[all_columns] AC ON T.[object_id] = AC.[object_id] AND IC.[column_id] = AC.[column_id] 
WHERE T.[is_ms_shipped] = 0 AND I.[type_desc] <> 'HEAP' 
ORDER BY T.[name], I.[index_id], IC.[key_ordinal]