sp_who2
KILL 	136
--KILL 	63
ALTER DATABASE DBBackups SET MULTI_USER

--select 'KILL ', spid
--  from sysprocesses p inner join sysdatabases d on p.dbid = d.dbid
-- where d.name = 'DFWHC_Search_CrawlStore'

SELECT 'kill ' + CONVERT(VARCHAR(100), session_id)
FROM sys.dm_exec_sessions
WHERE database_id = DB_ID('DemoDB')
 AND session_id <> @@spid

select d.dbid, spid, d.name, p.status, login_time, nt_domain, nt_username, loginame
  from sysprocesses p inner join sysdatabases d on p.dbid = d.dbid
  where p.status <> 'sleeping'
 --or d.name = 'DFWHC_Content_SFT'

select d.name,  COUNT(*)
from sysprocesses p inner join sysdatabases d on p.dbid = d.dbid
GROUP BY d.name

--sp_who2 active


select 'ALTER DATABASE '+ name + ' SET SINGLE_USER' from sys.databases WHERE name NOT IN ('master','msdb','tempdb','model','DBBackups')


RESTORE DATABASE DFWHC_SubscriptionSettings WITH RECOVERY


OFFLINE

ALTER DATABASE <dbname> SET OFFLINE WITH ROLLBACK IMMEDIATE