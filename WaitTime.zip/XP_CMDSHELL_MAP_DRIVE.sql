USE MASTER
GO

Use Master
 GO

 EXEC master.dbo.sp_configure 'show advanced options', 1
 RECONFIGURE WITH OVERRIDE
 GO

 EXEC master.dbo.sp_configure 'xp_cmdshell', 1
 RECONFIGURE WITH OVERRIDE
 GO
 
 ----------------------------------------------


EXEC xp_cmdshell 'net use M: /delete'  -- Disconnected Network Drive (M:)

-- Connected Network Drive (M:)
EXEC xp_cmdshell 'net use M: "\\dfwf-share\SQL Backups\WV-SPSQL01" Welcome9999! /USER:DFWHC\Joseph-Johnson /PERSISTENT:yes'

--EXEC XP_CMDSHELL 'DIR *.bak'

-- \\DFWHC-Share\SQL Backups\SQL01Finance

--sp_configure

USE MASTER
GO
SELECT VALUE, VALUE_IN_USE, DESCRIPTION 
FROM SYS.CONFIGURATIONS 
WHERE DESCRIPTION = 'scan for startup stored procedures'
GO

exec sp_procoption 'MapDrive','STARTUP','ON' 

IF OBJECTPROPERTY ( object_id('MapDrive'),'ExecIsStartup') = 1
   PRINT 'MapDrive will be executed at startup.'


SELECT ROUTINE_NAME, OBJECTPROPERTY(OBJECT_ID(ROUTINE_NAME),'ExecIsStartup') as execisstartup
FROM MASTER.INFORMATION_SCHEMA.Routines WHERE ROUTINE_TYPE = 'PROCEDURE' and
OBJECTPROPERTY(OBJECT_ID(ROUTINE_NAME),'ExecIsStartup') = 1
