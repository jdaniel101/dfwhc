RESTORE  DATABASE [IQSC_DataWarehouse] FROM
DISK = '\\Dfwf-share\e$\DFWF\HV10\IQSC_DataWarehouse\HV10$IQSC01\IQSC_DataWarehouse\FULL\HV10$IQSC01_IQSC_DataWarehouse_FULL_20150714_020001_1.bak',
DISK = '\\Dfwf-share\e$\DFWF\HV10\IQSC_DataWarehouse\HV10$IQSC01\IQSC_DataWarehouse\FULL\HV10$IQSC01_IQSC_DataWarehouse_FULL_20150714_020001_2.bak',
DISK = '\\Dfwf-share\e$\DFWF\HV10\IQSC_DataWarehouse\HV10$IQSC01\IQSC_DataWarehouse\FULL\HV10$IQSC01_IQSC_DataWarehouse_FULL_20150714_020001_3.bak',
DISK = '\\Dfwf-share\e$\DFWF\HV10\IQSC_DataWarehouse\HV10$IQSC01\IQSC_DataWarehouse\FULL\HV10$IQSC01_IQSC_DataWarehouse_FULL_20150714_020001_4.bak',
DISK = '\\Dfwf-share\e$\DFWF\HV10\IQSC_DataWarehouse\HV10$IQSC01\IQSC_DataWarehouse\FULL\HV10$IQSC01_IQSC_DataWarehouse_FULL_20150714_020001_5.bak',
DISK = '\\Dfwf-share\e$\DFWF\HV10\IQSC_DataWarehouse\HV10$IQSC01\IQSC_DataWarehouse\FULL\HV10$IQSC01_IQSC_DataWarehouse_FULL_20150714_020001_6.bak',
DISK = '\\Dfwf-share\e$\DFWF\HV10\IQSC_DataWarehouse\HV10$IQSC01\IQSC_DataWarehouse\FULL\HV10$IQSC01_IQSC_DataWarehouse_FULL_20150714_020001_7.bak',
DISK = '\\Dfwf-share\e$\DFWF\HV10\IQSC_DataWarehouse\HV10$IQSC01\IQSC_DataWarehouse\FULL\HV10$IQSC01_IQSC_DataWarehouse_FULL_20150714_020001_8.bak'
WITH 
MOVE 'IQSC_DataWarehouse' TO '\\WV-ICD10TESTSQL\E$\Program Files\Microsoft SQL Server\MSSQL10_50.MSSQLSERVER\MSSQL\Data\IQSC_DataWarehouse.mdf',
MOVE 'IQSC_DataWarehouse_log' TO '\\WV-ICD10TESTSQL\F$\Program Files\Microsoft SQL Server\MSSQL10_50.MSSQLSERVER\MSSQL\Log\IQSC_DataWarehouse_1.ldf',
MOVE 'IQSC_DataWarehouse' TO '\\WV-ICD10TESTSQL\E$\Program Files\Microsoft SQL Server\MSSQL10_50.MSSQLSERVER\MSSQL\Data\IQSC_DataWarehouse_2.ndf',
MOVE 'IQSC_DataWarehouse' TO '\\WV-ICD10TESTSQL\E$\Program Files\Microsoft SQL Server\MSSQL10_50.MSSQLSERVER\MSSQL\Data\IQSC_DataWarehouse_3.ndf',
MOVE 'IQSC_DataWarehouse' TO '\\WV-ICD10TESTSQL\E$\Program Files\Microsoft SQL Server\MSSQL10_50.MSSQLSERVER\MSSQL\Data\IQSC_DataWarehouse_4.ndf',
MOVE 'IQSC_DataWarehouse' TO '\\WV-ICD10TESTSQL\E$\Program Files\Microsoft SQL Server\MSSQL10_50.MSSQLSERVER\MSSQL\Data\IQSC_DataWarehouse_5.ndf',
MOVE 'IQSC_DataWarehouse' TO '\\WV-ICD10TESTSQL\E$\Program Files\Microsoft SQL Server\MSSQL10_50.MSSQLSERVER\MSSQL\Data\IQSC_DataWarehouse_6.ndf',
MOVE 'IQSC_DataWarehouse' TO '\\WV-ICD10TESTSQL\E$\Program Files\Microsoft SQL Server\MSSQL10_50.MSSQLSERVER\MSSQL\Data\IQSC_DataWarehouse_7.ndf',
MOVE 'IQSC_DataWarehouse' TO '\\WV-ICD10TESTSQL\E$\Program Files\Microsoft SQL Server\MSSQL10_50.MSSQLSERVER\MSSQL\Data\IQSC_DataWarehouse_8.ndf'
GO

