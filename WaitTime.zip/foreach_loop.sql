EXECUTE master.sys.sp_MSforeachdb 'USE [?]; EXEC sp_spaceused'

EXECUTE master.sys.sp_MSforeachdb 'USE [?]; EXEC sp_helpfile'

exec sp_MSForEachdb 'SELECT ''?'' as DBName, ?.dbo.sysobjects.name AS TableName from ?.dbo.sysobjects WHERE  ?.dbo.sysobjects.xtype=''U'''

------------------------------------

create table dbindex(dbname varchar(20),
tblname varchar(130),idxname varchar(130))

EXECUTE master.sys.sp_MSforeachdb 'USE [?]; INSERT INTO master.dbo.dbindex select ''?'', t.name, i.name from 
sys.tables t INNER JOIN sys.indexes i on t.object_id = i.object_id'

------------------------------------

select COUNT(*) from sys.tables -- (Max # of index is 3160; averaging 10 indexes per table)

select COUNT(*) FROM sys.indexes --(# of index we have is 469)

DECLARE @SQL NVARCHAR(MAX)
SELECT @SQL = STUFF((
	SELECT CHAR(13) + 'UNION ALL' + CHAR(13) +
'select ''?'', t.name, i.name from 
sys.tables t INNER JOIN sys.indexes i on t.object_id = i.object_id'
FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 11, '')

PRINT @SQL


DECLARE @SQL NVARCHAR(MAX)
SELECT @SQL = STUFF((
    SELECT CHAR(13) + 'UNION ALL' + CHAR(13) + 'select d.name, t.name, i.name  FROM   
    sys.tables t INNER JOIN  
    sys.indexes i ON t.OBJECT_ID = i.object_id'
FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 11, '')

PRINT @SQL


DECLARE @SQL NVARCHAR(MAX)
SELECT @SQL = STUFF((
    SELECT CHAR(13) + 'UNION ALL' + CHAR(13) + 'USE SELECT * FROM [' + s.name + '].[' + o.name + ']'
    FROM sys.objects o 
    JOIN sys.schemas s ON o.[schema_id] = s.[schema_id]
    WHERE o.[type] = 'U'
    FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 11, '')

PRINT @SQL

--------------------------

