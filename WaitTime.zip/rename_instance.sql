sp_helpserver 
select @@servername 

--Execute the below query to change the instance name
sp_dropserver 'JD_DB' 
go 
sp_addserver 'JDDB' , 'local' 
go


--RESTART SQL SEVER

--Verify sql server instance configuration by running below queries
sp_helpserver
select @@servername 