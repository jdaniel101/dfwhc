USE THCIC_DW
GO

-- Verify Count from User Manual PDF
select COUNT(*) from PUDF_base1_IPworking
select COUNT(*) from PUDF_base2_IPworking
select COUNT(*) from PUDF_charges_IPworking
select COUNT(*) from Facility_type_IPworking

-- Verify Count from Data Dictionary PDF 
select COUNT(*) from OP_PUDF_base_Working
select COUNT(*) from OP_Classification_working
select COUNT(*) from OP_Facility_type_working
select COUNT(*) from OP_PUDF_charges_working

-----------------------------------------------------

DECLARE @DschrgQtrStart VARCHAR(6)
DECLARE @DschrgQtrEnd VARCHAR(6)

SET @DschrgQtrStart = '2014Q3' 
SET @DschrgQtrEnd	= '2014Q3'


SELECT a.PtType, a.HospID, a.DschrgQtr, a.Hospital_Key, a.HospitalShortName Hospital
, a.THCIC_Cnt, a.IQSC_Cnt, CASE WHEN a.THCIC_Cnt <> a.IQSC_Cnt THEN 'Mismatch' ELSE '' END as Result, (1-(CAST(a.THCIC_Cnt as decimal)/CAST(a.IQSC_Cnt as decimal))) as StdDiv
FROM (
	SELECT c.PtType, c.HospID, c.DschrgQtr, b.Hospital_Key,b.HospitalShortName, c.THCIC_Cnt, b.IQSC_Cnt
	FROM (
			SELECT t.PtType, t.HospID,
				t.Hospital,
				t.DschrgQtr, Sum(t.CaseCnt) THCIC_Cnt
			FROM THCIC.dbo.QV_LOAD_THCIC t
			WHERE t.DschrgQtr BETWEEN @DschrgQtrStart
					AND @DschrgQtrEnd
			GROUP BY t.DschrgQtr, t.PtType, t.HospID,
				t.Hospital
		) c
	LEFT JOIN (
		SELECT a.PtType, a.HospID, a.DschrgQtr, a.Hospital_Key,a.HospitalShortName, COUNT(a.Claim_Key) AS IQSC_Cnt
		FROM (
			SELECT dc.DischargeDate, ddt.[Quarter] AS DschrgQtr, dc.Claim_Key, dc.SubmissionPurpose AS PtType, dc.Hospital_Key,  dh.HospitalShortName, dh.t_THCIC_Hospital_ID AS HospID
			FROM IQSC_DataWarehouse.dbo.DimClaim dc
			LEFT JOIN IQSC_DataWarehouse.dbo.DimDate AS ddt ON ddt.DateValue = dc.DischargeDate
			LEFT JOIN IQSC_DataWarehouse.dbo.DimHospital AS dh ON dh.Hospital_Key = dc.Hospital_Key
			WHERE dc.DischargeQuarter BETWEEN REPLACE(@DschrgQtrStart,'Q','0')
					AND REPLACE(@DschrgQtrEnd,'Q','0')
				AND dc.ClaimStatusCode NOT IN ('V', 'X')
			) a
		GROUP BY a.PtType, a.HospID, a.DschrgQtr, a.Hospital_Key, a.HospitalShortName
		) b ON b.DschrgQtr = c.DschrgQtr
		AND b.PtType = c.PtType
		AND b.HospID = c.HospID
	WHERE b.IQSC_Cnt IS NOT NULL
	) a
WHERE PtType = 'I'