
WHILE EXISTS (SELECT COUNT(*) FROM OP_Classification_working GROUP BY RECORD_ID HAVING COUNT(*) > 1)
BEGIN
    DELETE FROM OP_Classification_working WHERE RECORD_ID IN 
    (
        SELECT MIN(RECORD_ID) as [DeleteID]
        FROM OP_Classification_working
        GROUP BY RECORD_ID
        HAVING COUNT(*) > 1
    )
END

