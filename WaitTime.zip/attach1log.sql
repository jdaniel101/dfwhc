
CREATE DATABASE DFWHC_Content_SFT
ON (FILENAME=N'D:\SQLDATA\DFWHC_Content_SFT.mdf')
--,(FILENAME=N'E:\SQLLOGS\DFWHC_Content_SFT_log.ldf')
FOR ATTACH_REBUILD_LOG;


EXEC sp_attach_single_file_db @dbname = 'DFWHC_Content_SFT', 
@physname = N'D:\SQLDATA\DFWHC_Content_SFT.mdf';

--DFWHC_Config_2013_log
--DFWHC_Content_SFT_log
--DFWHC_Search_log
--DFWHC_SecureStore_log

--EXEC sp_detach_db 'DFWHC_Config_2013'

ALTER DATABASE DFWHC_SessionState SET EMERGENCY;
ALTER DATABASE DFWHC_SessionState SET SINGLE_USER;

DBCC CHECKDB (DFWHC_SessionState, REPAIR_ALLOW_DATA_LOSS) WITH NO_INFOMSGS, ALL_ERRORMSGS;

ALTER DATABASE DFWHC_SessionState SET MULTI_USER;

ALTER DATABASE DFWHC_SessionState SET ONLINE;
