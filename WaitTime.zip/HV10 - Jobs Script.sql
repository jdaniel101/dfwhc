USE [msdb]
GO

/****** Object:  Job [_tmpqedit load]    Script Date: 12/31/2015 08:46:41 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'_tmpqedit load')
EXEC msdb.dbo.sp_delete_job @job_id=N'fe9ee191-81ec-4a72-93c6-d20e41865c22', @delete_unused_schedule=1
GO

/****** Object:  Job [5_DW_Quadramed_Refresh]    Script Date: 12/31/2015 08:46:41 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'5_DW_Quadramed_Refresh')
EXEC msdb.dbo.sp_delete_job @job_id=N'bf89958d-fbbe-4405-bf09-385216e6f41c', @delete_unused_schedule=1
GO

/****** Object:  Job [AHRQ DI Processing Onetime]    Script Date: 12/31/2015 08:46:41 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'AHRQ DI Processing Onetime')
EXEC msdb.dbo.sp_delete_job @job_id=N'fc40a4e5-e0c4-4a60-b37a-f78d7afd6681', @delete_unused_schedule=1
GO

/****** Object:  Job [AHRQ Processing]    Script Date: 12/31/2015 08:46:41 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'AHRQ Processing')
EXEC msdb.dbo.sp_delete_job @job_id=N'8e00b54d-61f3-43d9-8162-f598cb1cd12d', @delete_unused_schedule=1
GO

/****** Object:  Job [BackupAllDB]    Script Date: 12/31/2015 08:46:41 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'BackupAllDB')
EXEC msdb.dbo.sp_delete_job @job_id=N'1a7780e0-cb9a-479a-90e1-7fa529bd54ac', @delete_unused_schedule=1
GO

/****** Object:  Job [Blind_HIV]    Script Date: 12/31/2015 08:46:41 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Blind_HIV')
EXEC msdb.dbo.sp_delete_job @job_id=N'74aa7c2e-ee2f-4004-ba36-491ec116ddb4', @delete_unused_schedule=1
GO

/****** Object:  Job [BlindQuarter]    Script Date: 12/31/2015 08:46:41 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'BlindQuarter')
EXEC msdb.dbo.sp_delete_job @job_id=N'344dac74-6bde-4f66-ba41-b3f09e01654c', @delete_unused_schedule=1
GO

/****** Object:  Job [Claim_processing_JobHistory]    Script Date: 12/31/2015 08:46:41 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Claim_processing_JobHistory')
EXEC msdb.dbo.sp_delete_job @job_id=N'1a658e26-52b7-4c19-9d20-d8097240a2d9', @delete_unused_schedule=1
GO

/****** Object:  Job [CommandLog Cleanup]    Script Date: 12/31/2015 08:46:41 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'CommandLog Cleanup')
EXEC msdb.dbo.sp_delete_job @job_id=N'da103af8-b74f-48e2-a08c-2fe10a5bff63', @delete_unused_schedule=1
GO

/****** Object:  Job [copy]    Script Date: 12/31/2015 08:46:41 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'copy')
EXEC msdb.dbo.sp_delete_job @job_id=N'c739812d-9ca9-4e89-a1d8-4b38384b9b61', @delete_unused_schedule=1
GO

/****** Object:  Job [create index]    Script Date: 12/31/2015 08:46:41 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'create index')
EXEC msdb.dbo.sp_delete_job @job_id=N'de7f67bd-3b17-433d-bee7-0ecc3f605f02', @delete_unused_schedule=1
GO

/****** Object:  Job [DashBoard Load]    Script Date: 12/31/2015 08:46:41 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DashBoard Load')
EXEC msdb.dbo.sp_delete_job @job_id=N'20ec7c19-177c-47db-be54-f30fe047d617', @delete_unused_schedule=1
GO

/****** Object:  Job [DB_SpaceUseed]    Script Date: 12/31/2015 08:46:41 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DB_SpaceUseed')
EXEC msdb.dbo.sp_delete_job @job_id=N'd422efc4-b613-4dec-b8bf-1bdfa971af24', @delete_unused_schedule=1
GO

/****** Object:  Job [DBCC DFWHC_Staging]    Script Date: 12/31/2015 08:46:41 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DBCC DFWHC_Staging')
EXEC msdb.dbo.sp_delete_job @job_id=N'23a01144-2530-429f-99aa-89923af95d0e', @delete_unused_schedule=1
GO

/****** Object:  Job [DBCC INDEXDEFRAG]    Script Date: 12/31/2015 08:46:41 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DBCC INDEXDEFRAG')
EXEC msdb.dbo.sp_delete_job @job_id=N'e11bce87-4984-41b3-8338-5d71c2924660', @delete_unused_schedule=1
GO

/****** Object:  Job [DBCC IQSC_Datawarehouse]    Script Date: 12/31/2015 08:46:41 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DBCC IQSC_Datawarehouse')
EXEC msdb.dbo.sp_delete_job @job_id=N'9b12bddd-deab-405b-9a70-a510091dedb7', @delete_unused_schedule=1
GO

/****** Object:  Job [DBCC QEdit_Staging]    Script Date: 12/31/2015 08:46:41 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DBCC QEdit_Staging')
EXEC msdb.dbo.sp_delete_job @job_id=N'26ba0062-3124-4632-be7d-1a97ab8f9d08', @delete_unused_schedule=1
GO

/****** Object:  Job [DBCC Shrink]    Script Date: 12/31/2015 08:46:41 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DBCC Shrink')
EXEC msdb.dbo.sp_delete_job @job_id=N'5458467a-218a-4676-a45d-44819dbbf598', @delete_unused_schedule=1
GO

/****** Object:  Job [DRG_Test Run]    Script Date: 12/31/2015 08:46:41 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DRG_Test Run')
EXEC msdb.dbo.sp_delete_job @job_id=N'd4ce9eb4-f633-4296-8eaa-85aacb6de187', @delete_unused_schedule=1
GO

/****** Object:  Job [FactClaims]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'FactClaims')
EXEC msdb.dbo.sp_delete_job @job_id=N'64d4cfac-5c01-4aa6-aba4-2af8a8bc5a25', @delete_unused_schedule=1
GO

/****** Object:  Job [Hospitals load from Data_Submission]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Hospitals load from Data_Submission')
EXEC msdb.dbo.sp_delete_job @job_id=N'2d5197f0-87c8-41aa-a4ae-a82a3dda2267', @delete_unused_schedule=1
GO

/****** Object:  Job [IQSC_Warehouse backup]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'IQSC_Warehouse backup')
EXEC msdb.dbo.sp_delete_job @job_id=N'd3b447c7-76b6-467d-92da-b1cdaae92251', @delete_unused_schedule=1
GO

/****** Object:  Job [JointPUDFTesting]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'JointPUDFTesting')
EXEC msdb.dbo.sp_delete_job @job_id=N'6f528859-c973-44d9-ac10-70b9229fc821', @delete_unused_schedule=1
GO

/****** Object:  Job [Load Diags Procs and ECodes from View to Table]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Load Diags Procs and ECodes from View to Table')
EXEC msdb.dbo.sp_delete_job @job_id=N'a8b5a481-dd6f-46fa-b931-47efc78cef68', @delete_unused_schedule=1
GO

/****** Object:  Job [Load_QV_LOAD_THCIC]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Load_QV_LOAD_THCIC')
EXEC msdb.dbo.sp_delete_job @job_id=N'e8edff6e-64ef-4117-96bc-3cf5b7d182de', @delete_unused_schedule=1
GO

/****** Object:  Job [Nightly Claim Processing]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Nightly Claim Processing')
EXEC msdb.dbo.sp_delete_job @job_id=N'5d76617d-e55a-48de-a07a-3e1d4c655194', @delete_unused_schedule=1
GO

/****** Object:  Job [Notloadedfiles]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Notloadedfiles')
EXEC msdb.dbo.sp_delete_job @job_id=N'de566859-c5e0-44d5-a7cd-97f45273a34b', @delete_unused_schedule=1
GO

/****** Object:  Job [Output File Cleanup]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Output File Cleanup')
EXEC msdb.dbo.sp_delete_job @job_id=N'374e2901-41bd-41b1-8b23-c23315399f55', @delete_unused_schedule=1
GO

/****** Object:  Job [Patientdata]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Patientdata')
EXEC msdb.dbo.sp_delete_job @job_id=N'2d2dd46c-5f45-41a1-8486-88e939526ec9', @delete_unused_schedule=1
GO

/****** Object:  Job [PLE update]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'PLE update')
EXEC msdb.dbo.sp_delete_job @job_id=N'd699361e-2274-4fa9-9515-fd1d778454dc', @delete_unused_schedule=1
GO

/****** Object:  Job [pudf load]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'pudf load')
EXEC msdb.dbo.sp_delete_job @job_id=N'd3973083-0900-449c-b3a3-239b9640ece7', @delete_unused_schedule=1
GO

/****** Object:  Job [QEdit Staging Load]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'QEdit Staging Load')
EXEC msdb.dbo.sp_delete_job @job_id=N'a75c6cc4-08a8-4377-9943-4f171a0baa77', @delete_unused_schedule=1
GO

/****** Object:  Job [Qedit Temp]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Qedit Temp')
EXEC msdb.dbo.sp_delete_job @job_id=N'45d3e4b6-2122-4bc7-8b19-d8ea4db21a83', @delete_unused_schedule=1
GO

/****** Object:  Job [QlikVIew LOAd]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'QlikVIew LOAd')
EXEC msdb.dbo.sp_delete_job @job_id=N'3b5e8ee9-96ce-436c-a90d-95cbe3cbaea0', @delete_unused_schedule=1
GO

/****** Object:  Job [QlikVIew LOAd Monthly]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'QlikVIew LOAd Monthly')
EXEC msdb.dbo.sp_delete_job @job_id=N'ba0ffbe9-1b7c-4206-b0e1-6e882b1a7761', @delete_unused_schedule=1
GO

/****** Object:  Job [Quadramed Full Load]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Quadramed Full Load')
EXEC msdb.dbo.sp_delete_job @job_id=N'5ec470d6-72c0-4d1a-8c64-0ae249310840', @delete_unused_schedule=1
GO

/****** Object:  Job [QuadramedRefresh]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'QuadramedRefresh')
EXEC msdb.dbo.sp_delete_job @job_id=N'2d80d74f-fbde-47ed-9b1c-bd839e8038e0', @delete_unused_schedule=1
GO

/****** Object:  Job [ReIndex.Subplan_1]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'ReIndex.Subplan_1')
EXEC msdb.dbo.sp_delete_job @job_id=N'6bada83a-05f1-405e-88d0-42ac47a41cf7', @delete_unused_schedule=1
GO

/****** Object:  Job [Rev_Fix]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Rev_Fix')
EXEC msdb.dbo.sp_delete_job @job_id=N'1a8d7383-0479-4ee8-a84f-834ce559f846', @delete_unused_schedule=1
GO

/****** Object:  Job [SAS_PUDF Table Load]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'SAS_PUDF Table Load')
EXEC msdb.dbo.sp_delete_job @job_id=N'29c886f4-1fc8-48fe-8a01-860f3533774e', @delete_unused_schedule=1
GO

/****** Object:  Job [sp_delete_backuphistory]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'sp_delete_backuphistory')
EXEC msdb.dbo.sp_delete_job @job_id=N'2e8e8cce-394b-4525-9873-13e0ece3a1c2', @delete_unused_schedule=1
GO

/****** Object:  Job [sp_purge_jobhistory]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'sp_purge_jobhistory')
EXEC msdb.dbo.sp_delete_job @job_id=N'2448858e-34b8-40e6-b617-06d69131eab8', @delete_unused_schedule=1
GO

/****** Object:  Job [Staging]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Staging')
EXEC msdb.dbo.sp_delete_job @job_id=N'61d83cfe-280b-4178-9887-21d4b07b4cd3', @delete_unused_schedule=1
GO

/****** Object:  Job [syspolicy_purge_history]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'syspolicy_purge_history')
EXEC msdb.dbo.sp_delete_job @job_id=N'33535c54-0b8c-495d-aaf0-f3187d9c917b', @delete_unused_schedule=1
GO

/****** Object:  Job [SystemDatabasesBackup.Subplan_1]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'SystemDatabasesBackup.Subplan_1')
EXEC msdb.dbo.sp_delete_job @job_id=N'789eaa4d-7c75-4bcf-928f-32a1a86acef0', @delete_unused_schedule=1
GO

/****** Object:  Job [Test]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Test')
EXEC msdb.dbo.sp_delete_job @job_id=N'f7942b92-0bb7-4461-bed0-c9e82fda8d71', @delete_unused_schedule=1
GO

/****** Object:  Job [THCIC]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'THCIC')
EXEC msdb.dbo.sp_delete_job @job_id=N'b999c6ea-cc60-4754-927d-7c18353004e4', @delete_unused_schedule=1
GO

/****** Object:  Job [THCIC PUDF Load]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'THCIC PUDF Load')
EXEC msdb.dbo.sp_delete_job @job_id=N'bff341fd-8f64-4354-8be9-070b9d1cb9b6', @delete_unused_schedule=1
GO

/****** Object:  Job [THCIC_DW]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'THCIC_DW')
EXEC msdb.dbo.sp_delete_job @job_id=N'c7a508ab-4a77-4474-b4ee-374f99e1521f', @delete_unused_schedule=1
GO

/****** Object:  Job [THCIC_pudf]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'THCIC_pudf')
EXEC msdb.dbo.sp_delete_job @job_id=N'caccf58e-092e-46d0-af63-25b1ecf35186', @delete_unused_schedule=1
GO

/****** Object:  Job [THCIC_Scripts]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'THCIC_Scripts')
EXEC msdb.dbo.sp_delete_job @job_id=N'cce3f192-8fb9-482c-8089-6f50b848584c', @delete_unused_schedule=1
GO

/****** Object:  Job [Update HCPCS]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Update HCPCS')
EXEC msdb.dbo.sp_delete_job @job_id=N'688564a8-7494-48cd-bcdf-e9b4dc0469cb', @delete_unused_schedule=1
GO

/****** Object:  Job [Update_DCP]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'Update_DCP')
EXEC msdb.dbo.sp_delete_job @job_id=N'f5f78cbb-c5ad-4ecb-8a7d-48b5959318fc', @delete_unused_schedule=1
GO

/****** Object:  Job [UpdateStats.Subplan_1]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'UpdateStats.Subplan_1')
EXEC msdb.dbo.sp_delete_job @job_id=N'a19b3e0f-faa5-4dea-bfba-e1c9103e1c9e', @delete_unused_schedule=1
GO

/****** Object:  Job [UserBackup.Subplan_1]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'UserBackup.Subplan_1')
EXEC msdb.dbo.sp_delete_job @job_id=N'170106a3-1674-4dd3-932d-0e80032d6af8', @delete_unused_schedule=1
GO

/****** Object:  Job [usp_claimids_batch_tmp load]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'usp_claimids_batch_tmp load')
EXEC msdb.dbo.sp_delete_job @job_id=N'3fce5b77-5374-4319-9b5b-53bc97a937b8', @delete_unused_schedule=1
GO

/****** Object:  Job [xx]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'xx')
EXEC msdb.dbo.sp_delete_job @job_id=N'f495716c-5fcd-45c1-8fe6-5a57ad473268', @delete_unused_schedule=1
GO

/****** Object:  Job [xxx]    Script Date: 12/31/2015 08:46:42 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'xxx')
EXEC msdb.dbo.sp_delete_job @job_id=N'f2d2038b-05ab-4b46-9ea8-b4c825204086', @delete_unused_schedule=1
GO

USE [msdb]
GO

/****** Object:  Job [_tmpqedit load]    Script Date: 12/31/2015 08:46:42 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:42 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'_tmpqedit load', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\pyalavarthy', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [_tmpqedit load]    Script Date: 12/31/2015 08:46:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'_tmpqedit load', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\MissedFiles" /SERVER hv10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [5_DW_Quadramed_Refresh]    Script Date: 12/31/2015 08:46:42 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:42 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'5_DW_Quadramed_Refresh', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Get 200k]    Script Date: 12/31/2015 08:46:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Get 200k', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=2, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'insert INTO DimMRN
select TOP 200000 claim_key,0,getdate()
from dimclaim where Claim_Key not in (select Claim_Key from DimMRN)
and claim_key > 129874953
and Claim_Key not in (select Claim_Key from worktables..DimMRN)', 
		@database_name=N'IQSC_DataWarehouse', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Quadramed file]    Script Date: 12/31/2015 08:46:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Quadramed file', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=3, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\4_DW_Quadramed_File_Processing_old" /SERVER HV10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Refresh]    Script Date: 12/31/2015 08:46:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Refresh', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=4, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\5_DW_Quadramed_Refresh" /SERVER HV10 /X86  /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update Flag]    Script Date: 12/31/2015 08:46:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update Flag', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'UPDATE A
SET Quadramed_sent = 1
FROM DimMRN A JOIN DIMCLAIM Q
ON A.CLAIM_KEY = Q.CLAIM_KEY
and Quadramed_sent = 0', 
		@database_name=N'IQSC_DataWarehouse', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'quadramed', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=8, 
		@freq_subday_interval=11, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20130913, 
		@active_end_date=99991231, 
		@active_start_time=50000, 
		@active_end_time=230059, 
		@schedule_uid=N'12a3b931-07ab-40ae-a46a-7ce2eaf5fb76'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [AHRQ DI Processing Onetime]    Script Date: 12/31/2015 08:46:42 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:42 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'AHRQ DI Processing Onetime', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\DATAINITSQLAGENT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [AHRQ DI Files]    Script Date: 12/31/2015 08:46:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'AHRQ DI Files', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\12_DW_AHRQ_DI_File_Loader" /SERVER hv10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update AHRQ Hospital Keys]    Script Date: 12/31/2015 08:46:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update AHRQ Hospital Keys', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec usp_UpdateAHRQHospital', 
		@database_name=N'IQSC_DataWarehouse', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [AHRQ Processing]    Script Date: 12/31/2015 08:46:42 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:42 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'AHRQ Processing', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\DATAINITSQLAGENT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [AHRQ DI Files]    Script Date: 12/31/2015 08:46:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'AHRQ DI Files', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=3, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\12_DW_AHRQ_DI_File_Loader" /SERVER hv10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [AHRQ THCIC Files]    Script Date: 12/31/2015 08:46:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'AHRQ THCIC Files', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\12_DW_AHRQ_THCIC_File_Loader" /SERVER hv10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update AHRQ Hospital Keys]    Script Date: 12/31/2015 08:46:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update AHRQ Hospital Keys', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec usp_UpdateAHRQHospital', 
		@database_name=N'IQSC_DataWarehouse', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [AHRQ THCIC Views to Tables Load]    Script Date: 12/31/2015 08:46:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'AHRQ THCIC Views to Tables Load', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\msdb\12_DW_AHRQ_THCIC_ViewToTable" /SERVER hv10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'AHRQ Test', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=4, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20111107, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'9313b30f-9118-4973-9bc0-776e412df592'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [BackupAllDB]    Script Date: 12/31/2015 08:46:42 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:42 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'BackupAllDB', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\jdaniel', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [BackupAllDB]    Script Date: 12/31/2015 08:46:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'BackupAllDB', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @name VARCHAR(50) -- database name  
DECLARE @path VARCHAR(256) -- path for backup files  
DECLARE @fileName VARCHAR(256) -- filename for backup  
DECLARE @fileDate VARCHAR(20) -- used for file name 

SET @path = ''\\Dfwf-share\DFWF\HV10\IQSC_DataWarehouse\''  

SELECT @fileDate = CONVERT(VARCHAR(20),GETDATE(),112) 

DECLARE db_cursor CURSOR FOR  
SELECT name 
FROM master.dbo.sysdatabases 
WHERE name NOT IN (''master'',''model'',''msdb'',''tempdb'',''IQSC_DataWarehouse'',''Data_Submission'')  

OPEN db_cursor   
FETCH NEXT FROM db_cursor INTO @name   

WHILE @@FETCH_STATUS = 0   
BEGIN   
       EXECUTE dbo.DatabaseBackup
			@Databases = @name,
			@Directory = @path,
			@BackupType = ''FULL'',
			@Compress = ''Y'',
			@CheckSum = ''Y'',
			@BufferCount = 50,
			@MaxTransferSize = 4194304,
			@NumberOfFiles = 8,
			@CleanupTime =72
			
       FETCH NEXT FROM db_cursor INTO @name   
END   

CLOSE db_cursor   
DEALLOCATE db_cursor', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'BackupAllDB_1', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20150729, 
		@active_end_date=99991231, 
		@active_start_time=20000, 
		@active_end_time=235959, 
		@schedule_uid=N'5c6ef8a3-aeb1-4f7e-8bcd-5e412cdfdf3c'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Blind_HIV]    Script Date: 12/31/2015 08:46:42 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:42 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Blind_HIV', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\DATAINITSQLAGENT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Blind_Hiv]    Script Date: 12/31/2015 08:46:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Blind_Hiv', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec dbo.Blind_HIV', 
		@database_name=N'IQSC_DataWarehouse', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Blind_Hiv', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=127, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20131219, 
		@active_end_date=99991231, 
		@active_start_time=40000, 
		@active_end_time=235959, 
		@schedule_uid=N'8196196d-49d0-4def-aa38-7913870e24a4'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [BlindQuarter]    Script Date: 12/31/2015 08:46:42 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:42 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'BlindQuarter', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\DATAINITSQLAGENT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [BlindQuarter]    Script Date: 12/31/2015 08:46:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'BlindQuarter', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC dbo.usp_CreateBlindedQuarter 201203
EXEC dbo.usp_CreateBlindedQuarter 201202
EXEC dbo.usp_CreateBlindedQuarter 201201', 
		@database_name=N'IQSC_DataWarehouse', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'BlindQuarter', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20121106, 
		@active_end_date=99991231, 
		@active_start_time=60000, 
		@active_end_time=235959, 
		@schedule_uid=N'76b25f4f-4e8b-4f8b-b2ad-9be395ee589c'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Claim_processing_JobHistory]    Script Date: 12/31/2015 08:46:42 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:42 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Claim_processing_JobHistory', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\DATAINITSQLAGENT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Claim_processing_JobHistory]    Script Date: 12/31/2015 08:46:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Claim_processing_JobHistory', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'insert into [IQSC_DataWarehouse].[dbo].[Claim_processing_JobHistory]
SELECT    sysjobs.name  AS   job_name,
             CASE sysjobhistory.run_status
               WHEN 0 THEN ''Failed''
               WHEN 1 THEN ''Succeeded''
               ELSE ''???''
             END AS run_status,
             CAST(
             Isnull(Substring(CONVERT(VARCHAR(8), run_date), 1, 4) + ''-'' +
                           Substring(CONVERT(VARCHAR
                                     (8), run_date), 5, 2) + ''-'' +
                    Substring(CONVERT(VARCHAR(
                              8), run_date), 7, 2), '''') AS DATETIME)
             AS
             [Run DATE],

             Isnull(Substring(CONVERT(VARCHAR(7), run_time+1000000), 2, 2) + '':''
                     +
                           Substring(CONVERT(VARCHAR(7), run_time+1000000), 4, 2
                            )
                    +
                    '':'' +
                    Substring(CONVERT(VARCHAR(7), run_time+1000000), 6, 2), '''') 
             AS
             [Run TIME],
             Isnull(Substring(CONVERT(VARCHAR(7), run_duration+1000000), 2, 2) +
                     '':'' +
                           Substring(CONVERT(VARCHAR(7), run_duration+1000000),
                           4,
                           2)
                    + '':'' +
                    Substring(CONVERT(VARCHAR(7), run_duration+1000000), 6, 2),
             ''''
             ) AS
             [Duration],
             Isnull(Substring(CONVERT(VARCHAR(7), run_time+run_duration+1000000), 2, 2) + '':''
                     +
                           Substring(CONVERT(VARCHAR(7), run_time+run_duration+1000000), 4, 2
                            )
                    +
                    '':'' +
                    Substring(CONVERT(VARCHAR(7), run_time+run_duration+1000000), 6, 2), '''')
             AS
             [Total TIME],             
             sysjobhistory.step_id,
             sysjobhistory.step_name,
             sysjobhistory.MESSAGE AS Msg,
             run_date
            -- into Claim_processing_JobHistory
      FROM   msdb.dbo.sysjobhistory
             INNER JOIN msdb.dbo.sysjobs
               ON msdb.dbo.sysjobhistory.job_id = msdb.dbo.sysjobs.job_id
      WHERE   sysjobs.name = ''Nightly Claim Processing'' 
      and run_date= (convert(varchar(4),YEAR ((getdate())))+
					case when len(convert(varchar(4),Month((getdate()))))=1
						then ''0''+convert(varchar(4),Month((getdate())))
						else convert(varchar(4),Month((getdate())))end+
							case when len(convert(varchar(4),DAY((getdate()))))=1
								then ''0''+convert(varchar(4),DAY((getdate())))
								else convert(varchar(4),DAY((getdate())))
									end)
', 
		@database_name=N'IQSC_DataWarehouse', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Claim_processing_JobHistory', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20130606, 
		@active_end_date=99991231, 
		@active_start_time=234500, 
		@active_end_time=235959, 
		@schedule_uid=N'774ed822-b723-4447-8d87-b0ccbcab3d1d'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [CommandLog Cleanup]    Script Date: 12/31/2015 08:46:42 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 12/31/2015 08:46:42 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'CommandLog Cleanup', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Source: https://ola.hallengren.com', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [CommandLog Cleanup]    Script Date: 12/31/2015 08:46:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'CommandLog Cleanup', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'sqlcmd -E -S $(ESCAPE_SQUOTE(SRVR)) -d master -Q "DELETE FROM [dbo].[CommandLog] WHERE StartTime < DATEADD(dd,-30,GETDATE())" -b', 
		@output_file_name=N'C:\Program Files\Microsoft SQL Server\MSSQL10_50.IQSC01\MSSQL\Log\CommandLogCleanup_$(ESCAPE_SQUOTE(JOBID))_$(ESCAPE_SQUOTE(STEPID))_$(ESCAPE_SQUOTE(STRTDT))_$(ESCAPE_SQUOTE(STRTTM)).txt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [copy]    Script Date: 12/31/2015 08:46:42 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:42 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'copy', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\DATAINITSQLAGENT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [copy]    Script Date: 12/31/2015 08:46:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'copy', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Exec master..xp_cmdshell  '' move  Y:\SQL02$IQSC01_DFWHC_Staging_FULL_20130809_011633.bak  M:\IQSC_DataWarehouse''', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [create index]    Script Date: 12/31/2015 08:46:42 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:42 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'create index', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\DATAINITSQLAGENT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [create index]    Script Date: 12/31/2015 08:46:42 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'create index', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=2, 
		@retry_interval=20, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE [IQSC_DataWarehouse]
GO

alter table dbo.FACT_ClaimCharge alter column Sequence int not null

go


USE [IQSC_DataWarehouse]
GO

/****** Object:  Index [PK_FACT_ClaimCharge]    Script Date: 02/28/2014 23:48:33 ******/
ALTER TABLE [dbo].[FACT_ClaimCharge] ADD  CONSTRAINT [PK_FACT_ClaimCharge] PRIMARY KEY CLUSTERED 
(
	[Claim_Key] ASC,
	[Sequence] ASC
)WITH (PAD_INDEX  = ON, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON, FILLFACTOR = 90) ON [PRIMARY]
GO


USE [IQSC_DataWarehouse]
GO

/****** Object:  Index [_dta_index_FACT_ClaimCharge_6_1829685666__K25_K4_K10_K1_2]    Script Date: 02/28/2014 23:47:23 ******/
CREATE NONCLUSTERED INDEX [_dta_index_FACT_ClaimCharge_6_1829685666__K25_K4_K10_K1_2] ON [dbo].[FACT_ClaimCharge] 
(
	[Batch_ID] ASC,
	[SubmissionPurpose] ASC,
	[HCPCS_ProcedureCode] ASC,
	[Claim_Key] ASC
)
INCLUDE ( [Sequence]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO




USE [IQSC_DataWarehouse]
GO

SET ARITHABORT ON
GO

SET CONCAT_NULL_YIELDS_NULL ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_NULLS ON
GO

SET ANSI_PADDING ON
GO

SET ANSI_WARNINGS ON
GO

SET NUMERIC_ROUNDABORT OFF
GO

/****** Object:  Index [_dta_index_FACT_ClaimCharge_6_1829685666__K4_K21_1_2_3_5_6_7_8_9_10_11_12_13_14_15_16_17_18_19_20_22_23_24_25_26]    Script Date: 02/28/2014 23:47:44 ******/
CREATE NONCLUSTERED INDEX [_dta_index_FACT_ClaimCharge_6_1829685666__K4_K21_1_2_3_5_6_7_8_9_10_11_12_13_14_15_16_17_18_19_20_22_23_24_25_26] ON [dbo].[FACT_ClaimCharge] 
(
	[SubmissionPurpose] ASC,
	[OutpatientProcedureFlag] ASC
)
INCLUDE ( [Claim_Key],
[Sequence],
[Hospital_Key],
[DischargeQuarter],
[DischargeDate],
[ServiceDate],
[RevenueCode],
[HCPCS_QualifierCode],
[HCPCS_ProcedureCode],
[HCPCS_ModifierCode01],
[HCPCS_ModifierCode02],
[HCPCS_ModifierCode03],
[HCPCS_ModifierCode04],
[ChargeAmt],
[NonCoveredChargeAmt],
[Units],
[UnitRate],
[UnitMeasurementCode],
[APC_Key],
[DW_InsertDate],
[Revision],
[Fact_Key],
[Batch_ID],
[UpdateDate]) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
GO


', 
		@database_name=N'IQSC_DataWarehouse', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'xx', 
		@enabled=0, 
		@freq_type=1, 
		@freq_interval=0, 
		@freq_subday_type=0, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20140301, 
		@active_end_date=99991231, 
		@active_start_time=100000, 
		@active_end_time=235959, 
		@schedule_uid=N'fed6ecfa-29af-4d7d-8de1-f8b4ba4589bf'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [DashBoard Load]    Script Date: 12/31/2015 08:46:43 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:43 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DashBoard Load', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\DATAINITSQLAGENT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [dashboardload]    Script Date: 12/31/2015 08:46:43 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'dashboardload', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=3, 
		@retry_interval=2, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\Dashboard Load" /SERVER hv10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'DashBoard Load', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=8, 
		@freq_subday_interval=2, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20130830, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'084ac169-9501-4b1c-bd2b-b4ddacf91433'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [DB_SpaceUseed]    Script Date: 12/31/2015 08:46:43 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:43 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DB_SpaceUseed', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\DATAINITSQLAGENT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DB_SpaceUsed]    Script Date: 12/31/2015 08:46:43 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DB_SpaceUsed', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'  DECLARE @SpaceUsed TABLE
	 (
	  name nvarchar(30), 
	  db_size nvarchar(25),
	  owner nvarchar(24),
	  dbid smallint,
	  created char(11),
	  status varchar(max),
	  compatibility_level tinyint
	  )

	--Populate the table
	INSERT INTO @SpaceUsed EXEC sp_helpdb
	
	insert into Database_Space_Used
	select  name,db_size,GETDATE() from @SpaceUsed
	where name in(''IQSC_DataWarehouse'',''QEdit_Staging'',''DFWHC_Staging'')', 
		@database_name=N'DBA_Maintenance', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Db_SpaceUsed', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20130205, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'162efeda-a61d-4d95-be74-3ac962602f07'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [DBCC DFWHC_Staging]    Script Date: 12/31/2015 08:46:43 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:43 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DBCC DFWHC_Staging', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'Purna', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DBCC CheckDB]    Script Date: 12/31/2015 08:46:43 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DBCC CheckDB', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DBCC CHECKDB (''DFWHC_STAGING'')
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'DBCC CheckDB', 
		@enabled=1, 
		@freq_type=32, 
		@freq_interval=7, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=4, 
		@freq_recurrence_factor=1, 
		@active_start_date=20150927, 
		@active_end_date=99991231, 
		@active_start_time=70000, 
		@active_end_time=235959, 
		@schedule_uid=N'c7d8a802-a6d1-45a5-a922-1a55dd79959d'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [DBCC INDEXDEFRAG]    Script Date: 12/31/2015 08:46:43 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:43 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DBCC INDEXDEFRAG', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\jdaniel', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DBCC INDEXDEFRAG_1]    Script Date: 12/31/2015 08:46:43 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DBCC INDEXDEFRAG_1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'-- Declare variables
SET NOCOUNT ON;
DECLARE @tablename varchar(255);
DECLARE @execstr   varchar(400);
DECLARE @objectid  int;
DECLARE @indexid   int;
DECLARE @frag      decimal;
DECLARE @maxfrag   decimal;

-- Decide on the maximum fragmentation to allow for.
SELECT @maxfrag = 30.0;

-- Declare a cursor.
DECLARE tables CURSOR FOR
   SELECT TABLE_SCHEMA + ''.'' + TABLE_NAME
   FROM INFORMATION_SCHEMA.TABLES
   WHERE TABLE_TYPE = ''BASE TABLE'';

-- Create the table.
CREATE TABLE #fraglist (
   ObjectName char(255),
   ObjectId int,
   IndexName char(255),
   IndexId int,
   Lvl int,
   CountPages int,
   CountRows int,
   MinRecSize int,
   MaxRecSize int,
   AvgRecSize int,
   ForRecCount int,
   Extents int,
   ExtentSwitches int,
   AvgFreeBytes int,
   AvgPageDensity int,
   ScanDensity decimal,
   BestCount int,
   ActualCount int,
   LogicalFrag decimal,
   ExtentFrag decimal);

-- Open the cursor.
OPEN tables;

-- Loop through all the tables in the database.
FETCH NEXT
   FROM tables
   INTO @tablename;

WHILE @@FETCH_STATUS = 0
BEGIN
-- Do the showcontig of all indexes of the table
   INSERT INTO #fraglist 
   EXEC (''DBCC SHOWCONTIG ('''''' + @tablename + '''''') 
      WITH FAST, TABLERESULTS, ALL_INDEXES, NO_INFOMSGS'');
   FETCH NEXT
      FROM tables
      INTO @tablename;
END;

-- Close and deallocate the cursor.
CLOSE tables;
DEALLOCATE tables;

-- Declare the cursor for the list of indexes to be defragged.
DECLARE indexes CURSOR FOR
   SELECT ObjectName, ObjectId, IndexId, LogicalFrag
   FROM #fraglist
   WHERE LogicalFrag >= @maxfrag
      AND INDEXPROPERTY (ObjectId, IndexName, ''IndexDepth'') > 0;

-- Open the cursor.
OPEN indexes;

-- Loop through the indexes.
FETCH NEXT
   FROM indexes
   INTO @tablename, @objectid, @indexid, @frag;

WHILE @@FETCH_STATUS = 0
BEGIN
   PRINT ''Executing DBCC INDEXDEFRAG (0, '' + RTRIM(@tablename) + '',
      '' + RTRIM(@indexid) + '') - fragmentation currently ''
       + RTRIM(CONVERT(varchar(15),@frag)) + ''%'';
   SELECT @execstr = ''DBCC INDEXDEFRAG (0, '' + RTRIM(@objectid) + '',
       '' + RTRIM(@indexid) + '')'';
   EXEC (@execstr);

   FETCH NEXT
      FROM indexes
      INTO @tablename, @objectid, @indexid, @frag;
END;

-- Close and deallocate the cursor.
CLOSE indexes;
DEALLOCATE indexes;

-- Delete the temporary table.
DROP TABLE #fraglist;
GO', 
		@database_name=N'IQSC_DataWarehouse', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'DBCC INDEXDEFRAG_1', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=64, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20150804, 
		@active_end_date=99991231, 
		@active_start_time=230000, 
		@active_end_time=235959, 
		@schedule_uid=N'3aab757d-ebfe-44d4-8705-e1e8e9467937'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [DBCC IQSC_Datawarehouse]    Script Date: 12/31/2015 08:46:43 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:43 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DBCC IQSC_Datawarehouse', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'Purna', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DBCC CHECK DB]    Script Date: 12/31/2015 08:46:43 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DBCC CHECK DB', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DBCC CHECKDB (''IQSC_DATAWAREHOUSE'')
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'DBCC CheckDB', 
		@enabled=1, 
		@freq_type=32, 
		@freq_interval=7, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=1, 
		@freq_recurrence_factor=1, 
		@active_start_date=20150927, 
		@active_end_date=99991231, 
		@active_start_time=70000, 
		@active_end_time=235959, 
		@schedule_uid=N'513be1a7-e4e6-40ea-9aaf-fedb63da4a36'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [DBCC QEdit_Staging]    Script Date: 12/31/2015 08:46:43 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:43 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DBCC QEdit_Staging', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'Purna', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DBCC CheckDB]    Script Date: 12/31/2015 08:46:43 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DBCC CheckDB', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DBCC CHECKDB (''QEDIT_STAGING'')', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'DBCC CheckDB', 
		@enabled=1, 
		@freq_type=32, 
		@freq_interval=7, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=4, 
		@freq_recurrence_factor=1, 
		@active_start_date=20150927, 
		@active_end_date=99991231, 
		@active_start_time=70000, 
		@active_end_time=235959, 
		@schedule_uid=N'583e53d9-3769-46b9-9f7a-8b3aadfdf8b7'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [DBCC Shrink]    Script Date: 12/31/2015 08:46:43 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:43 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DBCC Shrink', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\DATAINITSQLAGENT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DBCC Shrink]    Script Date: 12/31/2015 08:46:43 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DBCC Shrink', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DBCC SHRINKFILE (N''IQSC_Warehouse_DB'' , 460434)
GO', 
		@database_name=N'IQSC_DataWarehouse', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [DRG_Test Run]    Script Date: 12/31/2015 08:46:43 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:43 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DRG_Test Run', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Testing DRG Processing only', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\DATAINITSQLAGENT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DRG]    Script Date: 12/31/2015 08:46:43 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DRG', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\3_DW_Grouper" /SERVER hv10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [FactClaims]    Script Date: 12/31/2015 08:46:43 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:43 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'FactClaims', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Load Factclaims]    Script Date: 12/31/2015 08:46:43 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Load Factclaims', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/SQL "\2_DW_FactLoads" /SERVER "HV10\IQSC01" /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Hospitals load from Data_Submission]    Script Date: 12/31/2015 08:46:43 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:43 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Hospitals load from Data_Submission', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\DATAINITSQLAGENT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [To load New Hopitals]    Script Date: 12/31/2015 08:46:43 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'To load New Hopitals', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
--to load in staging
insert into DFWHC_Staging..[Hospitals] 
select ID,
HospitalName,
HospitalID,
MedicareProvider,
TaxonomyCode,
NPI,
FederalTaxEIN,
ThcicNumber,
AddressLine1,
AddressLine2,
City,
State,
ZipCode,
ContactName,
ContactPhone,
ContactFax,
BedSize,
AverageMonthlyCensus,
TeachingFacility,
RuralUrban,
Submission,
ExtendedDLQ1,
ExtendedDLQ2,
ExtendedDLQ3,
ExtendedDLQ4,
Archive,
CreatedAt
 from  [Data_submission]..[Hospitals]
 where ID not in(select ID from DFWHC_Staging..[Hospitals] )
 
 ---to load in warehouse
  
 insert into IQSC_DataWarehouse. dbo.DimHospital
(DIPart,
EIN,
HospitalFullName,
IQSC_Hospital_ID,
--DQA_Hospital_ID,
IsActive,
IsSystemMember,
NPI,
TaxomomyCode,
HospitalName,
MedicareID,
--DI_Member,
Bedsize,
[Address],
Address2,
City,
[State],
 Zip,
Teaching,
t_DataSubmission_HospitalID,
t_THCIC_Hospital_ID,
DW_InsertDate)
select 
1,
FederalTaxEIN,
HospitalName,
LEFT(HospitalID,10),
--ID,
1,
1,
NPI,
TaxonomyCode,
HospitalName,
MedicareProvider,
--1,
BedSize,
AddressLine1,
AddressLine2,
City,
case when [State] = ''texas'' then ''TX'' ELSE [STATE] END AS State,
[ZipCode],
[TeachingFacility],
ID,
LEFT(ThcicNumber,6),
GETDATE()
  From DFWHC_Staging..[Hospitals]
where thcicnumber not in(select t_THCIC_Hospital_ID from IQSC_DataWarehouse..dimhospital  )
and thcicnumber not in(''448000'',
''123456'',
''042000old'',
''653000'',
''642000b'',
''400000'',
''999999''
)



 

', 
		@database_name=N'DFWHC_Staging', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'To load New Hopitals', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20130508, 
		@active_end_date=99991231, 
		@active_start_time=180000, 
		@active_end_time=235959, 
		@schedule_uid=N'321859cc-cbb8-4911-8b52-50ad14b28b81'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [IQSC_Warehouse backup]    Script Date: 12/31/2015 08:46:43 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:43 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'IQSC_Warehouse backup', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'Purna', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DatawareHouse backup]    Script Date: 12/31/2015 08:46:43 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DatawareHouse backup', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXECUTE dbo.DatabaseBackup
@Databases = ''IQSC_Datawarehouse'',
@Directory = ''\\DFWF-Share\SQL Backups\HV10\IQSC_DataWarehouse\'',
@BackupType = ''FULL'',
@Compress = ''Y'',
@CheckSum = ''Y'',
@BufferCount = 50,
@MaxTransferSize = 4194304,
@NumberOfFiles = 8,
@CleanupTime =144


EXECUTE dbo.DatabaseBackup
@Databases = ''Data_Submission'',
@Directory = ''\\DFWF-Share\SQL Backups\HV10\Data_Submission\'',
@BackupType = ''FULL'',
@Compress = ''Y'',
@CheckSum = ''Y'',
@BufferCount = 50,
@MaxTransferSize = 4194304,
@NumberOfFiles = 8,
@CleanupTime =144



EXECUTE dbo.DatabaseBackup
@Databases = ''DFWHC_Staging'',
@Directory = ''\\DFWF-Share\SQL Backups\HV10\DFWHC_Staging\'',
@BackupType = ''FULL'',
@Compress = ''Y'',
@CheckSum = ''Y'',
@BufferCount = 50,
@MaxTransferSize = 4194304,
@NumberOfFiles = 8,
@CleanupTime =144


EXECUTE dbo.DatabaseBackup
@Databases = ''QEdit_Staging'',
@Directory = ''\\DFWF-Share\SQL Backups\HV10\QEdit_Staging\'',
@BackupType = ''FULL'',
@Compress = ''Y'',
@CheckSum = ''Y'',
@BufferCount = 50,
@MaxTransferSize = 4194304,
@NumberOfFiles = 8,
@CleanupTime =144', 
		@database_name=N'master', 
		@output_file_name=N'N:\Database_Backup\IQSC_Datawarehouse.txt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Warehouse Backup', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=62, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20141208, 
		@active_end_date=99991231, 
		@active_start_time=20000, 
		@active_end_time=235959, 
		@schedule_uid=N'3c64121b-caaf-4240-a5be-c940ca2584af'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [JointPUDFTesting]    Script Date: 12/31/2015 08:46:43 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:43 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'JointPUDFTesting', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\DATAINITSQLAGENT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [JointLoad]    Script Date: 12/31/2015 08:46:43 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'JointLoad', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\10_Export_IQSC_Pudf" /SERVER hv10 /CONNECTION "IQSC_DataWarehouse";"\"Data Source=SQL02\IQSC01;Initial Catalog=IQSC_DataWarehouse;Provider=SQLOLEDB.1;Integrated Security=SSPI;Persist Security Info=False;\"" /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Load Diags Procs and ECodes from View to Table]    Script Date: 12/31/2015 08:46:43 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:43 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Load Diags Procs and ECodes from View to Table', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\DATAINITSQLAGENT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [LoadDiagsProcsEcodes SSIS]    Script Date: 12/31/2015 08:46:43 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'LoadDiagsProcsEcodes SSIS', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\LoadDiagsProcsEcodes" /SERVER hv10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Load_QV_LOAD_THCIC]    Script Date: 12/31/2015 08:46:43 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:43 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Load_QV_LOAD_THCIC', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\DATAINITSQLAGENT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Load_QV_LOAD_THCIC]    Script Date: 12/31/2015 08:46:43 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Load_QV_LOAD_THCIC', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec [dbo].[Load_QV_LOAD_THCIC]

DROP TABLE THCIC.dbo.QV_THCIC_Vertical_Diags_IP

DROP TABLE THCIC.dbo.QV_THCIC_Vertical_Procs_IP

select * into THCIC.dbo.QV_THCIC_Vertical_Diags_IP from IQSC_DW_Reporting.dbo.vw_THCIC_Vertical_Diags_IP
select * into THCIC.dbo.QV_THCIC_Vertical_Procs_IP from IQSC_DW_Reporting.dbo.vw_THCIC_Vertical_Procs_IP', 
		@database_name=N'THCIC', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'load', 
		@enabled=0, 
		@freq_type=1, 
		@freq_interval=0, 
		@freq_subday_type=0, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20131002, 
		@active_end_date=99991231, 
		@active_start_time=234352, 
		@active_end_time=235959, 
		@schedule_uid=N'be49bd3a-e6e9-4627-8b4f-de06a8d8c0fb'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Nightly Claim Processing]    Script Date: 12/31/2015 08:46:43 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:43 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Nightly Claim Processing', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\DATAINITSQLAGENT', 
		@notify_email_operator_name=N'Purna', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [1_LoadTHCICCertificationFile]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'1_LoadTHCICCertificationFile', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\1_LoadTHCICCertificationFile" /SERVER HV10 /CONNECTION CertificationFile;"C:\DropBox\THCIC_Certification_Files\th859900_4q09_inpat_enc.txt" /CONNECTION ChargeFile;"C:\DropBox\THCIC_Certification_Files\th859900_4q09_inpat_rev.txt" /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [1_LoadTHCICCertificationFileToWarehouse]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'1_LoadTHCICCertificationFileToWarehouse', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\1_LoadTHCICCertificationFileToWarehouse" /SERVER HV10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [2_DW_FactLoads]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'2_DW_FactLoads', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=7, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\2_DW_FactLoads" /SERVER HV10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Fix_Physicians]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Fix_Physicians', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=7, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\Fix_Physicians" /SERVER hv10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [3_DW_Grouper]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'3_DW_Grouper', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=7, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\3_DW_Grouper" /SERVER HV10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [3_DW_Grouper_APC_APG]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'3_DW_Grouper_APC_APG', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\3_DW_Grouper_APC_APG" /SERVER HV10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [4_DW_Quadramed_File_Processing]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'4_DW_Quadramed_File_Processing', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=8, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\4_DW_Quadramed_File_Processing" /SERVER hv10 /CONNECTION "QuadraMed_local_file";"C:\DropBox\QuadraMed\QuadraMedLoadFile_20130913_1152_0.txt" /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update DimQueueStatus]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update DimQueueStatus', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=10, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'UPDATE Q

	SET SubmittedToQuadraMed = 1
	,	SubmittedToQuadraMedDate = getdate()
	
	FROM dbo.DimQueueStatus Q
		INNER JOIN ETL.Quadramed_QueueStatusList QL ON QL.QueueStatus_Key = Q.QueueStatus_Key
	

	INSERT INTO ETL.QuadramedControl (Has_File, FileCreationDate)
	SELECT 1 AS Has_File, GetDate() AS FileCreationDate

', 
		@database_name=N'IQSC_DataWarehouse', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Rife Move]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Rife Move', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @var1 nvarchar(100)
select @var1=''QuadraMedLoadFile''
select @var1=@var1+''_''+convert(varchar(10),getdate(),112)
select @var1=@var1+''*.txt''
declare @var3 nvarchar(600)
declare @var4 nvarchar(600)
select @var3 =''move''+'' C:\DropBOX\Quadramed\''+@var1 +'' C:\DropBOX\Quadramed\Success\''--'' \\RIFE\QuadraMed_DI_Extract''
select @var4 =''Copy''+'' C:\DropBOX\Quadramed\Success\''+@var1 +'' \\RIFE\QuadraMed_DI_Extract\load\''--'' \\RIFE\QuadraMed_DI_Extract''
Exec master..xp_cmdshell  @var3
Exec master..xp_cmdshell  @var4
--declare @var1 nvarchar(100)
--select @var1=''QuadraMedLoadFile''
--select @var1=@var1+''_''+convert(varchar(10),getdate(),112)
--select @var1=@var1+''*.txt''
--declare @var3 nvarchar(100)
--select @var3 =''Copy''+'' X:\''+@var1 +'' Y:\''
--Exec master..xp_cmdshell  @var3', 
		@database_name=N'master', 
		@output_file_name=N'C:\DropBOX\Quadramed\LOgfile.txt', 
		@flags=2
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [5_DW_Quadramed_Refresh]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'5_DW_Quadramed_Refresh', 
		@step_id=10, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\5_DW_Quadramed_Refresh" /SERVER hv10 /X86  /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DIMClaimPatient Update for QUID]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DIMClaimPatient Update for QUID', 
		@step_id=11, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'update dcp
            set dcp.QUID=dc.[QUID]
		FROM dbo.DimClaimPatient dcp 
			LEFT JOIN [IQSC_DataWarehouse].[dbo].[DimClaim] dc
			ON dcp.Claim_Key = dc.Claim_Key
			WHERE dc.ClaimStatusCode NOT IN (''X'',''V'')
			AND dc.PrimaryRecord = 1
			AND (dc.QUID != dcp.QUID or dcp.QUID is null)', 
		@database_name=N'IQSC_DataWarehouse', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [55_DW_QuadraMed_QUID_GUID_XRef]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'55_DW_QuadraMed_QUID_GUID_XRef', 
		@step_id=12, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\Update_QUID_GUID_XRef" /SERVER hv10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [6_ProcessEncounterClassification]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'6_ProcessEncounterClassification', 
		@step_id=13, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\6_ProcessEncounterClassification" /SERVER hv10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [7_DW_MasterDeathIndexLoad]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'7_DW_MasterDeathIndexLoad', 
		@step_id=14, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\7_DW_MasterDeathIndexLoad" /SERVER hv10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [7_1_Update_NumOfDaysLive]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'7_1_Update_NumOfDaysLive', 
		@step_id=15, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec dbo.sp_Update_MortalityDate_Status
', 
		@database_name=N'IQSC_DataWarehouse', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [8_REMPI_1_Process_ReadmissionMatrix]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'8_REMPI_1_Process_ReadmissionMatrix', 
		@step_id=16, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=21, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\8_REMPI_1_Process_ReadmissionMatrix" /SERVER hv10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [8_REMPI_2_Process_EncounterClassMatrix]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'8_REMPI_2_Process_EncounterClassMatrix', 
		@step_id=17, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\8_REMPI_2_Process_EncounterClassMatrix" /SERVER hv10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [8_REMPI_3_Process_ReAdmitTypeAssignment]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'8_REMPI_3_Process_ReAdmitTypeAssignment', 
		@step_id=18, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\8_REMPI_3_Process_ReAdmitTypeAssignment" /SERVER hv10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [8_REMPI_4_DM_REMPI_DataMart_ETL]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'8_REMPI_4_DM_REMPI_DataMart_ETL', 
		@step_id=19, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\8_REMPI_4_DM_REMPI_DataMart_ETL" /SERVER hv10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [8_REMPI_5_Process_Fact_Patient_Index_Expanded]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'8_REMPI_5_Process_Fact_Patient_Index_Expanded', 
		@step_id=20, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\8_REMPI_5_Process_Fact_Patient_Index_Expanded" /SERVER hv10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [9_NYU_Nightly]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'9_NYU_Nightly', 
		@step_id=21, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\9_NYU_Nightly" /SERVER hv10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [10_Export_IQSC_Pudf]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'10_Export_IQSC_Pudf', 
		@step_id=22, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=23, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\msdb\10_Export_IQSC_Pudf" /SERVER hv10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [ICD10 Update]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'ICD10 Update', 
		@step_id=23, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec dbo.sp_UpdateICD10', 
		@database_name=N'IQSC_DataWarehouse', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update ICD9Code]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update ICD9Code', 
		@step_id=24, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'update Map_Claim_ICD_Diagnosis 
set ICD9_Diag_Code=icd10.[ICD-9 Code]
from Map_Claim_ICD_Diagnosis MCD (NOLOCK)  
JOIN Dim_DiagnosisMap ICD10 (NOLOCK) ON MCD.Diagnosis_Code=ICD10.[ICD-10 Code]
 where icd10=1
 AND DATEDIFF (DD,DW_Insertdate,GETDATE()) < 7

update Map_Claim_ICD_Procedure 
 set ICD9_Proc_Code=icd10.[ICD-9 Code]
  from Map_Claim_ICD_Procedure MCD (NOLOCK)  
				JOIN Dim_ProcedureMap ICD10 (NOLOCK) ON MCD.Procedure_Code=ICD10.[ICD-10 Code]
 where icd10=1
 AND DATEDIFF (DD,DW_Insertdate,GETDATE()) < 7
           
 update Map_Claim_ECodes 
  set ICD9_Diag_Code=icd10.[ICD-9 Code]
 from Map_Claim_ECodes MCD (NOLOCK)  
				JOIN Dim_DiagnosisMap ICD10 (NOLOCK) ON MCD.Diagnosis_Code=ICD10.[ICD-10 Code]
 where icd10=1
 AND DATEDIFF (DD,DW_Insertdate,GETDATE()) < 7

UPDATE Map_Claim_ICD_Procedure
SET ICD9_PROC_CODE=Procedure_Code
where icd10 =0
and ICD9_PROC_CODE is null

UPDATE Map_Claim_ICD_Diagnosis
SET ICD9_Diag_CODE=Diagnosis_Code
where icd10 =0
and ICD9_Diag_CODE is null

UPDATE Map_Claim_ECodes
SET ICD9_Diag_CODE=Diagnosis_Code
where icd10 =0
and ICD9_Diag_CODE is null', 
		@database_name=N'IQSC_DataWarehouse', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Nightly Schedule', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=1, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20140517, 
		@active_end_date=99991231, 
		@active_start_time=190000, 
		@active_end_time=235959, 
		@schedule_uid=N'76786965-bd62-4e3c-9d59-1aebe471f84c'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Notloadedfiles]    Script Date: 12/31/2015 08:46:44 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:44 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Notloadedfiles', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Fixed]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Fixed', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\MissedFiles" /SERVER hv10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Output File Cleanup]    Script Date: 12/31/2015 08:46:44 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 12/31/2015 08:46:44 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Output File Cleanup', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Source: https://ola.hallengren.com', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Output File Cleanup]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Output File Cleanup', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'cmd /q /c "For /F "tokens=1 delims=" %v In (''ForFiles /P "C:\Program Files\Microsoft SQL Server\MSSQL10_50.IQSC01\MSSQL\Log" /m *_*_*_*.txt /d -30 2^>^&1'') do if EXIST "C:\Program Files\Microsoft SQL Server\MSSQL10_50.IQSC01\MSSQL\Log"\%v echo del "C:\Program Files\Microsoft SQL Server\MSSQL10_50.IQSC01\MSSQL\Log"\%v& del "C:\Program Files\Microsoft SQL Server\MSSQL10_50.IQSC01\MSSQL\Log"\%v"', 
		@output_file_name=N'C:\Program Files\Microsoft SQL Server\MSSQL10_50.IQSC01\MSSQL\Log\OutputFileCleanup_$(ESCAPE_SQUOTE(JOBID))_$(ESCAPE_SQUOTE(STEPID))_$(ESCAPE_SQUOTE(STRTDT))_$(ESCAPE_SQUOTE(STRTTM)).txt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Patientdata]    Script Date: 12/31/2015 08:46:44 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:44 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Patientdata', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [OP]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'OP', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select * INTO AAA_STUDY..tAllPatientData_OP1
from tAllPatientdata_OP1
WHERE SSN IN (SELECT SSN FROM AAA_Study.REPORTSOURCE.AAA_APD_bak)
AND SubmissionPurpose = ''O''', 
		@database_name=N'IQSC_DataWarehouse', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'OP', 
		@enabled=0, 
		@freq_type=1, 
		@freq_interval=0, 
		@freq_subday_type=0, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20130313, 
		@active_end_date=99991231, 
		@active_start_time=101000, 
		@active_end_time=235959, 
		@schedule_uid=N'56cc0299-ef95-4ceb-b204-df98a0f668e4'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [PLE update]    Script Date: 12/31/2015 08:46:44 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:44 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'PLE update', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\jdaniel', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PLE update_1]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PLE update_1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec dbo.PLE', 
		@database_name=N'DBA_Maintenance', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'PLE update_1', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=127, 
		@freq_subday_type=4, 
		@freq_subday_interval=5, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20150710, 
		@active_end_date=99991231, 
		@active_start_time=30000, 
		@active_end_time=180000, 
		@schedule_uid=N'c305b5c7-ec8c-42a1-a3b6-3806fa877ca1'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [pudf load]    Script Date: 12/31/2015 08:46:44 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:44 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'pudf load', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\DATAINITSQLAGENT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PUDF Load]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PUDF Load', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--insert into THCIC_PUDF
--select * from THCIC_PUDF_TEST(nolock)
--select count(*) from THCIC_PUDF_TEST(nolock)
--where RECORD_ID not in(select RECORD_ID from THCIC_PUDF(nolock))

/****** Script for SelectTopNRows command from SSMS  ******/
--Insert into [THCIC].[dbo].[THCIC_PUDF_Charges]
--SELECT*
--  FROM [THCIC].[dbo].[THCIC_PUDF_Charges_TEST](nolock)

insert into [THCIC].[dbo].[THCIC_PUDF_Charges_test]
SELECT --[Charge_PK]
      [RECORD_ID]
      ,[REVENUE_CODE]
      ,[HCPCS_QUALIFIER]
      ,[HCPCS_PROCEDURE_CODE]
      ,[MODIFIER_1]
      ,[MODIFIER_2]
      ,[MODIFIER_3]
      ,[MODIFIER_4]
      ,[UNIT_MEASUREMENT_CODE]
      ,[UNITS_OF_SERVICE]
      ,[UNIT_RATE]
      ,[CHRGS_LINE_ITEM]
      ,[CHRGS_NON_COV]
      ,[SUBMISSION_PURPOSE]
  FROM [THCIC].[dbo].[THCIC_PUDF_Charges_test]', 
		@database_name=N'THCIC', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [QEdit Staging Load]    Script Date: 12/31/2015 08:46:44 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:44 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'QEdit Staging Load', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'This job loads files from the DSS dashboard for QEdit extract files.  These are loaded into QEdit_Staging database and then on to the DFWHC_Staging database.  The normal nightly processing jobs then take the data from stagin into the IQSC Data warehouse.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\DATAINITSQLAGENT', 
		@notify_email_operator_name=N'Purna', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DSS QEdit File Fix]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DSS QEdit File Fix', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=4, 
		@on_success_step_id=2, 
		@on_fail_action=4, 
		@on_fail_step_id=2, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\DSS QEdit File Fix" /SERVER HV10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [DSS QEdit File Load]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'DSS QEdit File Load', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\DSS QEdit Fiel Load" /SERVER hv10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update Warehouse Claim Counts in Dashboard]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update Warehouse Claim Counts in Dashboard', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\UpdateWhseClaimCount" /SERVER HV10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Qedit Load', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=8, 
		@freq_subday_interval=2, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20140528, 
		@active_end_date=99991231, 
		@active_start_time=80000, 
		@active_end_time=170059, 
		@schedule_uid=N'6cf6a4fc-c743-46ad-bf47-767721780a21'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Qedit Temp]    Script Date: 12/31/2015 08:46:44 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:44 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Qedit Temp', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\pyalavarthy', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [qedit temp]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'qedit temp', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\DSS QEdit Fiel Load 1" /SERVER hv10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [QlikVIew LOAd]    Script Date: 12/31/2015 08:46:44 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:44 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'QlikVIew LOAd', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Qlik VIEW Load]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Qlik VIEW Load', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'drop table qlikView


SELECT  

1 AS CaseCnt,

DC.Claim_Key,

DD.[Quarter] ''DISCHQTR'',

DD.[Year] ''YEAR'',

DD.[Month] DschrgMnth,

DD.MonthAbr MnthName,

dd.MonthOfYear Mnth,

Blind.Hospital_Key,

fipc.SpecUnit1 ''SPECUNIT1'',

fipc.SpecUnit2 ''SPECUNIT2'',

Blind.SexCode ''SEXCODE'',

at.AdmitTypeCode ''ADMTYPE'',

DAS.AdmitSourceCode ''ADMSOURCE'',

cast (Blind.ZipCode AS VARCHAR) ''ZIPCODE'',

cast (Blind.State AS VARCHAR) ''STATE'',

Blind.County ''COUNTY'',

cast (dds.DischargeStatusCode AS VARCHAR) ''STATUS'',

cast (Blind.Race AS VARCHAR) ''RACE'',

cast (Blind.Ethnicity AS VARCHAR) ''ETHNICIT'',

DC.BillTypeCode ''BILLTYPE'',

AdmitDiag.DiagnosisShortDesc ''ADMCODE'',

cast (FC.LOS AS VARCHAR) ''LOS'',

cast (fipc.DILOS AS VARCHAR) ''DILOS'',

DATEPART (DW, DC.AdmitDate) ''ADMWEEKD'',

cast (FC.AdmitAge AS VARCHAR) ''AGE'',

FC.AdmitAgeDays AS ''AGEDAYS'',

r.GrouperVersionUsed ''VERSION'',

--fipc.DRG_Error AS ''ERROR'',

substring(convert(char(4),r.MDC + 100),2,2) ''APR_MDC'',

substring(convert(char(4),r.DRG + 1000),2,3) ''APR_DRG'',

r.RiskOfMortality AS ''RM'',

Case When fipc.IS_Emergency = 0 Then ''0'' ELSE ''1'' END AS IS_Emergency,

Case When fipc.IS_ObservationRoom = 0 Then ''0'' ELSE ''1'' END AS IS_ObservationRoom,

Case When fipc.IS_OperatingRoom = 0 Then ''0'' ELSE ''1'' END AS IS_OperatingRoom,

Case When fipc.IS_OutpatientProcedure = 0 Then ''0'' ELSE ''1'' END AS IS_OutpatientProcedure,

r.SeverityOfIllness ''SEV'',

FC.TotalCharges ''TOTALCHG'',

FC.AncillaryCharges ''T_ANCCHG'',

FC.AccomodationCharges ''T_ACCCHG'',

fipm.PRIVCHG cPRIVCHG,

fipm.SPRIVCHG cSPRIVCHG,

fipm.WARDCHG cWARDCHG,

fipm.ICUCHG cICUCHG,

fipm.CCUCHG cCCUCHG,

fipm.OTHANCHG cOTHANCHG,

fipm.PHARMCHG cPHARMCHG,

fipm.MEDSRGCH cMEDSRGCH,

fipm.DMECHG cDMECHG,

fipm.UDMECHG cUDMECHG,

fipm.PTCHG cPTCHG,

fipm.OTCHG cOTCHG,

fipm.SPEECHCH cSPEECHCH,

fipm.INHTXCHG cINHTXCHG,

fipm.BLOODCHG cBLOODCHG,

fipm.BLDADMCH cBLDADMCH,

fipm.ORCHG cORCHG,

fipm.LITHCHG cLITHCHG,

fipm.CARDCHG cCARDCHG,

fipm.ANESCHG cANESCHG,

fipm.LABCHG cLABCHG,

fipm.RADIOCHG cRADIOCHG,

fipm.MRICHG cMRICHG,

fipm.OPSRVCHG cOPSRVCHG,

fipm.ERCHG cERCHG,

fipm.AMBULCHG cAMBULCHG,

fipm.PROFEECH cPROFEECH,

fipm.ORGANCHG cORGANCHG,

fipm.ESRDCHG cESRDCHG,

fipm.CLINICCH cCLINICCH,

--fipc.APG,

FC.PayCode1 AS ''CLAIMFILINDCODE1'',

FC.PayCode2 AS ''CLAIMFILINDCODE2'',

FC.PayCode3 AS ''CLAIMFILINDCODE3'',

DC.SubmissionPurpose AS ''SubmissionPurpose'',

fipc.IS_Emergency AS EmergentFlag,

acu.Acuity,

cpfd.DiagPosCnt,

cpfp.ProcPosCnt,

THR.Product_line_name AS DiagProdLine,

THR.[3_digit_name] AS DiagProdSub,

ccs.[CCS CATEGORY DESCRIPTION] AS CCS_Category,

ccsdx.[CCS LVL 1 LABEL] AS CCS_Label1,

ccsdx.[CCS LVL 2 LABEL] AS CCS_Label2, 

D.DiagnosisCode_Decimal AS PrincipleDiagnosisCode,

D.Diagnosis AS PrincipleDiagnosis,

COALESCE (DP.ProcedureCode_Decimal, '''') AS PrinicpleProcedureCode,

COALESCE (DP.[Procedure], '''') AS PrincipleProcedure,

CASE WHEN MCID.DiagnosisSequence > 1 THEN ''1'' ELSE ''0'' END

AS SecondaryDiagnosis,

DPC.ECode01,   

DPC.ECode02,

DPC.ECode03,

DPC.Diag02,

DPC.Diag03,

DPC.Diag04,

DPC.Diag05,

DPC.Diag06,

DPC.Diag07,

DPC.Diag08,

DPC.Diag09,

DPC.Diag10,

DPC.Proc02,

DPC.Proc03,

DPC.Proc04,

DPC.Proc05,

DPC.Proc06,

DPC.Proc07,

DPC.Proc08,

DPC.Proc09,

DPC.Proc10,

FC.AdmitSource_Key,

FC.AdmitType_Key,

fipc.AGE AS AgeGroupCode,

--FC.APR_DRG_Key,

DC.BillTypeCode,

DC.ClaimStatusCode,

DC.DischargeDate,

DC.DischargeQuarter,

--FC.DRG_Key,
substring(convert(char(4),r2.DRG + 1000),2,3) ''DRG'',

FC.EthnicityCode,

FC.FacilityType_Key,

FC.RaceCode,

r.RiskOfMortality,

r.SeverityOfIllness ''Severity'',

FC.Sex,

CASE WHEN DDS.DischargeStatusCode IN (''20'', ''40'', ''41'', ''41'') THEN 1 ELSE 0 END AS Mortality,

mor.DeathFlag,

mor.MortalityStatus,

mor.NoDaysLive,

mor.LiveDaysAD,

DH.Ownership,

DH.Bedsize,

DH.CriticalAccess,

DH.Zip,

DH.County AS HospitalCounty,

HCP.HCPCS_ProcedureCode,

HP.HCPCS_ProcedureDesc,

CPT.OP_ProductLine AS CPT_ProductLine,

LOS.LOSGroupName,

CASE WHEN MCP1.Physician_Key = -1 THEN MCP1.PhysNameSupplied WHEN MCP1.Physician_Key = -2 THEN MCP1.PhysNameSupplied ELSE DP1.FullName END AS AttendingPhysician,

CASE WHEN MCP1.Physician_Key = -1 THEN MCP1.PhysIDSupplied WHEN MCP1.Physician_Key = -2 THEN MCP1.PhysIDSupplied WHEN DP1.NPI is not Null THEN convert(varchar(50),DP1.NPI) WHEN DP1.NPI is Null AND DP1.t_TMP_License_Number is not Null THEN convert(varchar(50),DP1.t_TMP_License_Number) ELSE convert(varchar(50),DP1.t_UPIN) END AS AttPhysID,

NPI.Healthcare_Provider_Taxonomy_Code AS TaxCode,

TCM.PracticeSpecialty,

TCM.Specialization,

CASE WHEN MCP2.Physician_Key = -1 THEN MCP2.PhysNameSupplied WHEN MCP2.Physician_Key = -2 THEN MCP2.PhysNameSupplied ELSE DP2.FullName END AS OperatingPhysician,

CASE WHEN MCP2.Physician_Key = -1 THEN MCP2.PhysIDSupplied WHEN MCP2.Physician_Key = -2 THEN MCP2.PhysIDSupplied WHEN DP2.NPI is not Null THEN convert(varchar(50),DP2.NPI) WHEN DP2.NPI is Null AND DP2.t_TMP_License_Number is not Null THEN convert(varchar(50),DP2.t_TMP_License_Number) ELSE convert(varchar(50),DP2.t_UPIN) END AS OprPhysID,   

CASE WHEN MCP1.Physician_Key = -1 THEN ''Yes'' WHEN MCP1.Physician_Key = -2 THEN ''Yes'' ELSE ''No'' END AS AttendingPhysicianMissing,

CASE WHEN MCP2.Physician_Key = -1 THEN ''Yes'' WHEN MCP2.Physician_Key = -2 THEN ''Yes'' ELSE ''No'' END AS OperatingPhysicianMissing,

NYU.dxgroup,
NYU.ne,
NYU.epct,
NYU.edcnpa,
NYU.edcnnpa,
NYU.injury,
NYU.psych,
NYU.alcohol,
NYU.drug,
NYU.unclassified,
NYU.DiagClass

--into qlikView

FROM IQSC_DataWarehouse.dbo.DimClaim DC (nolock)

LEFT JOIN IQSC_DataWarehouse.dbo.FACT_CLAIM FC(nolock)
ON FC.Claim_Key = DC.Claim_Key

--LEFT JOIN IQSC_DataWarehouse.dbo.Dim_MS_DRG drg (nolock)
--ON drg.DRG_Key = fc.DRG_Key

LEFT JOIN IQSC_DataWarehouse.dbo.FACT_IQSC_PUDF_Blinded Blind (nolock)
ON Blind.Claim_Key = DC.Claim_Key

LEFT JOIN IQSC_DataWarehouse.dbo.FACT_IQSC_PUDF_Computed fipc (nolock)
ON fipc.Claim_Key = DC.Claim_Key

LEFT JOIN IQSC_DataWarehouse.EncounterGrouping.GrouperResults r (nolock)
ON r.Claim_Key = dc.Claim_Key AND r.GrouperType = ''apr''

LEFT JOIN IQSC_DataWarehouse.EncounterGrouping.GrouperResults r2 (nolock)
ON r2.Claim_Key = dc.Claim_Key AND r.GrouperType = ''cms''

LEFT JOIN IQSC_DataWarehouse.dbo.FACT_IQSC_PUDF_MedPar fipm (nolock)
ON fipm.Claim_Key = DC.Claim_Key

LEFT JOIN IQSC_DataWarehouse.dbo.DimClaimPatient DCP (nolock)
ON dcp.Claim_Key = DC.Claim_Key

LEFT JOIN IQSC_DataWarehouse.dbo.DimAdmitType at (nolock)
ON at.AdmitType_Key = FC.AdmitType_Key

LEFT JOIN IQSC_DataWarehouse.dbo.DimAdmitSource DAS (nolock)
ON DAS.AdmitSource_Key = FC.AdmitSource_Key

LEFT JOIN IQSC_DataWarehouse.dbo.Map_Claim_ICD_Diagnosis admit (nolock)
ON admit.Claim_Key = DC.Claim_Key AND admit.DiagnosisSequence = 0

LEFT JOIN IQSC_DataWarehouse.dbo.DimDiagnosis AdmitDiag (nolock)
ON AdmitDiag.Diagnosis_Key = admit.Diagnosis_Key

LEFT JOIN IQSC_DataWarehouse.dbo.FACT_Claim_HighestChargeProcedure HCP (nolock)
ON HCP.Claim_Key = DC.Claim_Key

LEFT JOIN IQSC_DataWarehouse.dbo.Map_Claim_ICD_Diagnosis MCID (nolock)
ON MCID.Claim_Key = DC.Claim_Key AND MCID.PrincipleDiagnosis = 1

LEFT JOIN IQSC_DataWarehouse.dbo.DimDiagnosis D (nolock)
ON D.Diagnosis_Key = MCID.Diagnosis_Key

LEFT JOIN IQSC_DataWarehouse.dbo.Map_Claim_ICD_Procedure MCIP (nolock)
ON MCIP.Claim_Key = DC.Claim_Key AND PrincipleProcedure = 1 AND Procedure_Key <> -1

LEFT JOIN IQSC_DataWarehouse.dbo.DimProcedure DP (nolock)
ON DP.Procedure_Key = MCIP.Procedure_Key

LEFT JOIN IQSC_DataWarehouse.dbo.Dim_HCPCS_Procedure HP (nolock)
ON HP.HCPCS_ProcedureCode = HCP.HCPCS_ProcedureCode

LEFT JOIN IQSC_DataWarehouse.dbo.Dim_LOS_Group LOS (nolock)
ON FC.LOS BETWEEN LOS.LowerLOS AND LOS.UpperLOS

LEFT JOIN IQSC_DataWarehouse.dbo.DimDischargeStatus DDS (nolock)
ON FC.DischargeStatus_Key = DDS.DischargeStatus_Key

LEFT JOIN IQSC_DataWarehouse.dbo.DimHospital DH (nolock)
ON DC.Hospital_Key = DH.Hospital_Key

LEFT JOIN IQSC_DataWarehouse.dbo.Dim_CPT4_ProductLine CPT (nolock)
ON CPT.CPT_Code = HCP.HCPCS_ProcedureCode

LEFT JOIN IQSC_DataWarehouse.dbo.Map_Claim_Physician MCP1 (nolock)
ON MCP1.Claim_Key = DC.Claim_Key AND MCP1.PhysicianRole_Key = 1

LEFT JOIN IQSC_DataWarehouse.dbo.Map_Claim_Physician MCP2 (nolock)
ON MCP2.Claim_Key = DC.Claim_Key AND MCP2.PhysicianRole_Key = 2

LEFT JOIN IQSC_DataWarehouse.dbo.DimPhysician DP1 (nolock)
ON DP1.Physician_Key = MCP1.Physician_Key

LEFT JOIN IQSC_DataWarehouse.dbo.DimPhysician DP2 (nolock)
ON DP2.Physician_Key = MCP2.Physician_Key

LEFT JOIN IQSC_DataWarehouse.NYU_LOAD.NYUER_OUT_PUDF NYU (nolock)
ON NYU.Claim_Key = DC.Claim_Key

LEFT JOIN  IQSC_DataWarehouse.NPIData.ProviderLicense NPI (nolock)
ON NPI.NPI = DP1.NPI AND NPI.Healthcare_Provider_Primary_Taxonomy_Switch = ''Y'' AND NPI.Provider_License_Number_State_Code = ''TX''

LEFT JOIN  IQSC_DataWarehouse.Legacy.TaxonomyCodeMaster TCM (nolock)
ON TCM.TaxonomyCode = NPI.Healthcare_Provider_Taxonomy_Code

LEFT JOIN IQSC_DataWarehouse.dbo.DimDate DD (nolock)
ON DD.DateValue = DC.DischargeDate

LEFT JOIN IQSC_DataWarehouse.dbo.Dim_Diag_ProductLine_THR THR (nolock)
ON THR.Code_no_Decimal = D.DiagnosisCode

LEFT JOIN  IQSC_DataWarehouse.dbo.vw_QV_DiagProcCodesInp  DPC (nolock)
ON DPC.DFWHCID = DC.Claim_Key 

LEFT JOIN  IQSC_DataWarehouse.CCS_Working.DXREF_2013_working ccs (nolock)
ON ccs.[ICD-9-CM CODE] = D.DiagnosisCode

LEFT JOIN  IQSC_DataWarehouse.CCS_Working.ccs_multi_dx_tool_2013 ccsdx (nolock)
ON ccsdx.[ICD-9-CM CODE] = D.DiagnosisCode

--LEFT JOIN  IQSC_DataWarehouse.dbo.vw_QV_BITS bits (nolock)
--ON bits.Claim_Key = dc.Claim_Key

LEFT JOIN IQSC_DataWarehouse.dbo.vw_QV_ER_Out_Acuity acu (nolock)
ON acu.Claim_Key = dc.Claim_Key

LEFT JOIN IQSC_DataWarehouse.dbo.vw_QV_Mortality mor (nolock)
ON mor.Claim_Key = dc.Claim_Key

LEFT JOIN  IQSC_DataWarehouse.dbo.vw_QV_CodePosFilledDiag cpfd (nolock)
ON cpfd.Claim_Key = dc.Claim_Key

LEFT JOIN  IQSC_DataWarehouse.dbo.vw_QV_CodePosFilledProc cpfp (nolock)
ON cpfp.Claim_Key = dc.Claim_Key


                
WHERE

DC.PrimaryRecord = 1
AND DC.ClaimStatusCode NOT IN (''X'',''V'')
AND DC.DischargeQuarter >= 201101 

--AND dc.SubmissionPurpose = ''I''
--AND DD.[Month] = 201403
--AND dc.Hospital_Key = 15




UNION




SELECT  

1 AS CaseCnt,

DC.Claim_Key,

DD.[Quarter] ''DISCHQTR'',

DD.[Year] ''YEAR'',

DD.[Month] DschrgMnth,

DD.MonthAbr MnthName,

dd.MonthOfYear Mnth,

Blind.Hospital_Key,

fipc.SpecUnit1 ''SPECUNIT1'',

fipc.SpecUnit2 ''SPECUNIT2'',

Blind.SexCode ''SEXCODE'',

at.AdmitTypeCode ''ADMTYPE'',

DAS.AdmitSourceCode ''ADMSOURCE'',

cast (Blind.ZipCode AS VARCHAR) ''ZIPCODE'',

cast (Blind.State AS VARCHAR) ''STATE'',

Blind.County ''COUNTY'',

cast (dds.DischargeStatusCode AS VARCHAR) ''STATUS'',

cast (Blind.Race AS VARCHAR) ''RACE'',

cast (Blind.Ethnicity AS VARCHAR) ''ETHNICIT'',

DC.BillTypeCode ''BILLTYPE'',

AdmitDiag.DiagnosisShortDesc ''ADMCODE'',

cast (FC.LOS AS VARCHAR) ''LOS'',

cast (fipc.DILOS AS VARCHAR) ''DILOS'',

DATEPART (DW, DC.AdmitDate) ''ADMWEEKD'',

cast (FC.AdmitAge AS VARCHAR) ''AGE'',

FC.AdmitAgeDays AS ''AGEDAYS'',

fipc.APR_DRG_Version AS ''VERSION'',

--fipc.DRG_Error AS ''ERROR'',

adrg.MDC AS ''APR_MDC'',

adrg.APR_DRG,

fc.RiskOfMortality AS ''RM'',

Case When fipc.IS_Emergency = 0 Then ''0'' ELSE ''1'' END AS IS_Emergency,

Case When fipc.IS_ObservationRoom = 0 Then ''0'' ELSE ''1'' END AS IS_ObservationRoom,

Case When fipc.IS_OperatingRoom = 0 Then ''0'' ELSE ''1'' END AS IS_OperatingRoom,

Case When fipc.IS_OutpatientProcedure = 0 Then ''0'' ELSE ''1'' END AS IS_OutpatientProcedure,

fc.Severity AS ''SEV'',

FC.TotalCharges ''TOTALCHG'',

FC.AncillaryCharges ''T_ANCCHG'',

FC.AccomodationCharges ''T_ACCCHG'',

fipm.PRIVCHG cPRIVCHG,

fipm.SPRIVCHG cSPRIVCHG,

fipm.WARDCHG cWARDCHG,

fipm.ICUCHG cICUCHG,

fipm.CCUCHG cCCUCHG,

fipm.OTHANCHG cOTHANCHG,

fipm.PHARMCHG cPHARMCHG,

fipm.MEDSRGCH cMEDSRGCH,

fipm.DMECHG cDMECHG,

fipm.UDMECHG cUDMECHG,

fipm.PTCHG cPTCHG,

fipm.OTCHG cOTCHG,

fipm.SPEECHCH cSPEECHCH,

fipm.INHTXCHG cINHTXCHG,

fipm.BLOODCHG cBLOODCHG,

fipm.BLDADMCH cBLDADMCH,

fipm.ORCHG cORCHG,

fipm.LITHCHG cLITHCHG,

fipm.CARDCHG cCARDCHG,

fipm.ANESCHG cANESCHG,

fipm.LABCHG cLABCHG,

fipm.RADIOCHG cRADIOCHG,

fipm.MRICHG cMRICHG,

fipm.OPSRVCHG cOPSRVCHG,

fipm.ERCHG cERCHG,

fipm.AMBULCHG cAMBULCHG,

fipm.PROFEECH cPROFEECH,

fipm.ORGANCHG cORGANCHG,

fipm.ESRDCHG cESRDCHG,

fipm.CLINICCH cCLINICCH,

--fipc.APG,

FC.PayCode1 AS ''CLAIMFILINDCODE1'',

FC.PayCode2 AS ''CLAIMFILINDCODE2'',

FC.PayCode3 AS ''CLAIMFILINDCODE3'',

DC.SubmissionPurpose AS ''SubmissionPurpose'',

fipc.IS_Emergency AS EmergentFlag,

--bits.IS_Cardiology,

--bits.IS_AmbSurg,

--bits.IS_GastroInt,

--bits.IS_Radiology,

--bits.IS_Trauma,

acu.Acuity,

cpfd.DiagPosCnt,

cpfp.ProcPosCnt,

THR.Product_line_name AS DiagProdLine,

THR.[3_digit_name] AS DiagProdSub,

ccs.[CCS CATEGORY DESCRIPTION] AS CCS_Category,

ccsdx.[CCS LVL 1 LABEL] AS CCS_Label1,

ccsdx.[CCS LVL 2 LABEL] AS CCS_Label2, 

D.DiagnosisCode_Decimal AS PrincipleDiagnosisCode,

D.Diagnosis AS PrincipleDiagnosis,

COALESCE (DP.ProcedureCode_Decimal, '''') AS PrinicpleProcedureCode,

COALESCE (DP.[Procedure], '''') AS PrincipleProcedure,

CASE WHEN MCID.DiagnosisSequence > 1 THEN ''1'' ELSE ''0'' END

AS SecondaryDiagnosis,

DPC.ECode01,   

DPC.ECode02,

DPC.ECode03,

DPC.Diag02,

DPC.Diag03,

DPC.Diag04,

DPC.Diag05,

DPC.Diag06,

DPC.Diag07,

DPC.Diag08,

DPC.Diag09,

DPC.Diag10,

DPC.Proc02,

DPC.Proc03,

DPC.Proc04,

DPC.Proc05,

DPC.Proc06,

DPC.Proc07,

DPC.Proc08,

DPC.Proc09,

DPC.Proc10,

FC.AdmitSource_Key,

FC.AdmitType_Key,

fipc.AGE AS AgeGroupCode,

--adrg.APR_DRG,

DC.BillTypeCode,

DC.ClaimStatusCode,

DC.DischargeDate,

DC.DischargeQuarter,

--FC.DRG_Key,
drg.DRG,

FC.EthnicityCode,

FC.FacilityType_Key,

FC.RaceCode,

FC.RiskOfMortality,

FC.Severity,

FC.Sex,

CASE

WHEN DDS.DischargeStatusCode IN (''20'', ''40'', ''41'', ''41'') THEN 1

ELSE 0

END

AS Mortality,

mor.DeathFlag,

mor.MortalityStatus,

mor.NoDaysLive,

mor.LiveDaysAD,

DH.Ownership,

DH.Bedsize,

DH.CriticalAccess,

DH.Zip,

DH.County AS HospitalCounty,

HCP.HCPCS_ProcedureCode,

HP.HCPCS_ProcedureDesc,

CPT.OP_ProductLine AS CPT_ProductLine,

LOS.LOSGroupName,

CASE

WHEN MCP1.Physician_Key = -1 THEN MCP1.PhysNameSupplied

WHEN MCP1.Physician_Key = -2 THEN MCP1.PhysNameSupplied

ELSE DP1.FullName

END

AS AttendingPhysician,

CASE

WHEN MCP1.Physician_Key = -1 THEN MCP1.PhysIDSupplied

WHEN MCP1.Physician_Key = -2 THEN MCP1.PhysIDSupplied

WHEN DP1.NPI is not Null THEN convert(varchar(50),DP1.NPI)

WHEN DP1.NPI is Null AND DP1.t_TMP_License_Number is not Null THEN convert(varchar(50),DP1.t_TMP_License_Number)

ELSE convert(varchar(50),DP1.t_UPIN)

END

AS AttPhysID,

NPI.Healthcare_Provider_Taxonomy_Code AS TaxCode,

TCM.PracticeSpecialty,

TCM.Specialization,



CASE

WHEN MCP2.Physician_Key = -1 THEN MCP2.PhysNameSupplied

WHEN MCP2.Physician_Key = -2 THEN MCP2.PhysNameSupplied

ELSE DP2.FullName

END

AS OperatingPhysician,

CASE

WHEN MCP2.Physician_Key = -1 THEN MCP2.PhysIDSupplied

WHEN MCP2.Physician_Key = -2 THEN MCP2.PhysIDSupplied

WHEN DP2.NPI is not Null THEN convert(varchar(50),DP2.NPI)

WHEN DP2.NPI is Null AND DP2.t_TMP_License_Number is not Null THEN convert(varchar(50),DP2.t_TMP_License_Number)

ELSE convert(varchar(50),DP2.t_UPIN)

END

AS OprPhysID,   

CASE 

WHEN MCP1.Physician_Key = -1 THEN ''Yes'' 

WHEN MCP1.Physician_Key = -2 THEN ''Yes'' 

ELSE ''No'' 

END

AS AttendingPhysicianMissing,

CASE 

WHEN MCP2.Physician_Key = -1 THEN ''Yes'' 

WHEN MCP2.Physician_Key = -2 THEN ''Yes'' 

ELSE ''No'' 

END

AS OperatingPhysicianMissing,

NYU.dxgroup,
NYU.ne,
NYU.epct,
NYU.edcnpa,
NYU.edcnnpa,
NYU.injury,
NYU.psych,
NYU.alcohol,
NYU.drug,
NYU.unclassified,
NYU.DiagClass


--into qlikView

FROM IQSC_DataWarehouse.dbo.DimClaim DC (nolock)

LEFT JOIN IQSC_DataWarehouse.dbo.FACT_CLAIM FC(nolock)
ON FC.Claim_Key = DC.Claim_Key

LEFT JOIN IQSC_DataWarehouse.dbo.Dim_MS_DRG drg (nolock)
ON drg.DRG_Key = fc.DRG_Key

LEFT JOIN IQSC_DataWarehouse.dbo.Dim_APR_DRG adrg (nolock)
ON adrg.APR_DRG_Key = fc.APR_DRG_Key

LEFT JOIN IQSC_DataWarehouse.dbo.FACT_IQSC_PUDF_Blinded Blind (nolock)
ON Blind.Claim_Key = DC.Claim_Key

LEFT JOIN IQSC_DataWarehouse.dbo.FACT_IQSC_PUDF_Computed fipc (nolock)
ON fipc.Claim_Key = DC.Claim_Key

--LEFT JOIN IQSC_DataWarehouse.EncounterGrouping.GrouperResults r (nolock)
--ON r.Claim_Key = dc.Claim_Key AND r.GrouperType = ''apr''

--LEFT JOIN IQSC_DataWarehouse.EncounterGrouping.GrouperResults r2 (nolock)
--ON r2.Claim_Key = dc.Claim_Key AND r.GrouperType = ''cms''

LEFT JOIN IQSC_DataWarehouse.dbo.FACT_IQSC_PUDF_MedPar fipm (nolock)
ON fipm.Claim_Key = DC.Claim_Key

LEFT JOIN IQSC_DataWarehouse.dbo.DimClaimPatient DCP (nolock)
ON dcp.Claim_Key = DC.Claim_Key

LEFT JOIN IQSC_DataWarehouse.dbo.DimAdmitType at (nolock)
ON at.AdmitType_Key = FC.AdmitType_Key

LEFT JOIN IQSC_DataWarehouse.dbo.DimAdmitSource DAS (nolock)
ON DAS.AdmitSource_Key = FC.AdmitSource_Key

LEFT JOIN IQSC_DataWarehouse.dbo.Map_Claim_ICD_Diagnosis admit (nolock)
ON admit.Claim_Key = DC.Claim_Key AND admit.DiagnosisSequence = 0

LEFT JOIN IQSC_DataWarehouse.dbo.DimDiagnosis AdmitDiag (nolock)
ON AdmitDiag.Diagnosis_Key = admit.Diagnosis_Key

LEFT JOIN IQSC_DataWarehouse.dbo.FACT_Claim_HighestChargeProcedure HCP (nolock)
ON HCP.Claim_Key = DC.Claim_Key

LEFT JOIN IQSC_DataWarehouse.dbo.Map_Claim_ICD_Diagnosis MCID (nolock)
ON MCID.Claim_Key = DC.Claim_Key AND MCID.PrincipleDiagnosis = 1

LEFT JOIN IQSC_DataWarehouse.dbo.DimDiagnosis D (nolock)
ON D.Diagnosis_Key = MCID.Diagnosis_Key

LEFT JOIN IQSC_DataWarehouse.dbo.Map_Claim_ICD_Procedure MCIP (nolock)
ON MCIP.Claim_Key = DC.Claim_Key AND PrincipleProcedure = 1 AND Procedure_Key <> -1

LEFT JOIN IQSC_DataWarehouse.dbo.DimProcedure DP (nolock)
ON DP.Procedure_Key = MCIP.Procedure_Key

LEFT JOIN IQSC_DataWarehouse.dbo.Dim_HCPCS_Procedure HP (nolock)
ON HP.HCPCS_ProcedureCode = HCP.HCPCS_ProcedureCode

LEFT JOIN IQSC_DataWarehouse.dbo.Dim_LOS_Group LOS (nolock)
ON FC.LOS BETWEEN LOS.LowerLOS AND LOS.UpperLOS

LEFT JOIN IQSC_DataWarehouse.dbo.DimDischargeStatus DDS (nolock)
ON FC.DischargeStatus_Key = DDS.DischargeStatus_Key

LEFT JOIN IQSC_DataWarehouse.dbo.DimHospital DH (nolock)
ON DC.Hospital_Key = DH.Hospital_Key

LEFT JOIN IQSC_DataWarehouse.dbo.Dim_CPT4_ProductLine CPT (nolock)
ON CPT.CPT_Code = HCP.HCPCS_ProcedureCode

LEFT JOIN IQSC_DataWarehouse.dbo.Map_Claim_Physician MCP1 (nolock)
ON MCP1.Claim_Key = DC.Claim_Key AND MCP1.PhysicianRole_Key = 1

LEFT JOIN IQSC_DataWarehouse.dbo.Map_Claim_Physician MCP2 (nolock)
ON MCP2.Claim_Key = DC.Claim_Key AND MCP2.PhysicianRole_Key = 2

LEFT JOIN IQSC_DataWarehouse.dbo.DimPhysician DP1 (nolock)
ON DP1.Physician_Key = MCP1.Physician_Key

LEFT JOIN IQSC_DataWarehouse.dbo.DimPhysician DP2 (nolock)
ON DP2.Physician_Key = MCP2.Physician_Key

LEFT JOIN IQSC_DataWarehouse.NYU_LOAD.NYUER_OUT_PUDF NYU (nolock)
ON NYU.Claim_Key = DC.Claim_Key

LEFT JOIN  IQSC_DataWarehouse.NPIData.ProviderLicense NPI (nolock)
ON NPI.NPI = DP1.NPI AND NPI.Healthcare_Provider_Primary_Taxonomy_Switch = ''Y'' AND NPI.Provider_License_Number_State_Code = ''TX''

LEFT JOIN  IQSC_DataWarehouse.Legacy.TaxonomyCodeMaster TCM (nolock)
ON TCM.TaxonomyCode = NPI.Healthcare_Provider_Taxonomy_Code

LEFT JOIN IQSC_DataWarehouse.dbo.DimDate DD (nolock)
ON DD.DateValue = DC.DischargeDate

LEFT JOIN IQSC_DataWarehouse.dbo.Dim_Diag_ProductLine_THR THR (nolock)
ON THR.Code_no_Decimal = D.DiagnosisCode

LEFT JOIN  IQSC_DataWarehouse.dbo.vw_QV_DiagProcCodesInp  DPC (nolock)
ON DPC.DFWHCID = DC.Claim_Key 

LEFT JOIN  IQSC_DataWarehouse.CCS_Working.DXREF_2013_working ccs (nolock)
ON ccs.[ICD-9-CM CODE] = D.DiagnosisCode

LEFT JOIN  IQSC_DataWarehouse.CCS_Working.ccs_multi_dx_tool_2013 ccsdx (nolock)
ON ccsdx.[ICD-9-CM CODE] = D.DiagnosisCode

--LEFT JOIN  IQSC_DataWarehouse.dbo.vw_QV_BITS bits (nolock)
--ON bits.Claim_Key = dc.Claim_Key

LEFT JOIN IQSC_DataWarehouse.dbo.vw_QV_ER_Out_Acuity acu (nolock)
ON acu.Claim_Key = dc.Claim_Key

LEFT JOIN IQSC_DataWarehouse.dbo.vw_QV_Mortality mor (nolock)
ON mor.Claim_Key = dc.Claim_Key

LEFT JOIN  IQSC_DataWarehouse.dbo.vw_QV_CodePosFilledDiag cpfd (nolock)
ON cpfd.Claim_Key = dc.Claim_Key

LEFT JOIN  IQSC_DataWarehouse.dbo.vw_QV_CodePosFilledProc cpfp (nolock)
ON cpfp.Claim_Key = dc.Claim_Key


                
WHERE

DC.PrimaryRecord = 1
AND DC.ClaimStatusCode NOT IN (''X'',''V'')
AND DC.DischargeQuarter BETWEEN 200801 AND 201004

--AND dc.SubmissionPurpose = ''O''
--AND DD.[Month] = 201012
--AND dc.Hospital_Key = 15


GO



', 
		@database_name=N'IQSC_DataWarehouse', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Load Tables]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Load Tables', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec dbo.sp_LoadQlikViewTable', 
		@database_name=N'IQSC_DataWarehouse', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Load Qlik View', 
		@enabled=1, 
		@freq_type=16, 
		@freq_interval=12, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20140328, 
		@active_end_date=99991231, 
		@active_start_time=233000, 
		@active_end_time=235959, 
		@schedule_uid=N'f0d4fd36-cba8-4d02-b039-df2cb023c1a2'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [QlikVIew LOAd Monthly]    Script Date: 12/31/2015 08:46:44 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:44 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'QlikVIew LOAd Monthly', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\pyalavarthy', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Qlik View Load Monthly]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Qlik View Load Monthly', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'drop table qlikView


SELECT  

1 AS CaseCnt,

DC.Claim_Key,

DD.[Quarter] ''DISCHQTR'',

DD.[Year] ''YEAR'',

DD.[Month] DschrgMnth,

DD.MonthAbr MnthName,

dd.MonthOfYear Mnth,

Blind.Hospital_Key,

fipc.SpecUnit1 ''SPECUNIT1'',

fipc.SpecUnit2 ''SPECUNIT2'',

Blind.SexCode ''SEXCODE'',

at.AdmitTypeCode ''ADMTYPE'',

DAS.AdmitSourceCode ''ADMSOURCE'',

cast (Blind.ZipCode AS VARCHAR) ''ZIPCODE'',

cast (Blind.State AS VARCHAR) ''STATE'',

Blind.County ''COUNTY'',

cast (dds.DischargeStatusCode AS VARCHAR) ''STATUS'',

cast (Blind.Race AS VARCHAR) ''RACE'',

cast (Blind.Ethnicity AS VARCHAR) ''ETHNICIT'',

DC.BillTypeCode ''BILLTYPE'',

AdmitDiag.DiagnosisShortDesc ''ADMCODE'',

cast (FC.LOS AS VARCHAR) ''LOS'',

cast (fipc.DILOS AS VARCHAR) ''DILOS'',

DATEPART (DW, DC.AdmitDate) ''ADMWEEKD'',

cast (FC.AdmitAge AS VARCHAR) ''AGE'',

FC.AdmitAgeDays AS ''AGEDAYS'',

r.GrouperVersionUsed ''VERSION'',

--fipc.DRG_Error AS ''ERROR'',

substring(convert(char(4),r.MDC + 100),2,2) ''APR_MDC'',

substring(convert(char(4),r.DRG + 1000),2,3) ''APR_DRG'',

r.RiskOfMortality AS ''RM'',

Case When fipc.IS_Emergency = 0 Then ''0'' ELSE ''1'' END AS IS_Emergency,

Case When fipc.IS_ObservationRoom = 0 Then ''0'' ELSE ''1'' END AS IS_ObservationRoom,

Case When fipc.IS_OperatingRoom = 0 Then ''0'' ELSE ''1'' END AS IS_OperatingRoom,

Case When fipc.IS_OutpatientProcedure = 0 Then ''0'' ELSE ''1'' END AS IS_OutpatientProcedure,

r.SeverityOfIllness ''SEV'',

FC.TotalCharges ''TOTALCHG'',

FC.AncillaryCharges ''T_ANCCHG'',

FC.AccomodationCharges ''T_ACCCHG'',

fipm.PRIVCHG cPRIVCHG,

fipm.SPRIVCHG cSPRIVCHG,

fipm.WARDCHG cWARDCHG,

fipm.ICUCHG cICUCHG,

fipm.CCUCHG cCCUCHG,

fipm.OTHANCHG cOTHANCHG,

fipm.PHARMCHG cPHARMCHG,

fipm.MEDSRGCH cMEDSRGCH,

fipm.DMECHG cDMECHG,

fipm.UDMECHG cUDMECHG,

fipm.PTCHG cPTCHG,

fipm.OTCHG cOTCHG,

fipm.SPEECHCH cSPEECHCH,

fipm.INHTXCHG cINHTXCHG,

fipm.BLOODCHG cBLOODCHG,

fipm.BLDADMCH cBLDADMCH,

fipm.ORCHG cORCHG,

fipm.LITHCHG cLITHCHG,

fipm.CARDCHG cCARDCHG,

fipm.ANESCHG cANESCHG,

fipm.LABCHG cLABCHG,

fipm.RADIOCHG cRADIOCHG,

fipm.MRICHG cMRICHG,

fipm.OPSRVCHG cOPSRVCHG,

fipm.ERCHG cERCHG,

fipm.AMBULCHG cAMBULCHG,

fipm.PROFEECH cPROFEECH,

fipm.ORGANCHG cORGANCHG,

fipm.ESRDCHG cESRDCHG,

fipm.CLINICCH cCLINICCH,

--fipc.APG,

FC.PayCode1 AS ''CLAIMFILINDCODE1'',

FC.PayCode2 AS ''CLAIMFILINDCODE2'',

FC.PayCode3 AS ''CLAIMFILINDCODE3'',

DC.SubmissionPurpose AS ''SubmissionPurpose'',

fipc.IS_Emergency AS EmergentFlag,

acu.Acuity,

cpfd.DiagPosCnt,

cpfp.ProcPosCnt,

THR.Product_line_name AS DiagProdLine,

THR.[3_digit_name] AS DiagProdSub,

ccs.[CCS CATEGORY DESCRIPTION] AS CCS_Category,

ccsdx.[CCS LVL 1 LABEL] AS CCS_Label1,

ccsdx.[CCS LVL 2 LABEL] AS CCS_Label2, 

D.DiagnosisCode_Decimal AS PrincipleDiagnosisCode,

D.Diagnosis AS PrincipleDiagnosis,

COALESCE (DP.ProcedureCode_Decimal, '''') AS PrinicpleProcedureCode,

COALESCE (DP.[Procedure], '''') AS PrincipleProcedure,

CASE WHEN MCID.DiagnosisSequence > 1 THEN ''1'' ELSE ''0'' END

AS SecondaryDiagnosis,

DPC.ECode01,   

DPC.ECode02,

DPC.ECode03,

DPC.Diag02,

DPC.Diag03,

DPC.Diag04,

DPC.Diag05,

DPC.Diag06,

DPC.Diag07,

DPC.Diag08,

DPC.Diag09,

DPC.Diag10,

DPC.Proc02,

DPC.Proc03,

DPC.Proc04,

DPC.Proc05,

DPC.Proc06,

DPC.Proc07,

DPC.Proc08,

DPC.Proc09,

DPC.Proc10,

FC.AdmitSource_Key,

FC.AdmitType_Key,

fipc.AGE AS AgeGroupCode,

--FC.APR_DRG_Key,

DC.BillTypeCode,

DC.ClaimStatusCode,

DC.DischargeDate,

DC.DischargeQuarter,

--FC.DRG_Key,
substring(convert(char(4),r2.DRG + 1000),2,3) ''DRG'',

FC.EthnicityCode,

FC.FacilityType_Key,

FC.RaceCode,

r.RiskOfMortality,

r.SeverityOfIllness ''Severity'',

FC.Sex,

CASE WHEN DDS.DischargeStatusCode IN (''20'', ''40'', ''41'', ''41'') THEN 1 ELSE 0 END AS Mortality,

mor.DeathFlag,

mor.MortalityStatus,

mor.NoDaysLive,

mor.LiveDaysAD,

DH.Ownership,

DH.Bedsize,

DH.CriticalAccess,

DH.Zip,

DH.County AS HospitalCounty,

HCP.HCPCS_ProcedureCode,

HP.HCPCS_ProcedureDesc,

CPT.OP_ProductLine AS CPT_ProductLine,

LOS.LOSGroupName,

CASE WHEN MCP1.Physician_Key = -1 THEN MCP1.PhysNameSupplied WHEN MCP1.Physician_Key = -2 THEN MCP1.PhysNameSupplied ELSE DP1.FullName END AS AttendingPhysician,

CASE WHEN MCP1.Physician_Key = -1 THEN MCP1.PhysIDSupplied WHEN MCP1.Physician_Key = -2 THEN MCP1.PhysIDSupplied WHEN DP1.NPI is not Null THEN convert(varchar(50),DP1.NPI) WHEN DP1.NPI is Null AND DP1.t_TMP_License_Number is not Null THEN convert(varchar(50),DP1.t_TMP_License_Number) ELSE convert(varchar(50),DP1.t_UPIN) END AS AttPhysID,

NPI.Healthcare_Provider_Taxonomy_Code AS TaxCode,

TCM.PracticeSpecialty,

TCM.Specialization,

CASE WHEN MCP2.Physician_Key = -1 THEN MCP2.PhysNameSupplied WHEN MCP2.Physician_Key = -2 THEN MCP2.PhysNameSupplied ELSE DP2.FullName END AS OperatingPhysician,

CASE WHEN MCP2.Physician_Key = -1 THEN MCP2.PhysIDSupplied WHEN MCP2.Physician_Key = -2 THEN MCP2.PhysIDSupplied WHEN DP2.NPI is not Null THEN convert(varchar(50),DP2.NPI) WHEN DP2.NPI is Null AND DP2.t_TMP_License_Number is not Null THEN convert(varchar(50),DP2.t_TMP_License_Number) ELSE convert(varchar(50),DP2.t_UPIN) END AS OprPhysID,   

CASE WHEN MCP1.Physician_Key = -1 THEN ''Yes'' WHEN MCP1.Physician_Key = -2 THEN ''Yes'' ELSE ''No'' END AS AttendingPhysicianMissing,

CASE WHEN MCP2.Physician_Key = -1 THEN ''Yes'' WHEN MCP2.Physician_Key = -2 THEN ''Yes'' ELSE ''No'' END AS OperatingPhysicianMissing,

NYU.dxgroup,
NYU.ne,
NYU.epct,
NYU.edcnpa,
NYU.edcnnpa,
NYU.injury,
NYU.psych,
NYU.alcohol,
NYU.drug,
NYU.unclassified,
NYU.DiagClass

--into qlikView

FROM IQSC_DataWarehouse.dbo.DimClaim DC (nolock)

LEFT JOIN IQSC_DataWarehouse.dbo.FACT_CLAIM FC(nolock)
ON FC.Claim_Key = DC.Claim_Key

--LEFT JOIN IQSC_DataWarehouse.dbo.Dim_MS_DRG drg (nolock)
--ON drg.DRG_Key = fc.DRG_Key

LEFT JOIN IQSC_DataWarehouse.dbo.FACT_IQSC_PUDF_Blinded Blind (nolock)
ON Blind.Claim_Key = DC.Claim_Key

LEFT JOIN IQSC_DataWarehouse.dbo.FACT_IQSC_PUDF_Computed fipc (nolock)
ON fipc.Claim_Key = DC.Claim_Key

LEFT JOIN IQSC_DataWarehouse.EncounterGrouping.GrouperResults r (nolock)
ON r.Claim_Key = dc.Claim_Key AND r.GrouperType = ''apr''

LEFT JOIN IQSC_DataWarehouse.EncounterGrouping.GrouperResults r2 (nolock)
ON r2.Claim_Key = dc.Claim_Key AND r.GrouperType = ''cms''

LEFT JOIN IQSC_DataWarehouse.dbo.FACT_IQSC_PUDF_MedPar fipm (nolock)
ON fipm.Claim_Key = DC.Claim_Key

LEFT JOIN IQSC_DataWarehouse.dbo.DimClaimPatient DCP (nolock)
ON dcp.Claim_Key = DC.Claim_Key

LEFT JOIN IQSC_DataWarehouse.dbo.DimAdmitType at (nolock)
ON at.AdmitType_Key = FC.AdmitType_Key

LEFT JOIN IQSC_DataWarehouse.dbo.DimAdmitSource DAS (nolock)
ON DAS.AdmitSource_Key = FC.AdmitSource_Key

LEFT JOIN IQSC_DataWarehouse.dbo.Map_Claim_ICD_Diagnosis admit (nolock)
ON admit.Claim_Key = DC.Claim_Key AND admit.DiagnosisSequence = 0

LEFT JOIN IQSC_DataWarehouse.dbo.DimDiagnosis AdmitDiag (nolock)
ON AdmitDiag.Diagnosis_Key = admit.Diagnosis_Key

LEFT JOIN IQSC_DataWarehouse.dbo.FACT_Claim_HighestChargeProcedure HCP (nolock)
ON HCP.Claim_Key = DC.Claim_Key

LEFT JOIN IQSC_DataWarehouse.dbo.Map_Claim_ICD_Diagnosis MCID (nolock)
ON MCID.Claim_Key = DC.Claim_Key AND MCID.PrincipleDiagnosis = 1

LEFT JOIN IQSC_DataWarehouse.dbo.DimDiagnosis D (nolock)
ON D.Diagnosis_Key = MCID.Diagnosis_Key

LEFT JOIN IQSC_DataWarehouse.dbo.Map_Claim_ICD_Procedure MCIP (nolock)
ON MCIP.Claim_Key = DC.Claim_Key AND PrincipleProcedure = 1 AND Procedure_Key <> -1

LEFT JOIN IQSC_DataWarehouse.dbo.DimProcedure DP (nolock)
ON DP.Procedure_Key = MCIP.Procedure_Key

LEFT JOIN IQSC_DataWarehouse.dbo.Dim_HCPCS_Procedure HP (nolock)
ON HP.HCPCS_ProcedureCode = HCP.HCPCS_ProcedureCode

LEFT JOIN IQSC_DataWarehouse.dbo.Dim_LOS_Group LOS (nolock)
ON FC.LOS BETWEEN LOS.LowerLOS AND LOS.UpperLOS

LEFT JOIN IQSC_DataWarehouse.dbo.DimDischargeStatus DDS (nolock)
ON FC.DischargeStatus_Key = DDS.DischargeStatus_Key

LEFT JOIN IQSC_DataWarehouse.dbo.DimHospital DH (nolock)
ON DC.Hospital_Key = DH.Hospital_Key

LEFT JOIN IQSC_DataWarehouse.dbo.Dim_CPT4_ProductLine CPT (nolock)
ON CPT.CPT_Code = HCP.HCPCS_ProcedureCode

LEFT JOIN IQSC_DataWarehouse.dbo.Map_Claim_Physician MCP1 (nolock)
ON MCP1.Claim_Key = DC.Claim_Key AND MCP1.PhysicianRole_Key = 1

LEFT JOIN IQSC_DataWarehouse.dbo.Map_Claim_Physician MCP2 (nolock)
ON MCP2.Claim_Key = DC.Claim_Key AND MCP2.PhysicianRole_Key = 2

LEFT JOIN IQSC_DataWarehouse.dbo.DimPhysician DP1 (nolock)
ON DP1.Physician_Key = MCP1.Physician_Key

LEFT JOIN IQSC_DataWarehouse.dbo.DimPhysician DP2 (nolock)
ON DP2.Physician_Key = MCP2.Physician_Key

LEFT JOIN IQSC_DataWarehouse.NYU_LOAD.NYUER_OUT_PUDF NYU (nolock)
ON NYU.Claim_Key = DC.Claim_Key

LEFT JOIN  IQSC_DataWarehouse.NPIData.ProviderLicense NPI (nolock)
ON NPI.NPI = DP1.NPI AND NPI.Healthcare_Provider_Primary_Taxonomy_Switch = ''Y'' AND NPI.Provider_License_Number_State_Code = ''TX''

LEFT JOIN  IQSC_DataWarehouse.Legacy.TaxonomyCodeMaster TCM (nolock)
ON TCM.TaxonomyCode = NPI.Healthcare_Provider_Taxonomy_Code

LEFT JOIN IQSC_DataWarehouse.dbo.DimDate DD (nolock)
ON DD.DateValue = DC.DischargeDate

LEFT JOIN IQSC_DataWarehouse.dbo.Dim_Diag_ProductLine_THR THR (nolock)
ON THR.Code_no_Decimal = D.DiagnosisCode

LEFT JOIN  IQSC_DataWarehouse.dbo.vw_QV_DiagProcCodesInp  DPC (nolock)
ON DPC.DFWHCID = DC.Claim_Key 

LEFT JOIN  IQSC_DataWarehouse.CCS_Working.DXREF_2013_working ccs (nolock)
ON ccs.[ICD-9-CM CODE] = D.DiagnosisCode

LEFT JOIN  IQSC_DataWarehouse.CCS_Working.ccs_multi_dx_tool_2013 ccsdx (nolock)
ON ccsdx.[ICD-9-CM CODE] = D.DiagnosisCode

--LEFT JOIN  IQSC_DataWarehouse.dbo.vw_QV_BITS bits (nolock)
--ON bits.Claim_Key = dc.Claim_Key

LEFT JOIN IQSC_DataWarehouse.dbo.vw_QV_ER_Out_Acuity acu (nolock)
ON acu.Claim_Key = dc.Claim_Key

LEFT JOIN IQSC_DataWarehouse.dbo.vw_QV_Mortality mor (nolock)
ON mor.Claim_Key = dc.Claim_Key

LEFT JOIN  IQSC_DataWarehouse.dbo.vw_QV_CodePosFilledDiag cpfd (nolock)
ON cpfd.Claim_Key = dc.Claim_Key

LEFT JOIN  IQSC_DataWarehouse.dbo.vw_QV_CodePosFilledProc cpfp (nolock)
ON cpfp.Claim_Key = dc.Claim_Key


                
WHERE

DC.PrimaryRecord = 1
AND DC.ClaimStatusCode NOT IN (''X'',''V'')
AND DC.DischargeQuarter >= 201101 

--AND dc.SubmissionPurpose = ''I''
--AND DD.[Month] = 201403
--AND dc.Hospital_Key = 15




UNION




SELECT  

1 AS CaseCnt,

DC.Claim_Key,

DD.[Quarter] ''DISCHQTR'',

DD.[Year] ''YEAR'',

DD.[Month] DschrgMnth,

DD.MonthAbr MnthName,

dd.MonthOfYear Mnth,

Blind.Hospital_Key,

fipc.SpecUnit1 ''SPECUNIT1'',

fipc.SpecUnit2 ''SPECUNIT2'',

Blind.SexCode ''SEXCODE'',

at.AdmitTypeCode ''ADMTYPE'',

DAS.AdmitSourceCode ''ADMSOURCE'',

cast (Blind.ZipCode AS VARCHAR) ''ZIPCODE'',

cast (Blind.State AS VARCHAR) ''STATE'',

Blind.County ''COUNTY'',

cast (dds.DischargeStatusCode AS VARCHAR) ''STATUS'',

cast (Blind.Race AS VARCHAR) ''RACE'',

cast (Blind.Ethnicity AS VARCHAR) ''ETHNICIT'',

DC.BillTypeCode ''BILLTYPE'',

AdmitDiag.DiagnosisShortDesc ''ADMCODE'',

cast (FC.LOS AS VARCHAR) ''LOS'',

cast (fipc.DILOS AS VARCHAR) ''DILOS'',

DATEPART (DW, DC.AdmitDate) ''ADMWEEKD'',

cast (FC.AdmitAge AS VARCHAR) ''AGE'',

FC.AdmitAgeDays AS ''AGEDAYS'',

fipc.APR_DRG_Version AS ''VERSION'',

--fipc.DRG_Error AS ''ERROR'',

adrg.MDC AS ''APR_MDC'',

adrg.APR_DRG,

fc.RiskOfMortality AS ''RM'',

Case When fipc.IS_Emergency = 0 Then ''0'' ELSE ''1'' END AS IS_Emergency,

Case When fipc.IS_ObservationRoom = 0 Then ''0'' ELSE ''1'' END AS IS_ObservationRoom,

Case When fipc.IS_OperatingRoom = 0 Then ''0'' ELSE ''1'' END AS IS_OperatingRoom,

Case When fipc.IS_OutpatientProcedure = 0 Then ''0'' ELSE ''1'' END AS IS_OutpatientProcedure,

fc.Severity AS ''SEV'',

FC.TotalCharges ''TOTALCHG'',

FC.AncillaryCharges ''T_ANCCHG'',

FC.AccomodationCharges ''T_ACCCHG'',

fipm.PRIVCHG cPRIVCHG,

fipm.SPRIVCHG cSPRIVCHG,

fipm.WARDCHG cWARDCHG,

fipm.ICUCHG cICUCHG,

fipm.CCUCHG cCCUCHG,

fipm.OTHANCHG cOTHANCHG,

fipm.PHARMCHG cPHARMCHG,

fipm.MEDSRGCH cMEDSRGCH,

fipm.DMECHG cDMECHG,

fipm.UDMECHG cUDMECHG,

fipm.PTCHG cPTCHG,

fipm.OTCHG cOTCHG,

fipm.SPEECHCH cSPEECHCH,

fipm.INHTXCHG cINHTXCHG,

fipm.BLOODCHG cBLOODCHG,

fipm.BLDADMCH cBLDADMCH,

fipm.ORCHG cORCHG,

fipm.LITHCHG cLITHCHG,

fipm.CARDCHG cCARDCHG,

fipm.ANESCHG cANESCHG,

fipm.LABCHG cLABCHG,

fipm.RADIOCHG cRADIOCHG,

fipm.MRICHG cMRICHG,

fipm.OPSRVCHG cOPSRVCHG,

fipm.ERCHG cERCHG,

fipm.AMBULCHG cAMBULCHG,

fipm.PROFEECH cPROFEECH,

fipm.ORGANCHG cORGANCHG,

fipm.ESRDCHG cESRDCHG,

fipm.CLINICCH cCLINICCH,

--fipc.APG,

FC.PayCode1 AS ''CLAIMFILINDCODE1'',

FC.PayCode2 AS ''CLAIMFILINDCODE2'',

FC.PayCode3 AS ''CLAIMFILINDCODE3'',

DC.SubmissionPurpose AS ''SubmissionPurpose'',

fipc.IS_Emergency AS EmergentFlag,

--bits.IS_Cardiology,

--bits.IS_AmbSurg,

--bits.IS_GastroInt,

--bits.IS_Radiology,

--bits.IS_Trauma,

acu.Acuity,

cpfd.DiagPosCnt,

cpfp.ProcPosCnt,

THR.Product_line_name AS DiagProdLine,

THR.[3_digit_name] AS DiagProdSub,

ccs.[CCS CATEGORY DESCRIPTION] AS CCS_Category,

ccsdx.[CCS LVL 1 LABEL] AS CCS_Label1,

ccsdx.[CCS LVL 2 LABEL] AS CCS_Label2, 

D.DiagnosisCode_Decimal AS PrincipleDiagnosisCode,

D.Diagnosis AS PrincipleDiagnosis,

COALESCE (DP.ProcedureCode_Decimal, '''') AS PrinicpleProcedureCode,

COALESCE (DP.[Procedure], '''') AS PrincipleProcedure,

CASE WHEN MCID.DiagnosisSequence > 1 THEN ''1'' ELSE ''0'' END

AS SecondaryDiagnosis,

DPC.ECode01,   

DPC.ECode02,

DPC.ECode03,

DPC.Diag02,

DPC.Diag03,

DPC.Diag04,

DPC.Diag05,

DPC.Diag06,

DPC.Diag07,

DPC.Diag08,

DPC.Diag09,

DPC.Diag10,

DPC.Proc02,

DPC.Proc03,

DPC.Proc04,

DPC.Proc05,

DPC.Proc06,

DPC.Proc07,

DPC.Proc08,

DPC.Proc09,

DPC.Proc10,

FC.AdmitSource_Key,

FC.AdmitType_Key,

fipc.AGE AS AgeGroupCode,

--adrg.APR_DRG,

DC.BillTypeCode,

DC.ClaimStatusCode,

DC.DischargeDate,

DC.DischargeQuarter,

--FC.DRG_Key,
drg.DRG,

FC.EthnicityCode,

FC.FacilityType_Key,

FC.RaceCode,

FC.RiskOfMortality,

FC.Severity,

FC.Sex,

CASE

WHEN DDS.DischargeStatusCode IN (''20'', ''40'', ''41'', ''41'') THEN 1

ELSE 0

END

AS Mortality,

mor.DeathFlag,

mor.MortalityStatus,

mor.NoDaysLive,

mor.LiveDaysAD,

DH.Ownership,

DH.Bedsize,

DH.CriticalAccess,

DH.Zip,

DH.County AS HospitalCounty,

HCP.HCPCS_ProcedureCode,

HP.HCPCS_ProcedureDesc,

CPT.OP_ProductLine AS CPT_ProductLine,

LOS.LOSGroupName,

CASE

WHEN MCP1.Physician_Key = -1 THEN MCP1.PhysNameSupplied

WHEN MCP1.Physician_Key = -2 THEN MCP1.PhysNameSupplied

ELSE DP1.FullName

END

AS AttendingPhysician,

CASE

WHEN MCP1.Physician_Key = -1 THEN MCP1.PhysIDSupplied

WHEN MCP1.Physician_Key = -2 THEN MCP1.PhysIDSupplied

WHEN DP1.NPI is not Null THEN convert(varchar(50),DP1.NPI)

WHEN DP1.NPI is Null AND DP1.t_TMP_License_Number is not Null THEN convert(varchar(50),DP1.t_TMP_License_Number)

ELSE convert(varchar(50),DP1.t_UPIN)

END

AS AttPhysID,

NPI.Healthcare_Provider_Taxonomy_Code AS TaxCode,

TCM.PracticeSpecialty,

TCM.Specialization,



CASE

WHEN MCP2.Physician_Key = -1 THEN MCP2.PhysNameSupplied

WHEN MCP2.Physician_Key = -2 THEN MCP2.PhysNameSupplied

ELSE DP2.FullName

END

AS OperatingPhysician,

CASE

WHEN MCP2.Physician_Key = -1 THEN MCP2.PhysIDSupplied

WHEN MCP2.Physician_Key = -2 THEN MCP2.PhysIDSupplied

WHEN DP2.NPI is not Null THEN convert(varchar(50),DP2.NPI)

WHEN DP2.NPI is Null AND DP2.t_TMP_License_Number is not Null THEN convert(varchar(50),DP2.t_TMP_License_Number)

ELSE convert(varchar(50),DP2.t_UPIN)

END

AS OprPhysID,   

CASE 

WHEN MCP1.Physician_Key = -1 THEN ''Yes'' 

WHEN MCP1.Physician_Key = -2 THEN ''Yes'' 

ELSE ''No'' 

END

AS AttendingPhysicianMissing,

CASE 

WHEN MCP2.Physician_Key = -1 THEN ''Yes'' 

WHEN MCP2.Physician_Key = -2 THEN ''Yes'' 

ELSE ''No'' 

END

AS OperatingPhysicianMissing,

NYU.dxgroup,
NYU.ne,
NYU.epct,
NYU.edcnpa,
NYU.edcnnpa,
NYU.injury,
NYU.psych,
NYU.alcohol,
NYU.drug,
NYU.unclassified,
NYU.DiagClass


--into qlikView

FROM IQSC_DataWarehouse.dbo.DimClaim DC (nolock)

LEFT JOIN IQSC_DataWarehouse.dbo.FACT_CLAIM FC(nolock)
ON FC.Claim_Key = DC.Claim_Key

LEFT JOIN IQSC_DataWarehouse.dbo.Dim_MS_DRG drg (nolock)
ON drg.DRG_Key = fc.DRG_Key

LEFT JOIN IQSC_DataWarehouse.dbo.Dim_APR_DRG adrg (nolock)
ON adrg.APR_DRG_Key = fc.APR_DRG_Key

LEFT JOIN IQSC_DataWarehouse.dbo.FACT_IQSC_PUDF_Blinded Blind (nolock)
ON Blind.Claim_Key = DC.Claim_Key

LEFT JOIN IQSC_DataWarehouse.dbo.FACT_IQSC_PUDF_Computed fipc (nolock)
ON fipc.Claim_Key = DC.Claim_Key

--LEFT JOIN IQSC_DataWarehouse.EncounterGrouping.GrouperResults r (nolock)
--ON r.Claim_Key = dc.Claim_Key AND r.GrouperType = ''apr''

--LEFT JOIN IQSC_DataWarehouse.EncounterGrouping.GrouperResults r2 (nolock)
--ON r2.Claim_Key = dc.Claim_Key AND r.GrouperType = ''cms''

LEFT JOIN IQSC_DataWarehouse.dbo.FACT_IQSC_PUDF_MedPar fipm (nolock)
ON fipm.Claim_Key = DC.Claim_Key

LEFT JOIN IQSC_DataWarehouse.dbo.DimClaimPatient DCP (nolock)
ON dcp.Claim_Key = DC.Claim_Key

LEFT JOIN IQSC_DataWarehouse.dbo.DimAdmitType at (nolock)
ON at.AdmitType_Key = FC.AdmitType_Key

LEFT JOIN IQSC_DataWarehouse.dbo.DimAdmitSource DAS (nolock)
ON DAS.AdmitSource_Key = FC.AdmitSource_Key

LEFT JOIN IQSC_DataWarehouse.dbo.Map_Claim_ICD_Diagnosis admit (nolock)
ON admit.Claim_Key = DC.Claim_Key AND admit.DiagnosisSequence = 0

LEFT JOIN IQSC_DataWarehouse.dbo.DimDiagnosis AdmitDiag (nolock)
ON AdmitDiag.Diagnosis_Key = admit.Diagnosis_Key

LEFT JOIN IQSC_DataWarehouse.dbo.FACT_Claim_HighestChargeProcedure HCP (nolock)
ON HCP.Claim_Key = DC.Claim_Key

LEFT JOIN IQSC_DataWarehouse.dbo.Map_Claim_ICD_Diagnosis MCID (nolock)
ON MCID.Claim_Key = DC.Claim_Key AND MCID.PrincipleDiagnosis = 1

LEFT JOIN IQSC_DataWarehouse.dbo.DimDiagnosis D (nolock)
ON D.Diagnosis_Key = MCID.Diagnosis_Key

LEFT JOIN IQSC_DataWarehouse.dbo.Map_Claim_ICD_Procedure MCIP (nolock)
ON MCIP.Claim_Key = DC.Claim_Key AND PrincipleProcedure = 1 AND Procedure_Key <> -1

LEFT JOIN IQSC_DataWarehouse.dbo.DimProcedure DP (nolock)
ON DP.Procedure_Key = MCIP.Procedure_Key

LEFT JOIN IQSC_DataWarehouse.dbo.Dim_HCPCS_Procedure HP (nolock)
ON HP.HCPCS_ProcedureCode = HCP.HCPCS_ProcedureCode

LEFT JOIN IQSC_DataWarehouse.dbo.Dim_LOS_Group LOS (nolock)
ON FC.LOS BETWEEN LOS.LowerLOS AND LOS.UpperLOS

LEFT JOIN IQSC_DataWarehouse.dbo.DimDischargeStatus DDS (nolock)
ON FC.DischargeStatus_Key = DDS.DischargeStatus_Key

LEFT JOIN IQSC_DataWarehouse.dbo.DimHospital DH (nolock)
ON DC.Hospital_Key = DH.Hospital_Key

LEFT JOIN IQSC_DataWarehouse.dbo.Dim_CPT4_ProductLine CPT (nolock)
ON CPT.CPT_Code = HCP.HCPCS_ProcedureCode

LEFT JOIN IQSC_DataWarehouse.dbo.Map_Claim_Physician MCP1 (nolock)
ON MCP1.Claim_Key = DC.Claim_Key AND MCP1.PhysicianRole_Key = 1

LEFT JOIN IQSC_DataWarehouse.dbo.Map_Claim_Physician MCP2 (nolock)
ON MCP2.Claim_Key = DC.Claim_Key AND MCP2.PhysicianRole_Key = 2

LEFT JOIN IQSC_DataWarehouse.dbo.DimPhysician DP1 (nolock)
ON DP1.Physician_Key = MCP1.Physician_Key

LEFT JOIN IQSC_DataWarehouse.dbo.DimPhysician DP2 (nolock)
ON DP2.Physician_Key = MCP2.Physician_Key

LEFT JOIN IQSC_DataWarehouse.NYU_LOAD.NYUER_OUT_PUDF NYU (nolock)
ON NYU.Claim_Key = DC.Claim_Key

LEFT JOIN  IQSC_DataWarehouse.NPIData.ProviderLicense NPI (nolock)
ON NPI.NPI = DP1.NPI AND NPI.Healthcare_Provider_Primary_Taxonomy_Switch = ''Y'' AND NPI.Provider_License_Number_State_Code = ''TX''

LEFT JOIN  IQSC_DataWarehouse.Legacy.TaxonomyCodeMaster TCM (nolock)
ON TCM.TaxonomyCode = NPI.Healthcare_Provider_Taxonomy_Code

LEFT JOIN IQSC_DataWarehouse.dbo.DimDate DD (nolock)
ON DD.DateValue = DC.DischargeDate

LEFT JOIN IQSC_DataWarehouse.dbo.Dim_Diag_ProductLine_THR THR (nolock)
ON THR.Code_no_Decimal = D.DiagnosisCode

LEFT JOIN  IQSC_DataWarehouse.dbo.vw_QV_DiagProcCodesInp  DPC (nolock)
ON DPC.DFWHCID = DC.Claim_Key 

LEFT JOIN  IQSC_DataWarehouse.CCS_Working.DXREF_2013_working ccs (nolock)
ON ccs.[ICD-9-CM CODE] = D.DiagnosisCode

LEFT JOIN  IQSC_DataWarehouse.CCS_Working.ccs_multi_dx_tool_2013 ccsdx (nolock)
ON ccsdx.[ICD-9-CM CODE] = D.DiagnosisCode

--LEFT JOIN  IQSC_DataWarehouse.dbo.vw_QV_BITS bits (nolock)
--ON bits.Claim_Key = dc.Claim_Key

LEFT JOIN IQSC_DataWarehouse.dbo.vw_QV_ER_Out_Acuity acu (nolock)
ON acu.Claim_Key = dc.Claim_Key

LEFT JOIN IQSC_DataWarehouse.dbo.vw_QV_Mortality mor (nolock)
ON mor.Claim_Key = dc.Claim_Key

LEFT JOIN  IQSC_DataWarehouse.dbo.vw_QV_CodePosFilledDiag cpfd (nolock)
ON cpfd.Claim_Key = dc.Claim_Key

LEFT JOIN  IQSC_DataWarehouse.dbo.vw_QV_CodePosFilledProc cpfp (nolock)
ON cpfp.Claim_Key = dc.Claim_Key


                
WHERE

DC.PrimaryRecord = 1
AND DC.ClaimStatusCode NOT IN (''X'',''V'')
AND DC.DischargeQuarter BETWEEN 200801 AND 201004

--AND dc.SubmissionPurpose = ''O''
--AND DD.[Month] = 201012
--AND dc.Hospital_Key = 15


GO


', 
		@database_name=N'IQSC_DataWarehouse', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Load Monthly Tables]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Load Monthly Tables', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec dbo.sp_LoadQlikViewTable', 
		@database_name=N'IQSC_DataWarehouse', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'QLik View Monthly', 
		@enabled=1, 
		@freq_type=16, 
		@freq_interval=28, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20140627, 
		@active_end_date=99991231, 
		@active_start_time=233000, 
		@active_end_time=235959, 
		@schedule_uid=N'07fa930b-adde-422d-b39d-2838d7b7baf6'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Quadramed Full Load]    Script Date: 12/31/2015 08:46:44 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:44 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Quadramed Full Load', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\DATAINITSQLAGENT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Quadramed Full Load]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Quadramed Full Load', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\Quadramed Full Load" /SERVER hv10 /X86  /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [QuadramedRefresh]    Script Date: 12/31/2015 08:46:44 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:44 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'QuadramedRefresh', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\DATAINITSQLAGENT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [5_DW_Quadramed_Refresh_Test]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'5_DW_Quadramed_Refresh_Test', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\5_DW_Quadramed_Refresh_Test" /SERVER hv10 /X86  /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Nightly Schedule', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=1, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20140517, 
		@active_end_date=99991231, 
		@active_start_time=190000, 
		@active_end_time=235959, 
		@schedule_uid=N'76786965-bd62-4e3c-9d59-1aebe471f84c'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [ReIndex.Subplan_1]    Script Date: 12/31/2015 08:46:44 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 12/31/2015 08:46:44 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'ReIndex.Subplan_1', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'Purna', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Subplan_1]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Subplan_1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/SQL "Maintenance Plans\ReIndex" /SERVER "HV10\IQSC01" /CHECKPOINTING OFF /SET "\Package\Subplan_1.Disable";false /REPORTING E', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'ReIndex', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=64, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151229, 
		@active_end_date=99991231, 
		@active_start_time=10000, 
		@active_end_time=235959, 
		@schedule_uid=N'd6925aed-db5f-4480-b352-4b2e15122c99'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Rev_Fix]    Script Date: 12/31/2015 08:46:44 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:44 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Rev_Fix', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\pyalavarthy', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Rev_Fix]    Script Date: 12/31/2015 08:46:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Rev_Fix', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'delete from FACT_ClaimCharge
from  FACT_ClaimCharge FC
INNER JOIN FACT_Claim F ON FC.Claim_Key = F.Claim_Key
INNER JOIN Dimclaim DC on FC.Claim_Key=dc.Claim_Key and dc.DischargeQuarter=201402
JOIN TT_REV TT ON FC.Claim_Key=TT.Claim_Key

 go
 
insert into FACT_ClaimCharge(
Claim_Key,
Sequence,
Hospital_Key,
SubmissionPurpose,
DischargeDate,
ServiceDate,
RevenueCode,
HCPCS_QualifierCode,
HCPCS_ProcedureCode,
HCPCS_ModifierCode01,
HCPCS_ModifierCode02,
HCPCS_ModifierCode03,
HCPCS_ModifierCode04,
ChargeAmt,
NonCoveredChargeAmt,
Units,
UnitRate,
UnitMeasurementCode,
APC_Key,
Batch_ID,
DW_InsertDate)

select  
 R.Claim_Key,
r1.Quartile1,
f.Hospital_Key,
f.SubmissionPurpose,
f.DischargeDate,
case when dc.SubmissionPurpose = ''I'' then null else uid_serv_thru_date end as uid_serv_thru_date,
case when len (r.uid_rev_code)=3 then ''0''+r.uid_rev_code else r.uid_rev_code end uid_rev_code,
--r.uid_rev_code,
substring(r.uid_hipps,1,2) uid_hipps,
r.uid_hcpcs,
r.uid_mod1,
r.uid_mod2,
r.uid_mod3,
r.uid_mod4,
r.uid_tot_chrgs,
r.uid_non_cvrd_chrgs,
replace(R.uid_units,''.0'','''') uid_units,
r.uid_unit_rate,
r.uid_unit_code,
null APC_Key,
DC.Batch_ID,
''2014-10-20'' as dw_insertdate  --into FACT_ClaimCharge_tmp
from  (select MAX(rec_id)as rec_id  from tt_rev group by uid_rev_code,uid_key,uid_hcpcs,uid_serv_thru_date,claim_key) d1
 inner join tt_rev R on d1.rec_id=r.rec_id 
  inner join  tt_rev_sequence R1  
on r.claim_key=r1.Claim_Key and r1.uid_hcpcs=r.uid_hcpcs and r.uid_serv_thru_date=r1.uid_serv_thru_date and r.uid_rev_code=r1.uid_rev_code
--inner join FACT_ClaimCharge F on  F.Claim_Key=d.Claim_Key and ChargeAmt=uid_tot_chrgs and Units=replace(uid_units,''.0'','''') and UnitRate=uid_unit_rate and UnitMeasurementCode=uid_unit_code and f.RevenueCode=D.uid_rev_code
--and f.RevenueCode=-1 
INNER JOIN FACT_Claim F ON R.Claim_Key = F.Claim_Key
INNER JOIN Dimclaim DC on R.Claim_Key=dc.Claim_Key and dc.DischargeQuarter=201402
 
', 
		@database_name=N'IQSC_DataWarehouse', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [SAS_PUDF Table Load]    Script Date: 12/31/2015 08:46:44 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:44 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'SAS_PUDF Table Load', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\DATAINITSQLAGENT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Load SAS PUDF]    Script Date: 12/31/2015 08:46:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Load SAS PUDF', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\SAS_PUDF_Load" /SERVER hv10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [LoadDiagsProcsEcodes]    Script Date: 12/31/2015 08:46:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'LoadDiagsProcsEcodes', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\LoadDiagsProcsEcodes" /SERVER hv10 /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'idx', 
		@enabled=0, 
		@freq_type=1, 
		@freq_interval=0, 
		@freq_subday_type=0, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20130117, 
		@active_end_date=99991231, 
		@active_start_time=220805, 
		@active_end_time=235959, 
		@schedule_uid=N'3ae21684-8930-4a90-a88a-072755549aa1'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [sp_delete_backuphistory]    Script Date: 12/31/2015 08:46:45 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 12/31/2015 08:46:45 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'sp_delete_backuphistory', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Source: https://ola.hallengren.com', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [sp_delete_backuphistory]    Script Date: 12/31/2015 08:46:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'sp_delete_backuphistory', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'sqlcmd -E -S $(ESCAPE_SQUOTE(SRVR)) -d msdb -Q "DECLARE @CleanupDate datetime SET @CleanupDate = DATEADD(dd,-30,GETDATE()) EXECUTE dbo.sp_delete_backuphistory @oldest_date = @CleanupDate" -b', 
		@output_file_name=N'C:\Program Files\Microsoft SQL Server\MSSQL10_50.IQSC01\MSSQL\Log\sp_delete_backuphistory_$(ESCAPE_SQUOTE(JOBID))_$(ESCAPE_SQUOTE(STEPID))_$(ESCAPE_SQUOTE(STRTDT))_$(ESCAPE_SQUOTE(STRTTM)).txt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [sp_purge_jobhistory]    Script Date: 12/31/2015 08:46:45 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 12/31/2015 08:46:45 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'sp_purge_jobhistory', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Source: https://ola.hallengren.com', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [sp_purge_jobhistory]    Script Date: 12/31/2015 08:46:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'sp_purge_jobhistory', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'sqlcmd -E -S $(ESCAPE_SQUOTE(SRVR)) -d msdb -Q "DECLARE @CleanupDate datetime SET @CleanupDate = DATEADD(dd,-30,GETDATE()) EXECUTE dbo.sp_purge_jobhistory @oldest_date = @CleanupDate" -b', 
		@output_file_name=N'C:\Program Files\Microsoft SQL Server\MSSQL10_50.IQSC01\MSSQL\Log\sp_purge_jobhistory_$(ESCAPE_SQUOTE(JOBID))_$(ESCAPE_SQUOTE(STEPID))_$(ESCAPE_SQUOTE(STRTDT))_$(ESCAPE_SQUOTE(STRTTM)).txt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Staging]    Script Date: 12/31/2015 08:46:45 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:45 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Staging', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\pyalavarthy', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Staging]    Script Date: 12/31/2015 08:46:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Staging', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec DeleteStagingFileByDashboardID_PURNA 9615
exec DeleteStagingFileByDashboardID_PURNA 9643
exec DeleteStagingFileByDashboardID_PURNA 9644
exec DeleteStagingFileByDashboardID_PURNA 9645
exec DeleteStagingFileByDashboardID_PURNA 9665
exec DeleteStagingFileByDashboardID_PURNA 9918
exec DeleteStagingFileByDashboardID_PURNA 9919
exec DeleteStagingFileByDashboardID_PURNA 9920
exec DeleteStagingFileByDashboardID_PURNA 9921
exec DeleteStagingFileByDashboardID_PURNA 9923
exec DeleteStagingFileByDashboardID_PURNA 9925
exec DeleteStagingFileByDashboardID_PURNA 141284
exec DeleteStagingFileByDashboardID_PURNA 141286
exec DeleteStagingFileByDashboardID_PURNA 141288
exec DeleteStagingFileByDashboardID_PURNA 141290
exec DeleteStagingFileByDashboardID_PURNA 142226
exec DeleteStagingFileByDashboardID_PURNA 142228
exec DeleteStagingFileByDashboardID_PURNA 142230
exec DeleteStagingFileByDashboardID_PURNA 142232
exec DeleteStagingFileByDashboardID_PURNA 142233
exec DeleteStagingFileByDashboardID_PURNA 142234', 
		@database_name=N'DFWHC_Staging', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [syspolicy_purge_history]    Script Date: 12/31/2015 08:46:45 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:45 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'syspolicy_purge_history', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Verify that automation is enabled.]    Script Date: 12/31/2015 08:46:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Verify that automation is enabled.', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=1, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'IF (msdb.dbo.fn_syspolicy_is_automation_enabled() != 1)
        BEGIN
            RAISERROR(34022, 16, 1)
        END', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Purge history.]    Script Date: 12/31/2015 08:46:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Purge history.', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC msdb.dbo.sp_syspolicy_purge_history', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Erase Phantom System Health Records.]    Script Date: 12/31/2015 08:46:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Erase Phantom System Health Records.', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'if (''$(ESCAPE_SQUOTE(INST))'' -eq ''MSSQLSERVER'') {$a = ''\DEFAULT''} ELSE {$a = ''''};
(Get-Item SQLSERVER:\SQLPolicy\$(ESCAPE_NONE(SRVR))$a).EraseSystemHealthPhantomRecords()', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'syspolicy_purge_history_schedule', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20080101, 
		@active_end_date=99991231, 
		@active_start_time=20000, 
		@active_end_time=235959, 
		@schedule_uid=N'63c1ada3-806c-4d57-a789-16d0db2766f9'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [SystemDatabasesBackup.Subplan_1]    Script Date: 12/31/2015 08:46:45 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 12/31/2015 08:46:45 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'SystemDatabasesBackup.Subplan_1', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'DFWHC\pyalavarthy', 
		@notify_email_operator_name=N'Purna', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Subplan_1]    Script Date: 12/31/2015 08:46:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Subplan_1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/Server "$(ESCAPE_NONE(SRVR))" /SQL "Maintenance Plans\SystemDatabasesBackup" /set "\Package\Subplan_1.Disable;false"', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'SystemDB Backup', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=62, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151229, 
		@active_end_date=99991231, 
		@active_start_time=220000, 
		@active_end_time=235959, 
		@schedule_uid=N'416924de-fa2b-4f7c-8acf-fe275c2a5e12'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Test]    Script Date: 12/31/2015 08:46:45 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:45 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Test', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\pyalavarthy', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Test]    Script Date: 12/31/2015 08:46:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Test', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'select @@servername', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [THCIC]    Script Date: 12/31/2015 08:46:45 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:45 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'THCIC', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\DATAINITSQLAGENT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Restore]    Script Date: 12/31/2015 08:46:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Restore', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [THCIC] FROM  DISK = N''M:\IQSC_DataWarehouse\SQL02$IQSC01\THCIC\FULL\SQL02$IQSC01_THCIC_FULL_20130809_041412.bak'' 
WITH  FILE = 1,  MOVE N''THCIC'' TO N''M:\SQLDATA\IQSC\THCIC.mdf'',
 MOVE N''THCIC_log'' TO N''I:\SQLLOGS\IQSCLOGS\THCIC_1.ldf'',  NOUNLOAD,  REPLACE,  STATS = 10
GO
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [THCIC PUDF Load]    Script Date: 12/31/2015 08:46:45 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:45 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'THCIC PUDF Load', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\DATAINITSQLAGENT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Import THCIC PUDF Files]    Script Date: 12/31/2015 08:46:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Import THCIC PUDF Files', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/DTS "\MSDB\Load_THCIC_PUDF_2004_Format" /SERVER HV10 /CONNECTION THCIC;"\"Data Source=SQL02\IQSC01;Initial Catalog=THCIC;Provider=SQLOLEDB.1;Integrated Security=SSPI;Application Name=SSIS-Load_THCIC_PUDF_2004_Format-{8CE8C816-33B7-4522-A734-5675506C3DDC}THCIC_PUDF_Main_Working;\"" /CHECKPOINTING OFF /REPORTING E', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Regular Recurring', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=1, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20111104, 
		@active_end_date=99991231, 
		@active_start_time=83000, 
		@active_end_time=235959, 
		@schedule_uid=N'74b54d76-ad8f-4c1e-b622-aa75e38d9240'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [THCIC_DW]    Script Date: 12/31/2015 08:46:45 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:45 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'THCIC_DW', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Restore]    Script Date: 12/31/2015 08:46:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Restore', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [THCIC_DW] FROM  DISK = N''M:\IQSC_DataWarehouse\SQL02$IQSC01\THCIC_DW\FULL\SQL02$IQSC01_THCIC_DW_FULL_20130809_064522.bak'' WITH  FILE = 1,  MOVE N''THCIC_DW'' TO N''M:\SQLDATA\IQSC\THCIC_DW.mdf'',  MOVE N''THCIC_DW_log'' TO N''I:\SQLLOGS\IQSCLOGS\THCIC_DW_1.ldf'',  NOUNLOAD,  REPLACE,  STATS = 10
GO
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [THCIC_pudf]    Script Date: 12/31/2015 08:46:45 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:45 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'THCIC_pudf', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\pyalavarthy', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [THCIC_PUDF_CHsrges]    Script Date: 12/31/2015 08:46:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'THCIC_PUDF_CHsrges', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
--insert into THCIC_PUDF_Charges_TMP
--(RECORD_ID,
--REVENUE_CODE,
--HCPCS_QUALIFIER,
--HCPCS_PROCEDURE_CODE,
--MODIFIER_1,
--MODIFIER_2,
--MODIFIER_3,
--MODIFIER_4,
--UNIT_MEASUREMENT_CODE,
--UNITS_OF_SERVICE,
--UNIT_RATE,
--CHRGS_LINE_ITEM,
--CHRGS_NON_COV,
--SUBMISSION_PURPOSE)

select distinct RECORD_ID,
REVENUE_CODE,
HCPCS_QUALIFIER,
HCPCS_PROCEDURE_CODE,
MODIFIER_1,
MODIFIER_2,
MODIFIER_3,
MODIFIER_4,
UNIT_MEASUREMENT_CODE,
UNITS_OF_SERVICE,
UNIT_RATE,
CHRGS_LINE_ITEM,
CHRGS_NON_COV,
SUBMISSION_PURPOSE
into THCIC_PUDF_Charges_TMP
from THCIC_PUDF_Charges
--select * from THCIC_PUDF_Charges_sri

truncate table THCIC_PUDF_Charges


insert into THCIC_PUDF_Charges
(RECORD_ID,
REVENUE_CODE,
HCPCS_QUALIFIER,
HCPCS_PROCEDURE_CODE,
MODIFIER_1,
MODIFIER_2,
MODIFIER_3,
MODIFIER_4,
UNIT_MEASUREMENT_CODE,
UNITS_OF_SERVICE,
UNIT_RATE,
CHRGS_LINE_ITEM,
CHRGS_NON_COV,
SUBMISSION_PURPOSE)

select  RECORD_ID,
REVENUE_CODE,
HCPCS_QUALIFIER,
HCPCS_PROCEDURE_CODE,
MODIFIER_1,
MODIFIER_2,
MODIFIER_3,
MODIFIER_4,
UNIT_MEASUREMENT_CODE,
UNITS_OF_SERVICE,
UNIT_RATE,
CHRGS_LINE_ITEM,
CHRGS_NON_COV,
SUBMISSION_PURPOSE
 
from THCIC_PUDF_Charges_TMP



insert into THCIC_PUDF_Charges
(RECORD_ID,
REVENUE_CODE,
HCPCS_QUALIFIER,
HCPCS_PROCEDURE_CODE,
MODIFIER_1,
MODIFIER_2,
MODIFIER_3,
MODIFIER_4,
UNIT_MEASUREMENT_CODE,
UNITS_OF_SERVICE,
UNIT_RATE,
CHRGS_LINE_ITEM,
CHRGS_NON_COV,
SUBMISSION_PURPOSE)

select  RECORD_ID,
REVENUE_CODE,
HCPCS_QUALIFIER,
HCPCS_PROCEDURE_CODE,
MODIFIER_1,
MODIFIER_2,
MODIFIER_3,
MODIFIER_4,
UNIT_MEASUREMENT_CODE,
UNITS_OF_SERVICE,
UNIT_RATE,
CHRGS_LINE_ITEM,
CHRGS_NON_COV,
SUBMISSION_PURPOSE
 
from THCIC_PUDF_Charges_Sri



', 
		@database_name=N'THCIC', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'start', 
		@enabled=0, 
		@freq_type=1, 
		@freq_interval=0, 
		@freq_subday_type=0, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20140116, 
		@active_end_date=99991231, 
		@active_start_time=191000, 
		@active_end_time=235959, 
		@schedule_uid=N'14b4d8b0-d2fd-4e71-a43e-2c6db600071e'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [THCIC_Scripts]    Script Date: 12/31/2015 08:46:45 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:45 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'THCIC_Scripts', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\jdaniel', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [THCIC_Script_step1]    Script Date: 12/31/2015 08:46:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'THCIC_Script_step1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'--  PUDF STAGING LOAD - Inpatient
	
	TRUNCATE TABLE THCIC_PUDF_Purna

	INSERT INTO THCIC_PUDF_Purna (
		DISCHARGE, THCIC_ID, PROVIDER_NAME, FAC_TEACHING_IND, FAC_PSYCH_IND, FAC_REHAB_IND, FAC_ACUTE_CARE_IND, FAC_SNF_IND, FAC_LONG_TERM_AC_IND, FAC_OTHER_LTC_IND, FAC_PEDS_IND, SPEC_UNIT_1, SPEC_UNIT_2, SPEC_UNIT_3, SPEC_UNIT_4, SPEC_UNIT_5, ENCOUNTER_INDICATOR, SEX_CODE, TYPE_OF_ADMISSION, SOURCE_OF_ADMISSION, PAT_STATE, PAT_ZIP, PAT_COUNTRY, COUNTY, PUBLIC_HEALTH_REGION, ADMIT_WEEKDAY, LENGTH_OF_STAY, PAT_AGE, PAT_STATUS, RACE, ETHNICITY, FIRST_PAYMENT_SRC, SECONDARY_PAYMENT_SRC, TYPE_OF_BILL, PRIVATE_AMOUNT, SEMI_PRIVATE_AMOUNT, WARD_AMOUNT, ICU_AMOUNT, CCU_AMOUNT, OTHER_AMOUNT, PHARM_AMOUNT, MEDSURG_AMOUNT, DME_AMOUNT, USED_DME_AMOUNT, PT_AMOUNT, OT_AMOUNT, SPEECH_AMOUNT, IT_AMOUNT, BLOOD_AMOUNT, BLOOD_ADMIN_AMOUNT, OR_AMOUNT, LITH_AMOUNT, CARD_AMOUNT, ANES_AMOUNT, LAB_AMOUNT, RAD_AMOUNT, MRI_AMOUNT, OP_AMOUNT, ER_AMOUNT, AMBULANCE_AMOUNT, PRO_FEE_AMOUNT, ORGAN_AMOUNT, ESRD_AMOUNT, CLINIC_AMOUNT, TOTAL_CHARGES, TOTAL_NON_COV_CHARGES, TOTAL_CHARGES_ACCOMM, TOTAL_NON_COV_CHARGES_ACCOMM, TOTAL_CHARGES_ANCIL, TOTAL_NON_COV_CHARGES_ANCIL, 
		ADMITTING_DIAGNOSIS, PRINC_DIAG_CODE, OTH_DIAG_CODE_1, OTH_DIAG_CODE_2, OTH_DIAG_CODE_3, OTH_DIAG_CODE_4, OTH_DIAG_CODE_5, OTH_DIAG_CODE_6, OTH_DIAG_CODE_7, OTH_DIAG_CODE_8, OTH_DIAG_CODE_9, OTH_DIAG_CODE_10, OTH_DIAG_CODE_11, OTH_DIAG_CODE_12, OTH_DIAG_CODE_13, OTH_DIAG_CODE_14, OTH_DIAG_CODE_15, OTH_DIAG_CODE_16, OTH_DIAG_CODE_17, OTH_DIAG_CODE_18, OTH_DIAG_CODE_19, OTH_DIAG_CODE_20, OTH_DIAG_CODE_21, OTH_DIAG_CODE_22, OTH_DIAG_CODE_23, OTH_DIAG_CODE_24, PRINC_SURG_PROC_CODE, PRINC_SURG_PROC_DAY, PRINC_ICD9_CODE, OTH_SURG_PROC_CODE_1, OTH_SURG_PROC_DAY_1, OTH_ICD9_CODE_1, OTH_SURG_PROC_CODE_2, OTH_SURG_PROC_DAY_2, OTH_ICD9_CODE_2, OTH_SURG_PROC_CODE_3, OTH_SURG_PROC_DAY_3, OTH_ICD9_CODE_3, OTH_SURG_PROC_CODE_4, OTH_SURG_PROC_DAY_4, OTH_ICD9_CODE_4, OTH_SURG_PROC_CODE_5, OTH_SURG_PROC_DAY_5, OTH_ICD9_CODE_5, OTH_SURG_PROC_CODE_6, OTH_SURG_PROC_DAY_6, OTH_ICD9_CODE_6, OTH_SURG_PROC_CODE_7, OTH_SURG_PROC_DAY_7, OTH_ICD9_CODE_7, OTH_SURG_PROC_CODE_8, OTH_SURG_PROC_DAY_8, OTH_ICD9_CODE_8, OTH_SURG_PROC_CODE_9, OTH_SURG_PROC_DAY_9, 
		OTH_ICD9_CODE_9, OTH_SURG_PROC_CODE_10, OTH_SURG_PROC_DAY_10, OTH_ICD9_CODE_10, OTH_SURG_PROC_CODE_11, OTH_SURG_PROC_DAY_11, OTH_ICD9_CODE_11, OTH_SURG_PROC_CODE_12, OTH_SURG_PROC_DAY_12, OTH_ICD9_CODE_12, OTH_SURG_PROC_CODE_13, OTH_SURG_PROC_DAY_13, OTH_ICD9_CODE_13, OTH_SURG_PROC_CODE_14, OTH_SURG_PROC_DAY_14, OTH_ICD9_CODE_14, OTH_SURG_PROC_CODE_15, OTH_SURG_PROC_DAY_15, OTH_ICD9_CODE_15, OTH_SURG_PROC_CODE_16, OTH_SURG_PROC_DAY_16, OTH_ICD9_CODE_16, OTH_SURG_PROC_CODE_17, OTH_SURG_PROC_DAY_17, OTH_ICD9_CODE_17, OTH_SURG_PROC_CODE_18, OTH_SURG_PROC_DAY_18, OTH_ICD9_CODE_18, OTH_SURG_PROC_CODE_19, OTH_SURG_PROC_DAY_19, OTH_ICD9_CODE_19, OTH_SURG_PROC_CODE_20, OTH_SURG_PROC_DAY_20, OTH_ICD9_CODE_20, OTH_SURG_PROC_CODE_21, OTH_SURG_PROC_DAY_21, OTH_ICD9_CODE_21, OTH_SURG_PROC_CODE_22, OTH_SURG_PROC_DAY_22, OTH_ICD9_CODE_22, OTH_SURG_PROC_CODE_23, OTH_SURG_PROC_DAY_23, OTH_ICD9_CODE_23, OTH_SURG_PROC_CODE_24, OTH_SURG_PROC_DAY_24, OTH_ICD9_CODE_24, E_CODE_1, E_CODE_2, E_CODE_3, E_CODE_4, E_CODE_5, E_CODE_6, E_CODE_7, E_CODE_8, 
		E_CODE_9, E_CODE_10, CONDITION_CODE_1, CONDITION_CODE_2, CONDITION_CODE_3, CONDITION_CODE_4, CONDITION_CODE_5, CONDITION_CODE_6, CONDITION_CODE_7, CONDITION_CODE_8, OCCUR_CODE_1, OCCUR_DAY_1, OCCUR_CODE_2, OCCUR_DAY_2, OCCUR_CODE_3, OCCUR_DAY_3, OCCUR_CODE_4, OCCUR_DAY_4, OCCUR_CODE_5, OCCUR_DAY_5, OCCUR_CODE_6, OCCUR_DAY_6, OCCUR_CODE_7, OCCUR_DAY_7, OCCUR_CODE_8, OCCUR_DAY_8, OCCUR_CODE_9, OCCUR_DAY_9, OCCUR_CODE_10, OCCUR_DAY_10, OCCUR_CODE_11, OCCUR_DAY_11, OCCUR_CODE_12, OCCUR_DAY_12, OCCUR_SPAN_CODE_1, OCCUR_SPAN_FROM_1, OCCUR_SPAN_THRU_1, OCCUR_SPAN_CODE_2, OCCUR_SPAN_FROM_2, OCCUR_SPAN_THRU_2, OCCUR_SPAN_CODE_3, OCCUR_SPAN_FROM_3, OCCUR_SPAN_THRU_3, OCCUR_SPAN_CODE_4, OCCUR_SPAN_FROM_4, OCCUR_SPAN_THRU_4, VALUE_CODE_1, VALUE_AMOUNT_1, VALUE_CODE_2, VALUE_AMOUNT_2, VALUE_CODE_3, VALUE_AMOUNT_3, VALUE_CODE_4, VALUE_AMOUNT_4, VALUE_CODE_5, VALUE_AMOUNT_5, VALUE_CODE_6, VALUE_AMOUNT_6, VALUE_CODE_7, VALUE_AMOUNT_7, VALUE_CODE_8, VALUE_AMOUNT_8, VALUE_CODE_9, VALUE_AMOUNT_9, VALUE_CODE_10, VALUE_AMOUNT_10, VALUE_CODE_11, VALUE_AMOUNT_11, 
		VALUE_CODE_12, VALUE_AMOUNT_12, HCFA_MDC, APR_MDC, HCFA_DRG, APR_DRG, RISK_MORTALITY, ILLNESS_SEVERITY, ATTENDING_PHYSICIAN_UNIF_ID, OPERATING_PHYSICIAN_UNIF_ID, CERT_STATUS, RECORD_ID, POA_PROVIDER_INDICATOR, POA_PRINC_DIAG_CODE, POA_OTH_DIAG_CODE_1, POA_OTH_DIAG_CODE_2, POA_OTH_DIAG_CODE_3, POA_OTH_DIAG_CODE_4, POA_OTH_DIAG_CODE_5, POA_OTH_DIAG_CODE_6, POA_OTH_DIAG_CODE_7, POA_OTH_DIAG_CODE_8, POA_OTH_DIAG_CODE_9, POA_OTH_DIAG_CODE_10, POA_OTH_DIAG_CODE_11, POA_OTH_DIAG_CODE_12, POA_OTH_DIAG_CODE_13, POA_OTH_DIAG_CODE_14, POA_OTH_DIAG_CODE_15, POA_OTH_DIAG_CODE_16, POA_OTH_DIAG_CODE_17, POA_OTH_DIAG_CODE_18, POA_OTH_DIAG_CODE_19, POA_OTH_DIAG_CODE_20, POA_OTH_DIAG_CODE_21, POA_OTH_DIAG_CODE_22, POA_OTH_DIAG_CODE_23, POA_OTH_DIAG_CODE_24, POA_E_CODE_1, POA_E_CODE_2, POA_E_CODE_3, POA_E_CODE_4, POA_E_CODE_5, POA_E_CODE_6, POA_E_CODE_7, POA_E_CODE_8, POA_E_CODE_9, POA_E_CODE_10, MS_GROUPER_VERSION_NBR, MS_GROUPER_ERROR_CODE, APR_GROUPER_VERSION_NBR, APR_GROUPER_ERROR_CODE, SubmissionPurpose
		)
	SELECT DISTINCT B1.DISCHARGE, B1.THCIC_ID, B1.PROVIDER_NAME, FIP1.FAC_TEACHING_IND, FIP1.FAC_PSYCH_IND, FIP1.FAC_REHAB_IND, FIP1.FAC_ACUTE_CARE_IND, FIP1.FAC_SNF_IND, FIP1.FAC_LONG_TERM_AC_IND, FIP1.FAC_OTHER_LTC_IND, FIP1.FAC_PEDS_IND, B1.SPEC_UNIT_1, B1.SPEC_UNIT_2, B1.SPEC_UNIT_3, B1.SPEC_UNIT_4, B1.SPEC_UNIT_5, B1.ENCOUNTER_INDICATOR, B1.SEX_CODE, B1.TYPE_OF_ADMISSION, B1.SOURCE_OF_ADMISSION, B1.PAT_STATE, B1.PAT_ZIP, B1.PAT_COUNTRY, B1.COUNTY, B1.PUBLIC_HEALTH_REGION, B1.ADMIT_WEEKDAY, B1.LENGTH_OF_STAY, B1.PAT_AGE, B1.PAT_STATUS, B1.RACE, B1.ETHNICITY, B1.FIRST_PAYMENT_SRC, B1.SECONDARY_PAYMENT_SRC, B1.TYPE_OF_BILL, B2.PRIVATE_AMOUNT, B2.SEMI_PRIVATE_AMOUNT, B2.WARD_AMOUNT, B2.ICU_AMOUNT, B2.CCU_AMOUNT, B2.OTHER_AMOUNT, B2.PHARM_AMOUNT, B2.MEDSURG_AMOUNT, B2.DME_AMOUNT, B2.USED_DME_AMOUNT, B2.PT_AMOUNT, B2.OT_AMOUNT, B2.SPEECH_AMOUNT, B2.IT_AMOUNT, B2.BLOOD_AMOUNT, B2.BLOOD_ADM_AMOUNT, B2.OR_AMOUNT, B2.LITH_AMOUNT, B2.CARD_AMOUNT, B2.ANES_AMOUNT, B2.LAB_AMOUNT, B2.RAD_AMOUNT, B2.MRI_AMOUNT, B2.OP_AMOUNT, B2.ER_AMOUNT, B2.AMBULANCE_AMOUNT, 
		B2.PRO_FEE_AMOUNT, B2.ORGAN_AMOUNT, B2.ESRD_AMOUNT, B2.CLINIC_AMOUNT, B1.TOTAL_CHARGES, B1.TOTAL_NON_COV_CHARGES, B1.TOTAL_CHARGES_ACCOMM, B1.TOTAL_NON_COV_CHARGES_ACCOMM, B1.TOTAL_CHARGES_ANCIL, B1.TOTAL_NON_COV_CHARGES_ANCIL, B1.ADMITTING_DIAGNOSIS, B1.PRINC_DIAG_CODE, B1.OTH_DIAG_CODE_1, B1.OTH_DIAG_CODE_2, B1.OTH_DIAG_CODE_3, B1.OTH_DIAG_CODE_4, B1.OTH_DIAG_CODE_5, B1.OTH_DIAG_CODE_6, B1.OTH_DIAG_CODE_7, B1.OTH_DIAG_CODE_8, B1.OTH_DIAG_CODE_9, B1.OTH_DIAG_CODE_10, B1.OTH_DIAG_CODE_11, B1.OTH_DIAG_CODE_12, B1.OTH_DIAG_CODE_13, B1.OTH_DIAG_CODE_14, B1.OTH_DIAG_CODE_15, B1.OTH_DIAG_CODE_16, B1.OTH_DIAG_CODE_17, B1.OTH_DIAG_CODE_18, B1.OTH_DIAG_CODE_19, B1.OTH_DIAG_CODE_20, B1.OTH_DIAG_CODE_21, B1.OTH_DIAG_CODE_22, B1.OTH_DIAG_CODE_23, B1.OTH_DIAG_CODE_24, B1.PRINC_SURG_PROC_CODE, B1.PRINC_SURG_PROC_DAY, B1.PRINC_ICD9_CODE, B1.OTH_SURG_PROC_CODE_1, B1.OTH_SURG_PROC_DAY_1, B1.OTH_ICD9_CODE_1, B1.OTH_SURG_PROC_CODE_2, B1.OTH_SURG_PROC_DAY_2, B1.OTH_ICD9_CODE_2, B1.OTH_SURG_PROC_CODE_3, B1.OTH_SURG_PROC_DAY_3, B1.OTH_ICD9_CODE_3, 
		B1.OTH_SURG_PROC_CODE_4, B1.OTH_SURG_PROC_DAY_4, B1.OTH_ICD9_CODE_4, B1.OTH_SURG_PROC_CODE_5, B1.OTH_SURG_PROC_DAY_5, B1.OTH_ICD9_CODE_5, B1.OTH_SURG_PROC_CODE_6, B1.OTH_SURG_PROC_DAY_6, B1.OTH_ICD9_CODE_6, B1.OTH_SURG_PROC_CODE_7, B1.OTH_SURG_PROC_DAY_7, B1.OTH_ICD9_CODE_7, B1.OTH_SURG_PROC_CODE_8, B1.OTH_SURG_PROC_DAY_8, B1.OTH_ICD9_CODE_8, B1.OTH_SURG_PROC_CODE_9, B1.OTH_SURG_PROC_DAY_9, B1.OTH_ICD9_CODE_9, B1.OTH_SURG_PROC_CODE_10, B1.OTH_SURG_PROC_DAY_10, B1.OTH_ICD9_CODE_10, B1.OTH_SURG_PROC_CODE_11, B1.OTH_SURG_PROC_DAY_11, B1.OTH_ICD9_CODE_11, B1.OTH_SURG_PROC_CODE_12, B1.OTH_SURG_PROC_DAY_12, B1.OTH_ICD9_CODE_12, B1.OTH_SURG_PROC_CODE_13, B1.OTH_SURG_PROC_DAY_13, B1.OTH_ICD9_CODE_13, B1.OTH_SURG_PROC_CODE_14, B1.OTH_SURG_PROC_DAY_14, B1.OTH_ICD9_CODE_14, B1.OTH_SURG_PROC_CODE_15, B1.OTH_SURG_PROC_DAY_15, B1.OTH_ICD9_CODE_15, B1.OTH_SURG_PROC_CODE_16, B1.OTH_SURG_PROC_DAY_16, B1.OTH_ICD9_CODE_16, B1.OTH_SURG_PROC_CODE_17, B1.OTH_SURG_PROC_DAY_17, B1.OTH_ICD9_CODE_17, B1.OTH_SURG_PROC_CODE_18, B1.
		OTH_SURG_PROC_DAY_18, B1.OTH_ICD9_CODE_18, B1.OTH_SURG_PROC_CODE_19, B1.OTH_SURG_PROC_DAY_19, B1.OTH_ICD9_CODE_19, B1.OTH_SURG_PROC_CODE_20, B1.OTH_SURG_PROC_DAY_20, B1.OTH_ICD9_CODE_20, B1.OTH_SURG_PROC_CODE_21, B1.OTH_SURG_PROC_DAY_21, B1.OTH_ICD9_CODE_21, B1.OTH_SURG_PROC_CODE_22, B1.OTH_SURG_PROC_DAY_22, B1.OTH_ICD9_CODE_22, B1.OTH_SURG_PROC_CODE_23, B1.OTH_SURG_PROC_DAY_23, B1.OTH_ICD9_CODE_23, B1.OTH_SURG_PROC_CODE_24, B1.OTH_SURG_PROC_DAY_24, B1.OTH_ICD9_CODE_24, B1.E_CODE_1, B1.E_CODE_2, B1.E_CODE_3, B1.E_CODE_4, B1.E_CODE_5, B1.E_CODE_6, B1.E_CODE_7, B1.E_CODE_8, B1.E_CODE_9, B1.E_CODE_10, B2.CONDITION_CODE_1, B2.CONDITION_CODE_2, B2.CONDITION_CODE_3, B2.CONDITION_CODE_4, B2.CONDITION_CODE_5, B2.CONDITION_CODE_6, B2.CONDITION_CODE_7, B2.CONDITION_CODE_8, B2.OCCUR_CODE_1, B2.OCCUR_DAY_1, B2.OCCUR_CODE_2, B2.OCCUR_DAY_2, B2.OCCUR_CODE_3, B2.OCCUR_DAY_3, B2.OCCUR_CODE_4, B2.OCCUR_DAY_4, B2.OCCUR_CODE_5, B2.OCCUR_DAY_5, B2.OCCUR_CODE_6, B2.OCCUR_DAY_6, B2.OCCUR_CODE_7, B2.OCCUR_DAY_7, B2.OCCUR_CODE_8, B2.OCCUR_DAY_8, B2.
		OCCUR_CODE_9, B2.OCCUR_DAY_9, B2.OCCUR_CODE_10, B2.OCCUR_DAY_10, B2.OCCUR_CODE_11, B2.OCCUR_DAY_11, B2.OCCUR_CODE_12, B2.OCCUR_DAY_12, B2.OCCUR_SPAN_CODE_1, B2.OCCUR_SPAN_FROM_1, B2.OCCUR_SPAN_THRU_1, B2.OCCUR_SPAN_CODE_2, B2.OCCUR_SPAN_FROM_2, B2.OCCUR_SPAN_THRU_2, B2.OCCUR_SPAN_CODE_3, B2.OCCUR_SPAN_FROM_3, B2.OCCUR_SPAN_THRU_3, B2.OCCUR_SPAN_CODE_4, B2.OCCUR_SPAN_FROM_4, B2.OCCUR_SPAN_THRU_4, B2.VALUE_CODE_1, B2.VALUE_AMOUNT_1, B2.VALUE_CODE_2, B2.VALUE_AMOUNT_2, B2.VALUE_CODE_3, B2.VALUE_AMOUNT_3, B2.VALUE_CODE_4, B2.VALUE_AMOUNT_4, B2.VALUE_CODE_5, B2.VALUE_AMOUNT_5, B2.VALUE_CODE_6, B2.VALUE_AMOUNT_6, B2.VALUE_CODE_7, B2.VALUE_AMOUNT_7, B2.VALUE_CODE_8, B2.VALUE_AMOUNT_8, B2.VALUE_CODE_9, B2.VALUE_AMOUNT_9, B2.VALUE_CODE_10, B2.VALUE_AMOUNT_10, B2.VALUE_CODE_11, B2.VALUE_AMOUNT_11, B2.VALUE_CODE_12, B2.VALUE_AMOUNT_12, B1.MS_MDC, B1.APR_MDC, B1.MS_DRG, B1.APR_DRG, B1.RISK_MORTALITY, B1.ILLNESS_SEVERITY, B1.ATTENDING_PHYSICIAN_UNIF_ID, B1.OPERATING_PHYSICIAN_UNIF_ID, B1.CERT_STATUS, B1.RECORD_ID, B1.POA_PROVIDER_INDICATOR, B1.
		POA_PRINC_DIAG_CODE, B1.POA_OTH_DIAG_CODE_1, B1.POA_OTH_DIAG_CODE_2, B1.POA_OTH_DIAG_CODE_3, B1.POA_OTH_DIAG_CODE_4, B1.POA_OTH_DIAG_CODE_5, B1.POA_OTH_DIAG_CODE_6, B1.POA_OTH_DIAG_CODE_7, B1.POA_OTH_DIAG_CODE_8, B1.POA_OTH_DIAG_CODE_9, B1.POA_OTH_DIAG_CODE_10, B1.POA_OTH_DIAG_CODE_11, B1.POA_OTH_DIAG_CODE_12, B1.POA_OTH_DIAG_CODE_13, B1.POA_OTH_DIAG_CODE_14, B1.POA_OTH_DIAG_CODE_15, B1.POA_OTH_DIAG_CODE_16, B1.POA_OTH_DIAG_CODE_17, B1.POA_OTH_DIAG_CODE_18, B1.POA_OTH_DIAG_CODE_19, B1.POA_OTH_DIAG_CODE_20, B1.POA_OTH_DIAG_CODE_21, B1.POA_OTH_DIAG_CODE_22, B1.POA_OTH_DIAG_CODE_23, B1.POA_OTH_DIAG_CODE_24, B1.POA_E_CODE_1, B1.POA_E_CODE_2, B1.POA_E_CODE_3, B1.POA_E_CODE_4, B1.POA_E_CODE_5, B1.POA_E_CODE_6, B1.POA_E_CODE_7, B1.POA_E_CODE_8, B1.POA_E_CODE_9, B1.POA_E_CODE_10, B1.MS_GROUPER_VERSION_NBR, B1.MS_GROUPER_ERROR_CODE, B1.APR_GROUPER_VERSION_NBR, B1.APR_GROUPER_ERROR_CODE, ''I''
	FROM [THCIC_DW].[dbo].PUDF_base1_IPworking B1
	INNER JOIN [THCIC_DW].[dbo].[PUDF_base2_IPworking] B2 ON b1.RECORD_ID = b2.RECORD_ID
	LEFT JOIN [THCIC_DW].[dbo].[Facility_type_IPworking] FIP1 ON FIP1.THCIC_ID = B1.THCIC_ID

	--  PUDF STAGING LOAD - Outpatient
	--Load Outpatient into THCIC_PUDF_PURNA

	INSERT INTO THCIC_PUDF_Purna (
		DISCHARGE, THCIC_ID, PROVIDER_NAME, FAC_TEACHING_IND, FAC_PSYCH_IND, FAC_REHAB_IND, FAC_ACUTE_CARE_IND, FAC_SNF_IND, FAC_LONG_TERM_AC_IND, FAC_OTHER_LTC_IND, FAC_PEDS_IND, SPEC_UNIT_1, SEX_CODE, PAT_STATE, PAT_ZIP, PAT_COUNTRY, COUNTY, PUBLIC_HEALTH_REGION, LENGTH_OF_STAY, PAT_AGE, RACE, ETHNICITY, FIRST_PAYMENT_SRC, SECONDARY_PAYMENT_SRC, TYPE_OF_BILL, OTHER_AMOUNT, PHARM_AMOUNT, MEDSURG_AMOUNT, DME_AMOUNT, USED_DME_AMOUNT, PT_AMOUNT, OT_AMOUNT, SPEECH_AMOUNT, IT_AMOUNT, BLOOD_AMOUNT, BLOOD_ADMIN_AMOUNT, OR_AMOUNT, LITH_AMOUNT, CARD_AMOUNT, ANES_AMOUNT, LAB_AMOUNT, RAD_AMOUNT, MRI_AMOUNT, OP_AMOUNT, ER_AMOUNT, AMBULANCE_AMOUNT, PRO_FEE_AMOUNT, ORGAN_AMOUNT, ESRD_AMOUNT, CLINIC_AMOUNT, TOTAL_CHARGES, TOTAL_NON_COV_CHARGES, TOTAL_CHARGES_ANCIL, TOTAL_NON_COV_CHARGES_ANCIL, PRINC_DIAG_CODE, OTH_DIAG_CODE_1, OTH_DIAG_CODE_2, OTH_DIAG_CODE_3, OTH_DIAG_CODE_4, OTH_DIAG_CODE_5, OTH_DIAG_CODE_6, OTH_DIAG_CODE_7, OTH_DIAG_CODE_8, OTH_DIAG_CODE_9, OTH_DIAG_CODE_10, OTH_DIAG_CODE_11, OTH_DIAG_CODE_12, OTH_DIAG_CODE_13, OTH_DIAG_CODE_14, OTH_DIAG_CODE_15, 
		OTH_DIAG_CODE_16, OTH_DIAG_CODE_17, OTH_DIAG_CODE_18, OTH_DIAG_CODE_19, OTH_DIAG_CODE_20, OTH_DIAG_CODE_21, OTH_DIAG_CODE_22, OTH_DIAG_CODE_23, OTH_DIAG_CODE_24, E_CODE_1, E_CODE_2, E_CODE_3, E_CODE_4, E_CODE_5, E_CODE_6, E_CODE_7, E_CODE_8, E_CODE_9, E_CODE_10, CONDITION_CODE_1, CONDITION_CODE_2, CONDITION_CODE_3, CONDITION_CODE_4, CONDITION_CODE_5, CONDITION_CODE_6, CONDITION_CODE_7, CONDITION_CODE_8, ATTENDING_PHYSICIAN_UNIF_ID, OPERATING_PHYSICIAN_UNIF_ID, CERT_STATUS, RECORD_ID, SubmissionPurpose
		)
	SELECT B1.SERVICE_QUARTER, B1.THCIC_ID, B1.PROVIDER_NAME, F1.FAC_TEACHING_IND, F1.FAC_PSYCH_IND, F1.FAC_REHAB_IND, F1.FAC_ACUTE_CARE_IND, F1.FAC_SNF_IND, F1.FAC_LONG_TERM_AC_IND, F1.FAC_OTHER_LTC_IND, F1.FAC_PEDS_IND, B1.SPEC_UNIT, B1.SEX_CODE, B1.PAT_STATE, B1.PAT_ZIP, B1.PAT_COUNTRY, B1.PAT_COUNTY, B1.PUBLIC_HEALTH_REGION, CASE 
			WHEN B1.[LENGTH_OF_SERVICE] = ''`''
				THEN 999
			ELSE B1.LENGTH_OF_SERVICE
			END, B1.PAT_AGE, B1.RACE, B1.ETHNICITY, B1.FIRST_PAYMENT_SRC, B1.SECONDARY_PAYMENT_SRC, B1.TYPE_OF_BILL, B1.OTHER_AMOUNT, B1.PHARM_AMOUNT, B1.MEDSURG_AMOUNT, B1.DME_AMOUNT, B1.USED_DME_AMOUNT, B1.PT_AMOUNT, B1.OT_AMOUNT, B1.SPEECH_AMOUNT, B1.IT_AMOUNT, B1.BLOOD_AMOUNT, B1.BLOOD_ADM_AMOUNT, B1.OR_AMOUNT, B1.LITH_AMOUNT, B1.CARD_AMOUNT, B1.ANES_AMOUNT, B1.LAB_AMOUNT, B1.RAD_AMOUNT, B1.MRI_AMOUNT, B1.OP_AMOUNT, B1.ER_AMOUNT, B1.AMBULANCE_AMOUNT, B1.PRO_FEE_AMOUNT, B1.ORGAN_AMOUNT, B1.ESRD_AMOUNT, B1.CLINIC_AMOUNT, B1.TOTAL_CHARGES, B1.TOTAL_NON_COV_CHARGES, B1.TOTAL_CHARGES_ANCIL, B1.TOTAL_NON_COV_CHARGES_ANCIL, B1.PRINC_DIAG_CODE, B1.OTH_DIAG_CODE_1, B1.OTH_DIAG_CODE_2, B1.OTH_DIAG_CODE_3, B1.OTH_DIAG_CODE_4, B1.OTH_DIAG_CODE_5, B1.OTH_DIAG_CODE_6, B1.OTH_DIAG_CODE_7, B1.OTH_DIAG_CODE_8, B1.OTH_DIAG_CODE_9, B1.OTH_DIAG_CODE_10, B1.OTH_DIAG_CODE_11, B1.OTH_DIAG_CODE_12, B1.OTH_DIAG_CODE_13, B1.OTH_DIAG_CODE_14, B1.OTH_DIAG_CODE_15, B1.OTH_DIAG_CODE_16, B1.OTH_DIAG_CODE_17, B1.OTH_DIAG_CODE_18, B1.OTH_DIAG_CODE_19, B1.OTH_DIAG_CODE_20, 
		B1.OTH_DIAG_CODE_21, B1.OTH_DIAG_CODE_22, B1.OTH_DIAG_CODE_23, B1.OTH_DIAG_CODE_24, E_CODE_1, E_CODE_2, E_CODE_3, E_CODE_4, E_CODE_5, E_CODE_6, E_CODE_7, E_CODE_8, E_CODE_9, E_CODE_10, CONDITION_CODE_1, CONDITION_CODE_2, CONDITION_CODE_3, CONDITION_CODE_4, CONDITION_CODE_5, CONDITION_CODE_6, CONDITION_CODE_7, CONDITION_CODE_8, PHYSICIAN1_INDEX_NUMBER, PHYSICIAN2_INDEX_NUMBER, CERT_STATUS, RECORD_ID, ''O''
	FROM [THCIC_DW].[dbo].[OP_PUDF_base_working] B1
	LEFT JOIN [THCIC_DW].[dbo].[OP_Facility_type_working] F1 ON F1.THCIC_ID = B1.THCIC_ID
	
----
	
--  PUDF CHARGES STAGING LOAD
	
	TRUNCATE TABLE THCIC_PUDF_Charges_Purna

	INSERT INTO [dbo].[THCIC_PUDF_Charges_Purna] ([RECORD_ID], [REVENUE_CODE], [HCPCS_QUALIFIER], [HCPCS_PROCEDURE_CODE], [MODIFIER_1], [MODIFIER_2], [MODIFIER_3], [MODIFIER_4], [UNIT_MEASUREMENT_CODE], [UNITS_OF_SERVICE], [UNIT_RATE], [CHRGS_LINE_ITEM], [CHRGS_NON_COV], SUBMISSION_PURPOSE)
	SELECT [RECORD_ID], [REVENUE_CODE], [HCPCS_QUALIFIER], [HCPCS_PROCEDURE_CODE], [MODIFIER_1], [MODIFIER_2], [MODIFIER_3], [MODIFIER_4], [UNIT_MEASUREMENT_CODE], CASE 
			WHEN [UNITS_OF_SERVICE] = ''.''
				THEN 999
			ELSE [UNITS_OF_SERVICE]
			END AS [UNITS_OF_SERVICE], [UNIT_RATE], [CHRGS_LINE_ITEM], [CHRGS_NON_COV], ''I''
	FROM [THCIC_DW].[dbo].[PUDF_charges_IPworking]

	UNION

	SELECT [RECORD_ID], [REVENUE_CODE], [HCPCS_QUALIFIER], [HCPCS_PROCEDURE_CODE], [MODIFIER_1], [MODIFIER_2], [MODIFIER_3], [MODIFIER_4], [UNIT_MEASUREMENT_CODE], CASE 
			WHEN [UNITS_OF_SERVICE] = ''.''
				THEN 999
			ELSE [UNITS_OF_SERVICE]
			END AS [UNITS_OF_SERVICE], [UNIT_RATE], [CHRGS_LINE_ITEM], [CHRGS_NON_COV], ''O''
	FROM [THCIC_DW].[dbo].[OP_PUDF_charges_working]

---

--  UPDATE SUBMISSION PURPOSE
	
	UPDATE A
	SET SUBMISSIONPURPOSE = B.SUBMISSIONPURPOSE
	FROM THCIC_PUDF_PURNA A JOIN IQSC_DATAWAREHOUSE..DIMBILLTYPE B
	ON A.TYPE_OF_BILL = B.BILLTYPECODE

	UPDATE B
	SET B.SUBMISSION_PURPOSE=SUBMISSIONPURPOSE
	FROM THCIC_PUDF_PURNA A JOIN  DBO.THCIC_PUDF_CHARGES_PURNA B
	ON A.RECORD_ID = B.RECORD_ID

	
-- FINAL STEP

	TRUNCATE TABLE THCIC.DBO.THCIC_PUDF_CHARGES
	DROP TABLE WORKTABLES.DBO.THCIC_PUDF_CHARGES_PURNA
	GO

	SELECT *
	INTO WORKTABLES.DBO.THCIC_PUDF_CHARGES_PURNA
	FROM THCIC_DW.dbo.THCIC_PUDF_CHARGES_PURNA
	GO

	INSERT INTO THCIC.dbo.THCIC_PUDF_CHARGES (RECORD_ID, REVENUE_CODE, HCPCS_QUALIFIER, HCPCS_PROCEDURE_CODE, MODIFIER_1, MODIFIER_2, MODIFIER_3, MODIFIER_4, UNIT_MEASUREMENT_CODE, UNITS_OF_SERVICE, UNIT_RATE, CHRGS_LINE_ITEM, CHRGS_NON_COV, SUBMISSION_PURPOSE)
	SELECT RECORD_ID, REVENUE_CODE, HCPCS_QUALIFIER, HCPCS_PROCEDURE_CODE, MODIFIER_1, MODIFIER_2, MODIFIER_3, MODIFIER_4, UNIT_MEASUREMENT_CODE, UNITS_OF_SERVICE, UNIT_RATE, CHRGS_LINE_ITEM, CHRGS_NON_COV, SUBMISSION_PURPOSE
	FROM THCIC_PUDF_CHARGES_PURNA
	GO

	TRUNCATE TABLE THCIC.DBO.THCIC_PUDF
	DROP TABLE WORKTABLES.DBO.THCIC_PUDF
	GO

	SELECT *
	INTO WORKTABLES.DBO.THCIC_PUDF
	FROM [THCIC].[DBO].THCIC_PUDF
	GO

	INSERT INTO [THCIC].[DBO].THCIC_PUDF
	SELECT *, SUBMISSIONPURPOSE
	FROM [THCIC_DW].[DBO].THCIC_PUDF_PURNA
	GO

	-- FIX DI_PART
	UPDATE TH
	SET TH.[DI_PART] = 0
	FROM [THCIC].[DBO].[THCIC_PUDF] TH(NOLOCK)
	WHERE TH.[DI_PART] IS NULL

	UPDATE TH
	SET TH.[DI_PART] = DH.DIPART
	FROM [THCIC].[DBO].[THCIC_PUDF] TH(NOLOCK)
	INNER JOIN IQSC_DATAWAREHOUSE.DBO.DIMHOSPITAL DH(NOLOCK) ON TH.THCIC_ID = DH.T_THCIC_HOSPITAL_ID
	WHERE TH.[DI_PART] IS NULL
		AND DH.DIPART = 1
		AND DH.ISACTIVE = 1
		AND TH.[THCIC_ID] != ''999998''



-- EXEC Below stored Procedures

	-- SET @cmd = ''USE IQSC_DW_Reporting''
	-- EXEC @cmd

	EXEC [THCIC].[dbo].[Load_QV_LOAD_THCIC]

	EXEC [THCIC].[dbo].[Load_Vertical_Diags_IP]

	EXEC [THCIC].[dbo].[Load_Vertical_Diags_OP]

	EXEC [THCIC].[dbo].[Load_Vertical_Procs_IP]', 
		@database_name=N'THCIC_DW', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Update HCPCS]    Script Date: 12/31/2015 08:46:45 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:45 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Update HCPCS', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=3, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\pyalavarthy', 
		@notify_email_operator_name=N'Purna', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [HCPCS_Update]    Script Date: 12/31/2015 08:46:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'HCPCS_Update', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'update F
set HCPCS_ProcedureCode=D.uid_hcpcs
    ,updatedate=getdate()
from (select max(dashboardid)as dashboardid 
from qedit_staging.dbo.TT_REV_11282014 
where uid_hcpcs<>''     ''
 group by uid_rev_code,uid_hcpcs,uid_key,uid_unit_code,uid_unit_rate,uid_units) d1
inner join qedit_staging.dbo.TT_REV_11282014  d on d1.dashboardid =d.dashboardid
inner join FACT_ClaimCharge F on  F.Claim_Key=d.Claim_Key 
and ChargeAmt=uid_tot_chrgs and 
Units=uid_units and UnitRate=uid_unit_rate 
and UnitMeasurementCode=uid_unit_code
and uid_rev_code=RevenueCode
and f.HCPCS_ProcedureCode=-1', 
		@database_name=N'IQSC_DataWarehouse', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Hcpcs_update', 
		@enabled=0, 
		@freq_type=1, 
		@freq_interval=0, 
		@freq_subday_type=0, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20150103, 
		@active_end_date=99991231, 
		@active_start_time=10033, 
		@active_end_time=235959, 
		@schedule_uid=N'8d3ec45d-108a-4c5a-9fdc-2f0fa716dab7'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [Update_DCP]    Script Date: 12/31/2015 08:46:45 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:45 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Update_DCP', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Update_PostalCode]    Script Date: 12/31/2015 08:46:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Update_PostalCode', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'update dcp
set PostalCode=	LEFT(COALESCE(PA.PostalCode,''''),5) 		 
	-- SELECT DCP.*
	FROM 	dbo.ClaimInformation C WITH (NOLOCK)
		--INNER JOIN DataWarehouse.BatchClaimList D ON C.ID = D.Claim_ID
		left join dbo.PatientInformation P (NOLOCK) on P.ID = C.Patient_FK
		--left join dbo.PatientName PN	on PN.Patient_FK = P.id
		LEFT JOIN (select max(id)as ID ,Patient_FK from dbo.PatientDemographics (NOLOCK)
						group by Patient_FK) PD1
		ON PD1.Patient_FK = P.id 
		left join dbo.PatientDemographics PD (NOLOCK) on PD1.ID = PD.id
		LEFT JOIN (select max(id)as ID,Patient_FK from dbo.PatientAddress  (NOLOCK)
						group by Patient_FK) PA1 ON PA1.Patient_FK = P.id
		LEFT JOIN dbo.PatientAddress PA (NOLOCK) ON PA.ID = Pa1.id
			join iqsc_datawarehouse..dimclaimpatient dcp (NOLOCK) on dcp.PatientControlNumber=left(LTRIM(RTRIM(C.PatientControlNumber)),25)
where dcp.postalcode=''-1''
		 ', 
		@database_name=N'DFWHC_Staging', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Update_PostalCode', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=127, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20150301, 
		@active_end_date=99991231, 
		@active_start_time=60000, 
		@active_end_time=235959, 
		@schedule_uid=N'44653ec1-9e0a-4648-acf1-e05d31375633'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [UpdateStats.Subplan_1]    Script Date: 12/31/2015 08:46:45 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 12/31/2015 08:46:45 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'UpdateStats.Subplan_1', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'Purna', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Subplan_1]    Script Date: 12/31/2015 08:46:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Subplan_1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/SQL "Maintenance Plans\UpdateStats" /SERVER "HV10\IQSC01" /CHECKPOINTING OFF /SET "\Package\Subplan_1.Disable";false /REPORTING E', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'UpdateStats', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151229, 
		@active_end_date=99991231, 
		@active_start_time=10000, 
		@active_end_time=235959, 
		@schedule_uid=N'229a0449-9c6e-4f11-b55a-09e325b109b2'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [UserBackup.Subplan_1]    Script Date: 12/31/2015 08:46:45 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [Database Maintenance]    Script Date: 12/31/2015 08:46:45 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'Database Maintenance' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'Database Maintenance'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'UserBackup.Subplan_1', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'Database Maintenance', 
		@owner_login_name=N'DFWHC\pyalavarthy', 
		@notify_email_operator_name=N'Purna', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Subplan_1]    Script Date: 12/31/2015 08:46:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Subplan_1', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'SSIS', 
		@command=N'/Server "$(ESCAPE_NONE(SRVR))" /SQL "Maintenance Plans\UserBackup" /set "\Package\Subplan_1.Disable;false"', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'UseDBrbackup', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=62, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20151229, 
		@active_end_date=99991231, 
		@active_start_time=220000, 
		@active_end_time=235959, 
		@schedule_uid=N'2ef701ed-3c71-4556-9915-f33880dfbfd2'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [usp_claimids_batch_tmp load]    Script Date: 12/31/2015 08:46:45 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:45 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'usp_claimids_batch_tmp load', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\DATAINITSQLAGENT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [usp_claimids_batch_tmp]    Script Date: 12/31/2015 08:46:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'usp_claimids_batch_tmp', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'insert into BatchClaimList_temp

SELECT    D.HospitalClaimDataFile_ID ,
 D.DQA_Hospital_ID , D.THCIC_Hospital_id , D.IQSC_Hospital_ID ,
  LEFT(C.PatientControlNumber,25) AS PatientControlNumber ,
   D.SubmissionPurpose , FT.PCN_DQA_Claim_Count , 
   MAX(C.ID) AS Claim_ID   
   ,D.Batch_ID 

   FROM dbo.ClaimInformation C WITH (NOLOCK)  
    INNER JOIN DataWarehouse.Claim_ID_Range_tmp D WITH (NOLOCK)  
     ON C.ID BETWEEN Begin_DQA_Claim_ID AND End_DQA_Claim_ID  
      INNER JOIN    [dbo].[tmp_claimrange]  FT ON FT.THCIC_Hospital_ID = D.THCIC_Hospital_ID AND FT.PatientControlNumber = C.PatientControlNumber AND FT.SubmissionPurpose = D.SubmissionPurpose  
                  WHERE C.ClaimFrequencyType = FT.ClaimFrequencyType  -- PRDR6328 --    
                  --AND C.PatientControlNumber = ''PRDR7517''  --> ADDED WGW 10/25/2011 Temporary --  
                  --  AND C.ID = 13802242   
                      GROUP BY D.Batch_ID, D.HospitalClaimDataFile_ID, D.DQA_Hospital_ID, D.THCIC_Hospital_id, IQSC_Hospital_ID, C.PatientControlNumber, D.SubmissionPurpose, FT.PCN_DQA_Claim_Count

        
', 
		@database_name=N'DFWHC_Staging', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [xx]    Script Date: 12/31/2015 08:46:45 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:45 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'xx', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\pyalavarthy', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [xx]    Script Date: 12/31/2015 08:46:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'xx', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [IQSC_DataWarehouse] FROM  DISK = N''N:\Database_Backup\HV10$IQSC01_IQSC_DataWarehouse_FULL_20140411_021624.bak'' 
WITH  FILE = 1,
  MOVE N''IQSC_Warehouse_DB'' TO N''L:\SQLDATA\DATA Files\IQSC_DataWarehouse.mdf'',
    MOVE N''IQSC_Warehouse_DB1'' TO N''L:\SQLDATA\DATA Files\IQSC_DataWarehouse_1.ndf'',
      MOVE N''IQSCPARFILE01'' TO N''N:\SQLDATA\IQSC_DataWarehouse_2.ndf'',  
      MOVE N''IQSCPARFILE02'' TO N''N:\SQLDATA\IQSC_DataWarehouse_3.ndf'',
        MOVE N''IQSCPARFILE03'' TO N''N:\SQLDATA\IQSC_DataWarehouse_4.ndf'', 
         MOVE N''IQSCPARFILE04'' TO N''N:\SQLDATA\IQSC_DataWarehouse_5.ndf'',
           MOVE N''IQSCPARFILE05'' TO N''L:\SQLDATA\DATA Files\IQSC_DataWarehouse_6.ndf'',
             MOVE N''IQSCPARFILE07'' TO N''L:\SQLDATA\DATA Files\IQSC_DataWarehouse_7.ndf'', 
              MOVE N''IQSC_Warehouse_DB_log'' TO N''I:\SQLLOGS\IQSCLOGS\IQSC_DataWarehouse_8.LDF'',
                NOUNLOAD,  STATS = 10
GO
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

/****** Object:  Job [xxx]    Script Date: 12/31/2015 08:46:45 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 12/31/2015 08:46:45 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'xxx', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'DFWHC\DATAINITSQLAGENT', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [xxx]    Script Date: 12/31/2015 08:46:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'xxx', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'RESTORE DATABASE [DFWHC_Staging] FROM  DISK = N''M:\IQSC_DataWarehouse\SQL02$IQSC01_DFWHC_Staging_FULL_20130809_011633.bak''
 WITH  FILE = 1,  
 MOVE N''DFWHC_Staging'' TO N''M:\SQLDATA\IQSC\DFWHC_Staging.mdf'', 
  MOVE N''DFWHC_Staging1'' TO N''M:\SQLDATA\IQSC\DFWHC_Staging_1.ndf'', 
   MOVE N''DFWHC_Staging_log'' TO N''I:\SQLLOGS\IQSCLOGS\DFWHC_Staging.ldf'',  NOUNLOAD,  REPLACE,  STATS = 10
GO
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

