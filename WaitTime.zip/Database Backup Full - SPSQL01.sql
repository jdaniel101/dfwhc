DECLARE @name		VARCHAR(50)	-- database name  
DECLARE @path		VARCHAR(256)	-- path for backup files  
DECLARE @fileName	VARCHAR(256)	-- filename for TRN backup
DECLARE @path1		VARCHAR(256)	-- path for log backup files  
DECLARE @fileName1	VARCHAR(256)	-- filename for Log backup
DECLARE @diffname	VARCHAR(256)	-- differential name
DECLARE @fileDate	VARCHAR(20)	-- used for file name
DECLARE @cmd NVARCHAR(500)  

-- specify database backup directory
SET @path = '\\dfwhc-share\B\SQLBackups\SharePoint2013_Backups\'  

-- specify database backup directory
SET @path1 = 'E:\SQLLOGS\'  

 
-- specify filename format
SELECT @fileDate = CONVERT(VARCHAR(20),GETDATE(),112) 

 
DECLARE db_cursor CURSOR FOR  
SELECT name 
FROM master.dbo.sysdatabases 
WHERE name NOT IN ('master','model','msdb','tempdb','DBBackups')

OPEN db_cursor   
FETCH NEXT FROM db_cursor INTO @name   


WHILE @@FETCH_STATUS = 0   
BEGIN
       SET @cmd = 'USE ' + @name 
       EXEC (@cmd) 

       SET @cmd = 'ALTER DATABASE ' + @name + ' SET SINGLE_USER'
       EXEC (@cmd)
       
       SET @fileName = @path + @name + '.BAK'
       
       BACKUP DATABASE @name TO DISK = @fileName
       WITH FORMAT

       SET @fileName1 = @path1 + @name + '.LDF'

       BACKUP LOG @name TO DISK = @fileName1  
       WITH FORMAT
 
       SET @cmd = 'ALTER DATABASE ' + @name +' SET MULTI_USER'
       EXEC (@cmd)
       
       FETCH NEXT FROM db_cursor INTO @name   
END   

 
CLOSE db_cursor   
DEALLOCATE db_cursor