--EXEC RestoreDB 'F'

create table #temp(name varchar(255));
insert into #temp(name) values ('DBBackups')
insert into #temp(name) values ('DFWHC_AppManagement')
insert into #temp(name) values ('DFWHC_Config_2013')
insert into #temp(name) values ('DFWHC_Content_Admin')
insert into #temp(name) values ('DFWHC_Content_External')
insert into #temp(name) values ('DFWHC_Content_Intranet')
insert into #temp(name) values ('DFWHC_Content_IT')
insert into #temp(name) values ('DFWHC_Content_MySites')
insert into #temp(name) values ('DFWHC_Content_Portal')
insert into #temp(name) values ('DFWHC_Content_SFT')
insert into #temp(name) values ('DFWHC_MetaData')
insert into #temp(name) values ('DFWHC_Profile')
insert into #temp(name) values ('DFWHC_Search')
insert into #temp(name) values ('DFWHC_Search_AnalyticsReportingStore')
insert into #temp(name) values ('DFWHC_Search_CrawlStore')
insert into #temp(name) values ('DFWHC_Search_LinksStore')
insert into #temp(name) values ('DFWHC_SecureStore')
insert into #temp(name) values ('DFWHC_SessionState')
insert into #temp(name) values ('DFWHC_Social')
insert into #temp(name) values ('DFWHC_StateService')
insert into #temp(name) values ('DFWHC_SubscriptionSettings')
insert into #temp(name) values ('DFWHC_Sync')
insert into #temp(name) values ('DFWHC_UsageAndHealth')
insert into #temp(name) values ('GP1_Content_Reporting');

select 'RESTORE DATABASE ' + name + ' FROM DISK = N'''  
				   + 'C:\temp\'+ name  + '%.bak'' WITH FILE = 1, NOUNLOAD,  REPLACE,  STATS = 10' 
FROM #temp

exec RestoreDB 'F'