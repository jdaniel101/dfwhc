USE [master]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

DECLARE @Database VARCHAR(255)
DECLARE @cmd VARCHAR(830)
DECLARE @SvrName VARCHAR(35)

SET @SvrName = (select name from sys.servers
				where server_id = 0)
				
--IF OBJECT_ID ('tempdb.dbo.#temp', 'U') IS NOT NULL 
--   DROP TABLE #temp;

SET @cmd = 'SELECT ''' + @SvrName + ''' as SvrName,f.name AS Name, f.physical_name AS File_Location, f.type AS [Type], f.type_desc AS [Type_Desc], CONVERT(Decimal(15, 2), ROUND(a.size / 128.000, 2)) AS [Currently Allocated Space (MB)], CONVERT(Decimal(15, 2), 
                  ROUND(FILEPROPERTY(a.name, [SpaceUsed]) / 128.000, 2)) AS [Space Used (MB)], CONVERT(Decimal(15, 2), ROUND((a.size - FILEPROPERTY(a.name, [Space Used])) 
                  / 128.000, 2)) AS [Available Space (MB)], f.max_size AS [Max Size], f.growth AS [Growth], f.is_percent_growth AS [PercentGrowth], f.is_media_read_only
			FROM         sys.sysfiles AS a WITH (NOLOCK) INNER JOIN
                  sys.sysfilegroups AS b WITH (NOLOCK) ON a.groupid = b.groupid INNER JOIN
                  sys.database_files AS f ON f.name = a.name
			ORDER BY b.groupname'
EXEC (@cmd)


--SET @cmd = 'INSERT INTO #temp
--				   ([SvrName]
--				   ,[Name]
--				   ,[File_Location]
--				   ,[Type]
--				   ,[Type_Desc]
--				   ,[Currently Allocated Space (MB)]
--				   ,[Space Used (MB)]
--				   ,[Available Space (MB)]
--				   ,[Max Size]
--				   ,[Growth]
--				   ,[PercentGrowth]
--				   ,[is_media_read_only]) SELECT ''' + @SvrName + ''' as SvrName,f.name AS Name, f.physical_name AS File_Location, f.type AS [Type], f.type_desc AS [Type_Desc], CONVERT(Decimal(15, 2), ROUND(a.size / 128.000, 2)) AS ''Currently Allocated Space (MB)'', CONVERT(Decimal(15, 2), 
--                  ROUND(FILEPROPERTY(a.name, ''SpaceUsed'') / 128.000, 2)) AS ''Space Used (MB)'', CONVERT(Decimal(15, 2), ROUND((a.size - FILEPROPERTY(a.name, ''SpaceUsed'')) 
--                  / 128.000, 2)) AS ''Available Space (MB)'', f.max_size AS [Max Size], f.growth AS ''Growth'', f.is_percent_growth AS ''PercentGrowth'', f.is_media_read_only
--			FROM         sys.sysfiles AS a WITH (NOLOCK) INNER JOIN
--								  sys.sysfilegroups AS b WITH (NOLOCK) ON a.groupid = b.groupid INNER JOIN
--								  sys.database_files AS f ON f.name = a.name
--			ORDER BY b.groupname'
--EXEC (@cmd)

--SET @cmd = '
--select * from tempdb.dbo.#temp --' -- where file_location like ''L:\%'' order by Growth'
--EXEC (@cmd)

--SET @cmd = 'select * from #temp where file_location like ''M:\%'' order by Growth'
--EXEC (@cmd)

SELECT     'HV10' AS SvrName, f.name AS Name, f.physical_name AS File_Location, f.type AS Type, f.type_desc AS Type_Desc, CONVERT(Decimal(15, 2), ROUND(a.size / 128.000, 2)) 
                      AS [Currently Allocated Space (MB)], CONVERT(Decimal(15, 2), ROUND(FILEPROPERTY(a.name, 'SpaceUsed') / 128.000, 2)) AS [Space Used (MB)], CONVERT(Decimal(15, 2), 
                      ROUND((a.size - FILEPROPERTY(a.name, 'SpaceUsed')) / 128.000, 2)) AS [Available Space (MB)], f.max_size AS [Max Size], f.growth AS Growth, f.is_percent_growth AS PercentGrowth, 
                      f.is_media_read_only
FROM         sys.sysfiles AS a WITH (NOLOCK) INNER JOIN
                      sys.sysfilegroups AS b WITH (NOLOCK) ON a.groupid = b.groupid INNER JOIN
                      sys.database_files AS f ON f.name = a.name
ORDER BY b.groupname