Use Master
 GO

 EXEC master.dbo.sp_configure 'show advanced options', 1
 RECONFIGURE WITH OVERRIDE
 GO

 EXEC master.dbo.sp_configure 'xp_cmdshell', 1
 RECONFIGURE WITH OVERRIDE
 GO


EXEC xp_cmdshell 'net use O: /delete'  -- Disconnected Network Drive (M:)

-- Connected Network Drive (M:)
EXEC xp_cmdshell 'net use O: "\\dfwf-share\SQL Backups\HV10\THCIC" Welcome9999! /USER:DFWHC\Joseph-Johnson /PERSISTENT:no'

RESTORE FILELISTONLY 
FROM DISK = 'O:\THCIC_backup_2015_11_13_220005_1524240.bak'

RESTORE DATABASE [THCIC] FROM DISK = N'O:\THCIC_backup_2015_11_13_220005_1524240.bak' 
WITH
MOVE 'THCIC' TO 'O:\THCIC2.mdf', 
MOVE 'THCIC_1' TO 'O:\THCIC_12.ndf', 
MOVE 'THCIC_Log' TO 'O:\THCIC_12.ldf', 
REPLACE