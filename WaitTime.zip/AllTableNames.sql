
declare @SQL nvarchar(max)

set @SQL = (select 'union all 
select '''+D.name+''' as DatabaseName,
       T.name collate database_default as TableName
from '+quotename(D.name)+'.sys.tables as T
'
from sys.databases as D
WHERE D.name NOT IN ('master','msdb','tempdb','model','distribution','AAA_Study','BHVH_Experience','IQSC_DW_QV') 
for xml path(''), type).value('substring((./text())[1], 13)', 'nvarchar(max)')

--print @SQL
exec (@SQL)