

--Here is one I wrote myself years ago. This is a section of a larger stored procedure, but it works fine on its own. You can modify the filters to remove unwanted entires as well as highlight others.
print ' '
print ' '
print '==================='
print '== SQL Errorlogs =='
print '==================='
print ' '


declare
  @FirstLog      smallint, 
  @LastLog       smallint,
  @BufferRecords smallint,
  @SQL           varchar(2000),
  @Output        varchar(2000)

select
  @FirstLog      = 0, --> Defaults to current logfile
  @LastLog       = 1, --> Defaults to logfile immediately preceding current
  @BufferRecords = 4  --> Used to give a frame of reference to the error message

---------------------------------------------------------------------------------------------------
-- Date Created: July 11, 2005
-- Author:       Bill McEvoy
-- Description:  This procedure combines and parses the SQL Error Logs.  Entries of special 
--               interest are marked which allows the operator to quickly scan the output for
--               errors.  Entries of interest are removed from the output.  Entries before and
--               after the errors are included to give a frame of reference.
--               
---------------------------------------------------------------------------------------------------
-- Date Revised: December 7, 2006
-- Author:       Bill McEvoy
-- Reason:       I converted this procedure to support SQL Server 2005
---------------------------------------------------------------------------------------------------
set nocount on
declare @count  smallint,
        @alert  char(5)

select  @count  = 0,
        @SQL    = '',
        @output = '',
        @alert  = '---->'

---------------------------------------------------------------------
-- Validate input parameters                                       --
---------------------------------------------------------------------

IF (@FirstLog > @LastLog)
BEGIN
  select @lastLog = @FirstLog + 1
END


---------------------------------------------------------------------
-- M A I N   P R O C E S S I N G                                   --
---------------------------------------------------------------------
--                                                                 --
-- Create work tables                                              --
--                                                                 --
-- Import SQL Error Logs                                           --
--                                                                 --
-- Remove unwanted entries                                         --
--                                                                 --
-- Mark items of interest                                          --
--                                                                 --
-- Generate report                                                 --
--                                                                 --
---------------------------------------------------------------------


---------------------------------------------------------------------
-- Create work tables                                              --
---------------------------------------------------------------------

IF (object_id('tempdb..#ERRORLOG') IS NOT NULL)
  drop table #ERRORLOG

CREATE TABLE #ERRORLOG
(
  LogID       int identity primary key clustered,
  LogDate     datetime NULL,
  ProcessInfo varchar(12) NULL, 
  Alert       char(5) default ' ',
  LogEntry    varchar(900) NULL,
  Row         smallint NULL

)

-- Add indexes
create index [IX_ERRORLOG_Alert]    on dbo.[#ERRORLOG](Alert)    with fillfactor = 98 on [PRIMARY]
create index [IX_ERRORLOG_LogEntry] on dbo.[#ERRORLOG](LogEntry) with fillfactor = 98 on [PRIMARY]


---------------------------------------------------------------------
-- Import SQL Error Logs                                           --
---------------------------------------------------------------------

select @count = @FirstLog



  WHILE (@Count <= @LastLog) 
  BEGIN
    insert into #ERRORLOG (ProcessInfo, Alert, LogEntry) values (' ','',' ')
    insert into #ERRORLOG (ProcessInfo, Alert, LogEntry) values (' ','',' ')
    insert into #ERRORLOG (ProcessInfo, Alert, LogEntry) values (' ','',' ')
    insert into #ERRORLOG (ProcessInfo, Alert, LogEntry) values (' ','','------------------------------')
    select @output = '-- Processing: ERRORLOG' + case(@count) when 0 then '    ' else '.' + convert(char(3), @count) end + ' --'
    insert into #ERRORLOG (ProcessInfo, Alert, LogEntry) values (' ','',@output)
    insert into #ERRORLOG (ProcessInfo, Alert, LogEntry) values (' ','','------------------------------')
    insert into #ERRORLOG (ProcessInfo, Alert, LogEntry) values (' ','',' ')
    select @SQL = 'exec master..sp_readerrorlog ' + convert(varchar(3), @count)
    insert into #errorlog (LogDate, ProcessInfo, LogEntry)
    execute (@SQL)
    select @count = @count + 1
  END

---------------------------------------------------------------------
-- Remove unwanted entries                                         --
---------------------------------------------------------------------


delete 
  from #ERRORLOG 
 where LogEntry like '%Bypassing recovery for database%'
    or LogEntry like '%Setting database option ANSI_WARNINGS%'
    or LogEntry like '%Log backed up with following information:%'
    or LogEntry like '%Login succeeded for user%'
    or LogEntry like '%found 0 errors and repaired 0 errors%'
    or LogEntry like '%Database differential changes%'
    or LogEntry like '%The certificate was successfully loaded%'
    or LogEntry like '%this is an informational message only%'
    or LogEntry like '%logging sql server messages in file%'
    or LogEntry like '%Recovery complete.%'
    or LogEntry like '%Starting up database ''ERROR_LOGGING''%'
    or LogEntry like '%Database backed up: Database: %'
    or LogEntry like '%Log backed up: Database: %'
    or LogEntry like '%allocate%'




---------------------------------------------------------------------
-- Mark items of interest                                          --
---------------------------------------------------------------------

update #ERRORLOG
   set Alert = @alert
 where (LogEntry like '%err%'
    or  LogEntry like '%exception%'
    or  LogEntry like '%violation%'
    or  LogEntry like '%warn%'
    or  LogEntry like '%kill%'
    or  LogEntry like '%dead%'
    or  LogEntry like '%encounter%'
    or  LogEntry like '%cannot%'
    or  LogEntry like '%could%'
    or  LogEntry like '%fail%'
    or  LogEntry like '%full%'
    or  LogEntry like '%not%'
    or  LogEntry like '%terminate%'
    or  LogEntry like '%bypass%'
    or  LogEntry like '%recover%'
    or  LogEntry like '%roll%'
    or  LogEntry like '%upgrade%'
    or  LogEntry like '%victim%'
    or  LogEntry like '%stop%'
    or  LogEntry like '%shut%'
    or  LogEntry like '%timed out%'
    or  LogEntry like '%truncate%'
    or  LogEntry like '%terminat%')
   and  (ProcessInfo <> ' ' or  ProcessInfo IS NULL)



---------------------------------------------------------------------
-- Generate report                                                 --
---------------------------------------------------------------------


BEGIN

  -- Show entries of interest + buffer records
  select A.LogID,
         'Date'       = isnull(convert(varchar(19), A.LogDate, 120), ''),
         A.ProcessInfo,
         A.Alert,
         'Descripton' = left(A.logEntry, 250)
    from #ERRORLOG A
   join (select LogID from #ERRORLOG where Alert = @alert) B  on (A.LogID >= (B.LogID - @BufferRecords))
                                                           and (A.LogID <= (B.LogID + @BufferRecords))

  -- Show informational records
  union
  select A.LogID,
         'Date'       = isnull(convert(varchar(19), A.LogDate, 120), ''),
         A.ProcessInfo,
         A.Alert,
         'Descripton' = left(A.logEntry, 250)
    from #ERRORLOG A
   where ProcessInfo = ''
   order by A.LogID
END
 