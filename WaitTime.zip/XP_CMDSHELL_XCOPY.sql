
EXEC xp_cmdshell 'net use X: /delete'  -- Disconnected Network Drive (X:)

-- Connected Network Drive (M:)
EXEC xp_cmdshell 'net use X: "\\DFWF-Share\DFWF\HV10" Welcome9999! /USER:DFWHC\Joseph-Johnson /PERSISTENT:yes'

EXEC xp_cmdshell 'net use O: /delete'  -- Disconnected Network Drive (O:)

-- Connected Network Drive (M:)
EXEC xp_cmdshell 'net use O: "\\dfwf-share\SQL Backups\HV10" Welcome9999! /USER:DFWHC\Joseph-Johnson /PERSISTENT:yes'


-- Copy Backups to New Folder
EXEC XP_CMDSHELL 'XCOPY X: O: /S /Y /D:11-01-2015'