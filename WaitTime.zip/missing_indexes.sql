--select * from sys.indexes

--SELECT     SCHEMA_NAME(o.schema_id) AS SchemaName, OBJECT_NAME(o.object_id) AS ObjectName, o.type AS ObjectType, s.name AS StatsName, STATS_DATE(o.object_id, s.stats_id) AS StatsDate
--FROM         sys.stats AS s INNER JOIN
--                      sys.objects AS o ON o.object_id = s.object_id
--WHERE     (OBJECTPROPERTY(o.object_id, N'ISMSShipped') = 0) AND (LEFT(s.name, 4) <> '_WA_')
--ORDER BY ObjectType, SchemaName, ObjectName, StatsName
--
-- How to find missing indexes?
--
EXEC sp_MSforeachdb 'USE ? SELECT     OBJECT_NAME(mid.object_id) AS TableName, migs.user_seeks AS Seeks, mid.equality_columns AS Equality, mid.inequality_columns AS Inequality, mid.included_columns AS Included, 
                      mid.statement AS Statement
FROM         sys.dm_db_missing_index_details AS mid INNER JOIN
                      sys.dm_db_missing_index_groups AS mig ON mid.index_handle = mig.index_handle INNER JOIN
                      sys.dm_db_missing_index_group_stats AS migs ON migs.group_handle = mig.index_group_handle
WHERE     (mid.database_id = DB_ID())
ORDER BY TableName'
GO

EXEC sp_MSforeachdb 'USE ? 
SELECT     (migs.avg_total_user_cost * (migs.avg_user_impact / 100.0)) * (migs.user_seeks + migs.user_scans) AS improvement_measure, ''CREATE INDEX [missing_index_'' + CONVERT(varchar, 
                      mig.index_group_handle) + ''_'' + CONVERT(varchar, mid.index_handle) + ''_'' + LEFT(PARSENAME(mid.statement, 1), 32) + '']'' + '' ON '' + mid.statement + '' ('' + ISNULL(mid.equality_columns, '''') 
                      + CASE WHEN mid.equality_columns IS NOT NULL AND mid.inequality_columns IS NOT NULL THEN '','' ELSE '''' END + ISNULL(mid.inequality_columns, '''') 
                      + '')'' + ISNULL('' INCLUDE ('' + mid.included_columns + '')'', '''') AS create_index_statement, migs.group_handle, migs.unique_compiles, migs.user_seeks, migs.user_scans, migs.last_user_seek, 
                      migs.last_user_scan, migs.avg_total_user_cost, migs.avg_user_impact, migs.system_seeks, migs.system_scans, migs.last_system_seek, migs.last_system_scan, migs.avg_total_system_cost, 
                      migs.avg_system_impact, mid.database_id, mid.object_id
FROM         sys.dm_db_missing_index_groups AS mig INNER JOIN
                      sys.dm_db_missing_index_group_stats AS migs ON migs.group_handle = mig.index_group_handle INNER JOIN
                      sys.dm_db_missing_index_details AS mid ON mig.index_handle = mid.index_handle
WHERE     ((migs.avg_total_user_cost * (migs.avg_user_impact / 100.0)) * (migs.user_seeks + migs.user_scans) > 10)
ORDER BY (migs.avg_total_user_cost * migs.avg_user_impact) * (migs.user_seeks + migs.user_scans) DESC'