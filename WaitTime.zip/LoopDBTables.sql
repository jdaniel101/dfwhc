USE master
GO

DECLARE @Database VARCHAR(255)
DECLARE @cmd NVARCHAR(500)  
DECLARE @Table VARCHAR(255)  

DECLARE DatabaseCursor CURSOR FOR  
SELECT name FROM master.dbo.sysdatabases   
WHERE name NOT IN ('master','msdb','tempdb','model','distribution','DFWHC_Content_External')
ORDER BY 1  

OPEN DatabaseCursor  

FETCH NEXT FROM DatabaseCursor INTO @Database  
WHILE @@FETCH_STATUS = 0  
BEGIN

	SET @cmd = 'USE ' + @Database
	EXEC (@cmd) 
   
	SET @cmd = 'DECLARE TableCursor CURSOR FOR  
	SELECT name FROM ' + @Database + '.sys.tables'
	EXEC (@cmd)
	
	OPEN TableCursor  

	FETCH NEXT FROM TableCursor INTO @Table  
	WHILE @@FETCH_STATUS = 0  
	BEGIN
		SET @cmd = 'SELECT * FROM ' + @Database + '.dbo.' + @Table
		EXEC (@cmd)
		
		FETCH NEXT FROM TableCursor INTO @Table  
	END  
	CLOSE TableCursor 
	  
	DEALLOCATE TableCursor 
FETCH NEXT FROM DatabaseCursor INTO @Database  
END  

CLOSE DatabaseCursor   
DEALLOCATE DatabaseCursor 