/****** Script for SelectTopNRows command from SSMS  ******/
SELECT [hospid]
      ,[hospital_id]
      ,[systemname]
      ,[hospitalname]
      ,[folderpath]
      ,[Notes]
  FROM [File_Transfer].[dbo].[thospital]
  
 SELECT     ID, hospid, userid
FROM         tuser_n_hosp

SELECT     userid, fname, lname, username, password, email, phone
FROM         tusers

======================================================

SELECT     h.hospid, h.hospital_id, h.systemname, h.hospitalname, h.folderpath, h.Notes, uh.ID, uh.hospid AS Expr1, uh.userid, u.userid AS Expr2, u.fname, u.lname, u.username, u.password, u.email, 
                      u.phone
FROM         thospital AS h INNER JOIN
                      tuser_n_hosp AS uh ON h.hospid = uh.hospid INNER JOIN
                      tusers AS u ON uh.userid = u.userid
ORDER BY h.hospid