 --database name
 --logical file name
 --file type (row, logs, etc)
 --filegroup
 --allocated space
 --used space
 --max size
 --growth rate
 --percent growth
 --drive/mountpoint path
 USE InventoryDB
 GO
 
 SELECT     f.name AS Name, f.physical_name AS File_Location, f.type AS [Type], f.type_desc AS [Type_Desc], CONVERT(Decimal(15, 2), ROUND(a.size / 128.000, 2)) AS [Currently Allocated Space (MB)], CONVERT(Decimal(15, 2), 
                      ROUND(FILEPROPERTY(a.name, 'SpaceUsed') / 128.000, 2)) AS [Space Used (MB)], CONVERT(Decimal(15, 2), ROUND((a.size - FILEPROPERTY(a.name, 'SpaceUsed')) 
                      / 128.000, 2)) AS [Available Space (MB)], f.max_size AS [Max Size], f.growth AS [Growth], f.is_percent_growth AS [PercentGrowth], f.is_media_read_only
FROM         sys.sysfiles AS a WITH (NOLOCK) INNER JOIN
                      sys.sysfilegroups AS b WITH (NOLOCK) ON a.groupid = b.groupid INNER JOIN
                      sys.database_files AS f ON f.name = a.name
ORDER BY b.groupname


select * from sys.sysfiles

 --select * from sys.database_files
 
SELECT
b.groupname AS 'File Group', 
Name,  
[Filename], 
CONVERT (Decimal(15,2),ROUND(a.Size/128.000,2))  
[Currently Allocated Space (MB)], 
CONVERT (Decimal(15,2), 
ROUND(FILEPROPERTY(a.Name,'SpaceUsed')/128.000,2))    
AS [Space Used (MB)], 
CONVERT (Decimal(15,2), 
ROUND((a.Size-FILEPROPERTY(a.Name,'SpaceUsed'))/128.000,2))    
AS [Available Space (MB)] 
FROM dbo.sysfiles a (NOLOCK) 
JOIN sysfilegroups b (NOLOCK) ON a.groupid = b.groupid 
ORDER BY b.groupname