-- Shrinkfile Log


--Note: First Change DB to "Simple" Recovery Mode


USE DFWHC_UsageAndHealth; 
CHECKPOINT;
DBCC SHRINKFILE (N'DFWHC_UsageAndHealth_log' , 0)


DBCC SHRINKFILE (N'DFWHC_Config_2013_log' , 0)

DBCC SQLPERF(logspace)

DBCC LOGINFO(DatabaseName)