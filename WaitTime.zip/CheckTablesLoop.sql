DECLARE @cmd VARCHAR(8000)

SELECT @cmd = 'IF ''@'' NOT IN (''master'',''model'',''msdb'',''tempdb'')
BEGIN
	USE [@] 
	DBCC CHECKCATALOG(@)
	DBCC CHECKALLOC(@)
	EXECUTE sp_MSForEachTable  ''DBCC CHECKTABLE(''' + '''?''' + ''') WITH ALL_ERRORMSGS ''
END'

EXEC sp_MSforeachdb @cmd, '@'