DBCC CHECKTABLE(DEX_SESSION)



DECLARE @Database VARCHAR(255)
DECLARE @cmd NVARCHAR(500)  


DECLARE DatabaseCursor CURSOR FOR  
SELECT name FROM master.dbo.sysdatabases   
WHERE name in (
'HHRA')
--WHERE name NOT IN ('master','msdb','tempdb','model','distribution',
ORDER BY 1  

OPEN DatabaseCursor  

FETCH NEXT FROM DatabaseCursor INTO @Database  
WHILE @@FETCH_STATUS = 0  
BEGIN  

   SELECT @Database
   
   SET @cmd = 'Use ' + @Database 
   EXEC (@cmd) 

   SET @cmd = 'ALTER DATABASE ' + @Database + ' SET SINGLE_USER'
   EXEC (@cmd)

   SET @cmd = 'DBCC CHECKDB(' + @Database + ', REPAIR_ALLOW_DATA_LOSS) WITH ALL_ERRORMSGS'
   EXEC (@cmd)


-- SET @cmd = 'DBCC CHECKALLOC(' + @Database + ', REPAIR_FAST)'
-- EXEC (@cmd)


-- SET @cmd = 'DBCC CHECKTABLE(' + @Database + ', REPAIR_FAST)'
-- EXEC (@cmd)


-- SET @cmd = 'DBCC CHECKCATALOG(' + @Database + ')'
-- EXEC (@cmd)


   SET @cmd = 'ALTER DATABASE ' + @Database +' SET MULTI_USER'
   EXEC (@cmd) 
   --select @cmd

   FETCH NEXT FROM DatabaseCursor INTO @Database  
END  
CLOSE DatabaseCursor   
DEALLOCATE DatabaseCursor 