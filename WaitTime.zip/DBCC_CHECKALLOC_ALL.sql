DECLARE @cmd VARCHAR(8000);

SET @cmd = 'USE ?; 	
	DBCC CHECKALLOC(?);EXEC sp_MSforeachtable ''DBCC CHECKTABLE(?)'''

EXEC sp_msforeachdb @command1 =@cmd