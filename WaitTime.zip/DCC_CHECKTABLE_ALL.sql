DECLARE @Database VARCHAR(255)
DECLARE @Table VARCHAR(255)  
DECLARE @tname VARCHAR(255) 
DECLARE @sname VARCHAR(255) 
DECLARE @cmd NVARCHAR(500)  
DECLARE @fillfactor INT 

SET @fillfactor = 90 

--IF OBJECT_ID ('tempdb.dbo.#dblist', 'U') IS NOT NULL 
--   DROP TABLE #dblist;

DECLARE DatabaseCursor CURSOR FOR 
SELECT name FROM sys.databases
WHERE (DB_NAME(database_id) IN ('HHRA')) 
ORDER BY name desc


OPEN DatabaseCursor  

FETCH NEXT FROM DatabaseCursor INTO @Database  
WHILE @@FETCH_STATUS = 0  
BEGIN  


   SET @cmd = 'ALTER DATABASE ' + @Database + ' SET SINGLE_USER'
   EXEC (@cmd)
       
   SET @cmd = 'USE ' + @Database 
   EXEC (@cmd)

   SET @cmd = 'DBCC CHECKCATALOG(' + @Database + ')'
   EXEC (@cmd)	
     
   SET @cmd = 'DBCC CHECKALLOC(' + @Database + ')'
   EXEC (@cmd)   
   
 -- create table cursor 
   SET @cmd = 'DECLARE TableCursor CURSOR FOR SELECT ''['' + table_catalog + ''].['' + table_schema + ''].['' + 
	  table_name + '']'' as tableName, table_name as tname, table_schema as sname FROM [' + @Database + '].INFORMATION_SCHEMA.TABLES 
	  WHERE table_type = ''BASE TABLE'' ORDER BY tname desc'   
   EXEC (@cmd)

   OPEN TableCursor   

   FETCH NEXT FROM TableCursor INTO @Table, @tname, @sname
   WHILE @@FETCH_STATUS = 0   
   BEGIN   

       IF (@@MICROSOFTVERSION / POWER(2, 24) >= 9)
		   BEGIN
			
			   --SET @cmd = 'DBCC CHECKIDENT (''' + @tname + ''', RESEED, 100000)'
			   --EXEC (@cmd)

			   SELECT @Database, @Table
		
			   SET @cmd = 'DBCC CHECKTABLE("' + @Database  + '.' + @sname + '.' +  @tname + '",REPAIR_ALLOW_DATA_LOSS)'
			   EXEC (@cmd)
				
			   SET @cmd = 'DBCC CLEANTABLE(' + @Database + ',"'  + @sname + '.' + @tname + '")'
			   EXEC (@cmd)
   	
		   END
       ELSE
		   BEGIN
			   SET @cmd = 'DBCC CHECKTABLE([' + @Table + '],[' + @fillfactor + '],REPAIR_ALLOW_DATA_LOSS)' 
			   EXEC (@cmd)
		   END
       FETCH NEXT FROM TableCursor INTO @Table, @tname, @sname		   
   END   

   CLOSE TableCursor   
   DEALLOCATE TableCursor 

   SET @cmd = 'ALTER DATABASE ' + @Database + ' SET MULTI_USER'
   EXEC (@cmd)
   
   FETCH NEXT FROM DatabaseCursor INTO @Database  
END
--drop table #dblist
CLOSE DatabaseCursor   
DEALLOCATE DatabaseCursor 

