USE tempdbIF OBJECT_ID('tempdb...#SpaceDB', N'U') IS NOT NULL
  DROP TABLE #SpaceDBELSE	BEGIN
		CREATE TABLE #SpaceDB ([Database Name]	VARCHAR(50),		[file_id]	VARCHAR(5),		[Logical Name]	VARCHAR(50),		[physical_name]	VARCHAR(150),		[type_desc]	VARCHAR(5),		[state_desc]	VARCHAR(10),		[Total Size in MB]	VARCHAR(10),		[Space Used in MB]	VARCHAR(10),		[Free Space in MB]	VARCHAR(10),		[Total Size in GB]	VARCHAR(10),		[Max Size in GB]VARCHAR(10))
	END



EXEC sys.sp_MSforeachdb 
'
use [?]
INSERT INTO #SpaceDB
SELECT DB_NAME([database_id]) AS [Database Name]
       ,[file_id]
       ,name AS [Logical Name]
       ,physical_name
       ,type_desc
       ,state_desc
       ,CONVERT(BIGINT, size / 128.0) AS [Total Size in MB]
       ,CONVERT(BIGINT, FILEPROPERTY(NAME, ''SpaceUsed'') / 128.0) AS [Space Used in MB]
       ,CONVERT(BIGINT, size / 128.0) - CONVERT(BIGINT, FILEPROPERTY(NAME, ''SpaceUsed'') / 128.0) AS [Free Space in MB]
       ,CONVERT(DECIMAL(18, 2), size / 131072.0) AS [Total Size in GB]
       ,CASE WHEN max_size = -1 THEN -1
             ELSE CONVERT(DECIMAL(18, 2), max_size / 131072.0)
        END AS [Max Size in GB]
    FROM sys.master_files WITH ( NOLOCK )
    WHERE DB_NAME([database_id]) = ''?''
    ORDER BY DB_NAME([database_id])
    OPTION ( RECOMPILE );
    '
SELECT     *,(CAST([Total Size in MB] AS NUMERIC)) as Size
			,(CAST([Space Used in MB] AS NUMERIC)/CAST([Total Size in MB] AS NUMERIC)) AS 'Percentage Used'
			,(CAST([Free Space in MB] AS NUMERIC)/CAST([Total Size in MB] AS NUMERIC)) AS 'Percentage Available'
FROM         #SpaceDB
WHERE		CAST([Total Size in MB] AS NUMERIC) > 0 --AND type_desc = 'ROWS' 
			AND [Database Name] NOT IN ('master','msdb','tempdb','model')
--WHERE [Database Name] = 'IQSC_DataWarehouse'
ORDER BY  [Database Name],Size desc
--ORDER BY [Logical Name]

IF OBJECT_ID(N'tempdb..#SpaceDB', N'U') IS NOT NULL 
DROP TABLE #SpaceDB;
GO
