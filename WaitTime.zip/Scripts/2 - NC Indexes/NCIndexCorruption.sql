/*============================================================================
  File:     NCIndexCorruption.sql

  Summary:  This script demonstrates fixing non-clustered
			index corruption

  SQL Server Versions: 2005/2008/2008R2/2012
------------------------------------------------------------------------------
  Written by Paul S. Randal, SQLskills.com

  (c) 2013, SQLskills.com. All rights reserved.

  For more scripts and sample code, check out 
    http://www.SQLskills.com

  You may alter this code for your own *non-commercial* purposes. You may
  republish altered code as long as you include this copyright and give due
  credit, but you must obtain prior permission before blogging this code.
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

/* Setup
USE [master];
GO

-- Get the backup from
-- http://www.sqlskills.com/PastConferences.asp
-- Make sure the restore path exists...
RESTORE DATABASE [DemoNCIndex] FROM
	DISK = N'D:\SQLskills\CorruptionDemoBackups\CorruptDemoNCIndex.bak'
WITH REPLACE, STATS = 10,
MOVE N'SalesDBData' TO N'D:\SQLskills\DemoNCIndex2.mdf',
MOVE N'SalesDBLog' TO N'D:\SQLskills\DemoNCIndex_log2.ldf';
GO
*/

-- Run a CHECKDB
DBCC CHECKDB (N'DemoNCIndex')
WITH NO_INFOMSGS, ALL_ERRORMSGS;
GO


-- Is it just non-clustered indexes?
-- Scan through all the errors looking for index IDs
-- Maybe use WITH TABLERESULTS?
DBCC CHECKDB (N'DemoNCIndex')
WITH NO_INFOMSGS, ALL_ERRORMSGS, TABLERESULTS;
GO

-- If you wanted to fix them with CHECKDB, it
-- may do single row repairs or rebuild the index,
-- depending on the error.
DBCC CHECKDB (N'DemoNCIndex', REPAIR_REBUILD)
WITH NO_INFOMSGS, ALL_ERRORMSGS, TABLERESULTS;
GO













-- You need to be in SINGLE_USER mode! Just to
-- fix non-clustered indexes.
--
-- That doesn't make sense. Just rebuild them
-- manually and keep the database online. Try an
-- online rebuild...
USE [DemoNCIndex]
GO
EXEC sp_HelpIndex N'Customers';
GO

ALTER INDEX [CustomerName] ON [Customers] REBUILD
WITH (ONLINE = ON);
GO

-- And check again...
DBCC CHECKDB (N'DemoNCIndex')
WITH NO_INFOMSGS, ALL_ERRORMSGS;
GO

















-- Didn't work! Online index rebuild scans
-- the old index...
-- Offline rebuild doesn't on 2005...
ALTER INDEX [CustomerName] ON [Customers] REBUILD;
GO

DBCC CHECKDB (N'DemoNCIndex')
WITH NO_INFOMSGS, ALL_ERRORMSGS;
GO

-- But on 2008+ you may have to drop and recreate
-- the index (or use repair to do it).
USE [DemoNCIndex];
GO

-- Force locks to be held which should prevent
-- constraint violations
BEGIN TRAN
GO
ALTER INDEX [CustomerName] ON [Customers] DISABLE;
ALTER INDEX [CustomerName] ON [Customers] REBUILD;
GO
COMMIT TRAN;
GO

DBCC CHECKDB (N'DemoNCIndex')
WITH NO_INFOMSGS, ALL_ERRORMSGS;
GO