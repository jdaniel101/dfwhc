/*============================================================================
  File:     FatalErrors.sql

  Summary:  This script shows some fatal (to CHECKDB) corruptions

  SQL Server Versions: 2005/2008/2008R2
------------------------------------------------------------------------------
  Written by Paul S. Randal, SQLskills.com

  (c) 2013, SQLskills.com. All rights reserved.

  For more scripts and sample code, check out 
    http://www.SQLskills.com

  You may alter this code for your own *non-commercial* purposes. You may
  republish altered code as long as you include this copyright and give due
  credit, but you must obtain prior permission before blogging this code.
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/

/* Setup
USE master;
GO

-- Make sure the restore path exists...
RESTORE DATABASE DemoFatalCorruption1 FROM
	DISK = 'C:\SQLskills\CorruptionDemoBackups\CorruptDemoFatalCorruption1.bak'
WITH REPLACE, STATS = 10;
GO
RESTORE DATABASE DemoFatalCorruption2 FROM
	DISK = 'C:\SQLskills\CorruptionDemoBackups\CorruptDemoFatalCorruption2.bak'
WITH REPLACE, STATS = 10;
GO
*/

USE master;
GO

-- Corrupt IAM chain for sys.syshobts
--
DBCC CHECKDB (DemoFatalCorruption1)
WITH NO_INFOMSGS, ALL_ERRORMSGS;
GO

-- Corruption found by the metadata layer
-- of the Engine

-- On 2008R2 you'll need to put the database into EMERGENCY mode after restoring
DBCC CHECKDB (DemoFatalCorruption2)
WITH NO_INFOMSGS, ALL_ERRORMSGS;
GO
