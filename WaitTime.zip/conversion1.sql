INSERT INTO [Test].[dbo].[UHS_term_final]
           ([name_last]
           ,[name_first]
           ,[name_middle]
           ,[name_suffix]
           ,[ssn]
           ,[address]
           ,[city]
           ,[state]
           ,[zip]
           ,[dob_month]
           ,[dob_day]
           ,[dob_year]
           ,[gender]
           ,[package]
           ,[emp_company_name]
           ,[emp_position]
           ,[emp_income_type]
           ,[emp_income]
           ,[emp_start_date]
           ,[emp_end_date]
           ,[emp_reason_for_leaving]
           ,[emp_comments]
           ,[employment_verification])
SELECT t.*
from UHS_terms_072715 t INNER JOIN UHS_term_final f ON t.ssn = f.ssn
where  t.ssn not in (select ssn from UHS_term_final)

[UHS_term_final].ssn is null AND t.name_last = [UHS_term_final].name_last AND t.name_first = [UHS_term_final].name_first

UPDATE [Test].[dbo].[UHS_term_final]
   SET [name_last] = t.name_last
      ,[name_first] = t.name_first
      ,[name_middle] = t.name_middle
      ,[name_suffix] = t.name_suffix
      ,[ssn] = CAST(t.ssn as float)
      ,[address] = t.address
      ,[city] = t.city
      ,[state] = t.state
      ,[zip] = t.zip
      ,[dob_month] = t.dob_month
      ,[dob_day] = t.dob_day
      ,[dob_year] = t.dob_year
      ,[gender] = t.gender
      ,[package] = t.package
      ,[emp_company_name] = t.emp_company_name
      ,[emp_position] = t.emp_position
      ,[emp_income_type] = t.emp_income_type
      ,[emp_income] = t.emp_income
      ,[emp_start_date] = t.emp_start_date
      ,[emp_end_date] = t.emp_end_date
      ,[emp_reason_for_leaving] = t.emp_reason_for_leaving
      ,[emp_comments] = t.emp_comments
      ,[employment_verification] = t.employment_verification
from UHS_terms_092715 t inner join UHS_term_final f on CAST(t.ssn as float) = f.ssn
--where [UHS_term_final].ssn is null AND t.name_last = [UHS_term_final].name_last AND t.name_first = [UHS_term_final].name_first
--where [UHS_term_final].ssn in (select ssn from UHS_term_final)

