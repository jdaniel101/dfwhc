DECLARE @name		VARCHAR(50)		-- database name  
DECLARE @path		VARCHAR(256)	-- path for backup files  
DECLARE @fileName	VARCHAR(256)	-- filename for TRN backup
DECLARE @path1		VARCHAR(256)	-- path for log backup files  
DECLARE @fileName1	VARCHAR(256)	-- filename for Log backup
DECLARE @diffname	VARCHAR(256)	-- differential name
DECLARE @fileDate	VARCHAR(20)		-- used for file name

-- specify database backup directory
SET @path = '\\dfwhc-share\B\SQLBackups\SharePoint2013_Backups\'  

-- specify database backup directory
SET @path1 = 'E:\SQLLOGS\'  

 
-- specify filename format
SELECT @fileDate = CONVERT(VARCHAR(20),GETDATE(),112) 

 
DECLARE db_cursor CURSOR FOR  
SELECT DBName 
FROM [DBBackups].[dbo].[BackupDB]
WHERE [Backup] = '1' and Batch = '3'
ORDER BY 1 

OPEN db_cursor   
FETCH NEXT FROM db_cursor INTO @name   


WHILE @@FETCH_STATUS = 0   
BEGIN   
       SET @fileName = @path + @name + '_' + @fileDate + '.TRN'
       
       BACKUP DATABASE @name TO DISK = @fileName
       WITH DIFFERENTIAL, NOFORMAT, NOINIT, NAME = @name, NOREWIND, NOUNLOAD

       SET @fileName1 = @path1 + @name + '.LOG'
       
       BACKUP LOG @name TO DISK = @fileName1  
       WITH NOFORMAT, NOINIT, NAME = @name, NOREWIND, NOUNLOAD

       FETCH NEXT FROM db_cursor INTO @name   
END   

 
CLOSE db_cursor   
DEALLOCATE db_cursor