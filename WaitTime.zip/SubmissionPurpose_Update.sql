update A
set SubmissionPurpose = b.SubmissionPurpose
from THCIC_PUDF_Purna a join IQSC_DataWarehouse..DimBillType b
on a.type_of_bill = b.billtypecode

update b
set b.Submission_Purpose=SubmissionPurpose
from THCIC_PUDF_Purna a join  dbo.THCIC_PUDF_Charges_Purna b
on a.RECORD_ID = b.RECORD_ID
 /*
 
  begin tran
  update   th
  set th.[DI_Part]= dh.DIPart
  from [THCIC].[dbo].[THCIC_PUDF] TH
  LEFT JOIN IQSC_DataWarehouse.dbo.DimHospital dh
  ON th.THCIC_ID = dh.t_THCIC_Hospital_ID
  
  WHERE th.[DI_Part] IS NULL
  AND dh.DIPart = 1
  AND dh.IsActive = 1

 update   th
  set th.[DI_Part]= 0
  from [THCIC].[dbo].[THCIC_PUDF] TH
  where th.[DI_Part] is null
  
Commit

*/

