-- Tables Unused

SELECT     s.name, t.name AS Expr1
FROM         sys.tables AS t LEFT OUTER JOIN
                      sys.schemas AS s ON t.schema_id = s.schema_id
WHERE     (t.parent_object_id = 0) AND (t.name NOT IN
                          (SELECT DISTINCT TableName
                            FROM          (SELECT     OBJECT_NAME(ius.object_id) AS TableName
                                                    FROM          sys.dm_db_index_usage_stats AS ius INNER JOIN
                                                                           sys.indexes AS si ON ius.object_id = si.object_id AND ius.index_id = si.index_id
                                                    WHERE      (ius.database_id = DB_ID())) AS u))
ORDER BY s.name, Expr1
 
-- Views Unused

SELECT     s.name, t.name AS Expr1
FROM         sys.views AS t LEFT OUTER JOIN
                      sys.schemas AS s ON t.schema_id = s.schema_id
WHERE     (t.parent_object_id = 0) AND (t.name NOT IN
                          (SELECT DISTINCT TableName
                            FROM          (SELECT     OBJECT_NAME(ius.object_id) AS TableName
                                                    FROM          sys.dm_db_index_usage_stats AS ius INNER JOIN
                                                                           sys.indexes AS si ON ius.object_id = si.object_id AND ius.index_id = si.index_id
                                                    WHERE      (ius.database_id = DB_ID())) AS u))
ORDER BY s.name, Expr1