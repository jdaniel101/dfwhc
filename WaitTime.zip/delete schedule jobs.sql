USE msdb
GO

select * 
from dbo.sysschedules
where schedule_id in (53,54,57)
--where name in ('Backup','UpdateStats','ReIndex')


select *
from dbo.sysjobschedules
where schedule_id in (53,54,57)

update dbo.sysjobschedules
set next_run_date = '20150826'--,next_run_time='50000'
where schedule_id in (53)


select *
from dbo.sysmaintplan_subplans
where subplan_id in ('EA399089-5549-470B-99AB-A0E70A52EDDD'),'0387FA57-38DB-44E6-9D7C-5DB0502B16A6','A714D111-29F3-41AE-8C33-D9F9409C4611')

select *
from dbo.sysmaintplan_log
where subplan_id in ('7F0AD793-AB4A-4F0E-AB80-6FDEF5400860')'BA18BE25-43C3-4C88-95C6-445CFFCDD7F2','0387FA57-38DB-44E6-9D7C-5DB0502B16A6','A714D111-29F3-41AE-8C33-D9F9409C4611')

select * from dbo.sysschedules
where schedule_id = 50
where name in ('Backup','UpdateStats','ReIndex')

EXEC sp_delete_schedule @schedule_name = 'Daily DBBackup', @force_delete=1;