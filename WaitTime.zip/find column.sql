select *
from (select t.name as tname, c.name as cname 
from sys.tables t INNER JOIN sys.columns c ON t.object_id = c.object_id) r
where r.cname like '%HealthCareClaimDataFileID%' 
