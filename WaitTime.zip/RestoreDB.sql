SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Johnson P. Daniel
-- Create date: October 28, 2015
-- Description:	RestoreDB restores to 3 level of to current backup.
-- 'T' - Last (T)ransactional
-- 'D' - Last (D)ifferential Hour
-- 'F' - Last (F)ull Backup 	
--  - Example			
--          PRINT dbo.RestoreDB 'T'
--          PRINT dbo.RestoreDB 'D'
--          PRINT dbo.RestoreDB 'F'
-- =============================================

ALTER PROCEDURE RestoreDB 
	@choice CHAR(1)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON 

	-- 1 - Variable declaration 
	DECLARE  @filepath   		VARCHAR(255),
			 @cmd        		VARCHAR(255),
			 @rc         		INT,
			 @dbName	 		VARCHAR(255),
			 @lastFullBackup 	NVARCHAR(500),
			 @backupPath 		NVARCHAR(500),
			 @lastDiffBackup 	NVARCHAR(500),
			 @lastTrnsBackup 	NVARCHAR(500),
			 @tranOut  			NVARCHAR(500)
			 
create table #temp(name varchar(255));
insert into #temp(name) values ('DBBackups')
insert into #temp(name) values ('DFWHC_AppManagement')
insert into #temp(name) values ('DFWHC_Config_2013')
insert into #temp(name) values ('DFWHC_Content_Admin')
insert into #temp(name) values ('DFWHC_Content_External')
insert into #temp(name) values ('DFWHC_Content_Intranet')
insert into #temp(name) values ('DFWHC_Content_IT')
insert into #temp(name) values ('DFWHC_Content_MySites')
insert into #temp(name) values ('DFWHC_Content_Portal')
insert into #temp(name) values ('DFWHC_Content_SFT')
insert into #temp(name) values ('DFWHC_MetaData')
insert into #temp(name) values ('DFWHC_Profile')
insert into #temp(name) values ('DFWHC_Search')
insert into #temp(name) values ('DFWHC_Search_AnalyticsReportingStore')
insert into #temp(name) values ('DFWHC_Search_CrawlStore')
insert into #temp(name) values ('DFWHC_Search_LinksStore')
insert into #temp(name) values ('DFWHC_SecureStore')
insert into #temp(name) values ('DFWHC_SessionState')
insert into #temp(name) values ('DFWHC_Social')
insert into #temp(name) values ('DFWHC_StateService')
insert into #temp(name) values ('DFWHC_SubscriptionSettings')
insert into #temp(name) values ('DFWHC_Sync')
insert into #temp(name) values ('DFWHC_UsageAndHealth')
insert into #temp(name) values ('GP1_Content_Reporting');
  
	-- Declare Cursor to go through list of DBs
	DECLARE DatabaseCursor CURSOR FOR  
	SELECT name
	FROM #temp

	OPEN DatabaseCursor
	FETCH NEXT FROM DatabaseCursor INTO @dbName  

	-- Initialize Variables
	select   @filepath = 'M:\'         
	select   @cmd      = 'dir /b /s ' + @filepath 
	--set @dbName = 'master'

	CREATE TABLE #output (output VARCHAR(255) null)
	INSERT #output EXEC @rc = master..xp_cmdshell @cmd

	WHILE @@FETCH_STATUS = 0  
	BEGIN  
	
		IF @choice IN ('F','D','T')
		BEGIN
			-- 4 - Find latest full backup 
			SELECT @lastFullBackup = MAX(output) FROM #output WHERE output LIKE '%.BAK' AND output LIKE @filepath + @dbName + '%' 

			--SET @cmd = 'ALTER DATABASE ' + @dbName + ' SET SINGLE_USER' 
			--PRINT @cmd 

			SET @cmd = 'RESTORE DATABASE ' + @dbName + ' FROM DISK = N'''  
				   + @lastFullBackup + ''' WITH FILE = 1, NOUNLOAD,  REPLACE,  STATS = 10' 
			PRINT @cmd 

			--SET @cmd = 'ALTER DATABASE ' + @dbName + ' SET MULTI_USER' 
			--EXEC @cmd 
		END
		
		IF @choice IN ('D','T')
		BEGIN
			-- Find latest diff backup 
			SELECT @lastDiffBackup = MAX(output) FROM #output WHERE output LIKE '%.DIF' AND output LIKE 'M:\Differential\' + @dbName + '%'

			SET @cmd = 'RESTORE DATABASE ' + @dbName + ' FROM DISK = ''' 
				   + @lastDiffBackup + ''' WITH NORECOVERY' 
			PRINT @cmd 
		END
		
		IF @choice = 'T'
		BEGIN
			-- Check for log backups 
			  SELECT @tranOut = MAX(output) FROM #output WHERE output LIKE '%.trn' AND output LIKE 'M:\SQLTRNS\' + @dbName + '%'

			  SET @cmd = 'RESTORE LOG ' + @dbName + ' FROM DISK = '''  
				   + @tranOut + ''' WITH NORECOVERY' 
			  PRINT @cmd 
		
		END 
		-- 6 - put database in a useable state 
		--SET @cmd = 'RESTORE DATABASE ' + @dbName + ' WITH RECOVERY' 
		--PRINT @cmd 
		FETCH NEXT FROM DatabaseCursor INTO @dbName  
	END  
	CLOSE DatabaseCursor   
	DEALLOCATE DatabaseCursor 
		  
	DROP TABLE #output

END
GO