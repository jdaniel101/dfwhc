
Level 3 Full + Diff + Trn	- Last Tranaction
Level 2 Full + Diff			- Last Hour
Level 1 Full				- Last Day

Case WHEN @choice = 'T' THEN @choice = 3
	 WHEN @choice = 'D' THEN @choice = 2
	 WHEN @choice = 'F' THEN @choice = 1
	 ELSE
		@choice = 1
	END
	
	IF choice > 3 Last Transaction
	