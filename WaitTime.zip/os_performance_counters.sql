SELECT     CntrVal.object_name, CntrVal.counter_name, CntrVal.instance_name, CASE WHEN CntrBase.cntr_value = 0 THEN 0 ELSE CAST(CntrVal.cntr_value AS FLOAT) 
                      / CntrBase.cntr_value END AS CounterValueRatio
FROM         sys.dm_os_performance_counters AS CntrVal INNER JOIN
                      sys.dm_os_performance_counters AS CntrBase ON CntrVal.object_name = CntrBase.object_name AND CntrVal.instance_name = CntrBase.instance_name AND 
                      (RTRIM(CntrVal.counter_name) + N' Base' = CntrBase.counter_name OR
                      CntrVal.counter_name = N'Worktables From Cache Ratio' AND CntrBase.counter_name = N'Worktables From Cache Base')
WHERE     (CntrVal.cntr_type = 537003264)

----------------------------------------
SELECT     CntrVal.object_name, CntrVal.counter_name, AVG(CASE WHEN CntrBase.cntr_value = 0 THEN 0 ELSE CAST(CntrVal.cntr_value AS FLOAT) / CntrBase.cntr_value END) 
                      AS CounterValueRatio
FROM         sys.dm_os_performance_counters AS CntrVal INNER JOIN
                      sys.dm_os_performance_counters AS CntrBase ON CntrVal.object_name = CntrBase.object_name AND CntrVal.instance_name = CntrBase.instance_name AND 
                      (RTRIM(CntrVal.counter_name) + N' Base' = CntrBase.counter_name OR
                      CntrVal.counter_name = N'Worktables From Cache Ratio' AND CntrBase.counter_name = N'Worktables From Cache Base')
WHERE     (CntrVal.cntr_type = 537003264) AND (CntrVal.counter_name LIKE '%Cache Hit Ratio%')
GROUP BY CntrVal.object_name, CntrVal.counter_name

SELECT object_name, counter_name, cntr_value 
FROM sys.dm_os_performance_counters
WHERE [object_name] LIKE '%Buffer Manager%'AND [counter_name] = 'Buffer cache hit ratio' 
-- See more at: http://www.sqlshack.com/sql-server-memory-performance-metrics-part-4-buffer-cache-hit-ratio-page-life-expectancy/#sthash.4KJ7zoyw.dpuf

SELECT object_name, counter_name, cntr_value
FROM sys.dm_os_performance_counters
WHERE [object_name] LIKE '%Buffer Manager%'AND [counter_name] = 'Page life expectancy' 
-- See more at: http://www.sqlshack.com/sql-server-memory-performance-metrics-part-4-buffer-cache-hit-ratio-page-life-expectancy/#sthash.4KJ7zoyw.dpuf