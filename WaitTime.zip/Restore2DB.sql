EXEC xp_cmdshell 'net use O: /delete'  -- Disconnected Network Drive (M:)

-- Connected Network Drive (M:)
EXEC xp_cmdshell 'net use O: "\\dfwf-share\SQL Backups\HV10\THCIC" Welcome9999! /USER:DFWHC\Joseph-Johnson /PERSISTENT:no'

RESTORE FILELISTONLY 
FROM DISK = '\\dfwf-share\SQL Backups\HV10\THCIC\THCIC_backup_2015_11_13_220005_1524240.bak'

RESTORE DATABASE [THCIC2] FROM DISK = N'O:\THCIC_backup_2015_11_13_220005_1524240.bak' 
WITH
MOVE 'THCIC2' TO 'O:\THCIC2.mdf', 
MOVE 'THCIC2_Log' TO 'O:\THCIC2_Log.ldf', 
REPLACE

RESTORE DATABASE [THCIC] FROM DISK = N'O:\THCIC_backup_2015_11_13_220005_1524240.bak' 
WITH
MOVE 'THCIC' TO 'O:\THCIC.mdf', 
MOVE 'THCIC_Log' TO 'O:\THCIC_Log.ldf', 
RECOVERY, REPLACE, STATS = 10


EXEC xp_cmdshell 'net use O: /delete'  -- Disconnected Network Drive (M:)

-- Connected Network Drive (M:)
EXEC xp_cmdshell 'net use O: "\\dfwf-share\SQL Backups\HV10\THCIC" Welcome9999! /USER:DFWHC\Joseph-Johnson /PERSISTENT:no'

RESTORE FILELISTONLY 
FROM DISK = '\\dfwf-share\SQL Backups\HV10\THCIC\THCIC_backup_2015_11_13_220005_1524240.bak'

RESTORE DATABASE [THCIC2] FROM DISK = N'O:\THCIC_backup_2015_11_13_220005_1524240.bak' 
WITH
MOVE 'THCIC' TO 'O:\THCIC.mdf', 
MOVE 'THCIC_1' TO 'O:\THCIC_1.ndf', 
MOVE 'THCIC_Log' TO 'O:\THCIC_1.ldf', 
REPLACE