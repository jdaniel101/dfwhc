UPDATE A
SET SUBMISSIONPURPOSE = B.SUBMISSIONPURPOSE
FROM THCIC_PUDF_PURNA A JOIN IQSC_DATAWAREHOUSE..DIMBILLTYPE B
ON A.TYPE_OF_BILL = B.BILLTYPECODE

UPDATE B
SET B.SUBMISSION_PURPOSE=SUBMISSIONPURPOSE
FROM THCIC_PUDF_PURNA A JOIN  DBO.THCIC_PUDF_CHARGES_PURNA B
ON A.RECORD_ID = B.RECORD_ID
 /*
 
  begin tran
  update   th
  set th.[DI_Part]= dh.DIPart
  from [THCIC].[dbo].[THCIC_PUDF] TH
  LEFT JOIN IQSC_DataWarehouse.dbo.DimHospital dh
  ON th.THCIC_ID = dh.t_THCIC_Hospital_ID
  
  WHERE th.[DI_Part] IS NULL
  AND dh.DIPart = 1
  AND dh.IsActive = 1

 update   th
  set th.[DI_Part]= 0
  from [THCIC].[dbo].[THCIC_PUDF] TH
  where th.[DI_Part] is null
  
Commit

*/

 