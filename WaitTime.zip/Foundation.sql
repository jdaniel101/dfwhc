USE InventoryDB
GO

SELECT [Server Name]
      ,[Server Type]
      ,[Prod/Test]
      ,[Company]
      ,[Cluster Name]
      ,[Location]
      --,[Operating System]
      ,[IP Address]
      --,[Product Type]
      --,[Serial Number]
      --,[Care Pack ID]
      --,[Product Number]
      ,[SQL Server]
      ,[Comments]
      ,[Status]
  FROM [InventoryDB].[dbo].[DFWHCServers]
  WHERE Status is not null AND Company in ('Community','Foundation') AND [SQL Server] LIKE '%SQL%' AND
		Status NOT IN ('End of Life','Retired','Offline')
  ORDER BY Company DESC
  
  --[Prod/Test] like '%Production%' AND [Company] = 'Foundation'
  
  --EXEC sp_updatestats;
  
  /****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP 1000 [Server Name]
      ,[Server Type]
      ,[Prod/Test]
      ,[Company]
      ,[Cluster Name]
      ,[Location]
      ,[Operating System]
      ,[IP Address]
      ,[Product Type]
      ,[Serial Number]
      ,[Care Pack ID]
      ,[Product Number]
      ,[SQL Server]
      ,[Comments]
      ,[Status]
  FROM [InventoryDB].[dbo].[DFWHCServers]
  WHERE [Prod/Test] like '%Production%' AND [Company] = 'Foundation'
  
  --Update [DFWHCServers]
  --SET 
  ----Comments = '4R 16C HD',
  --Status = 'Offline'
  --WHERE [IP Address] IN ('10.2.60.240','10.2.60.241','10.2.60.242')