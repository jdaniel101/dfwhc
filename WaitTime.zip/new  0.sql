SELECT DISTINCT Q.QueueStatus_Key, C.DischargeQuarter
FROM         DimQueueStatus AS Q INNER JOIN
                      DimClaim AS C ON C.QueueStatus_Key = Q.QueueStatus_Key
WHERE     (Q.ProcessedToDW = 1) AND (Q.QueuedToDRG = 0) AND (C.SubmissionPurpose = 'I') AND (C.ClaimStatusCode NOT IN ('V', 'X'))
ORDER BY Q.QueueStatus_Key, C.DischargeQuarter


SELECT    [QueuedToDRG], [QueuedToDRGDate], [ProcessedDRG], [ProcessedDRGDate]
FROM         DimQueueStatus
WHERE     (QueueStatus_Key IN (9132, 9277, 9683, 10043, 9992, 10457)) AND (Batch_ID IN (2324, 2357, 2445, 2517, 2508, 2599))


--UPDATE [IQSC_DataWarehouse].[dbo].[DimQueueStatus]
--SET [QueuedToDRG] = 0, [QueuedToDRGDate] = '', [ProcessedDRG] = 0, [ProcessedDRGDate] = '' 
--WHERE QueueStatus_Key IN (9132,9277,9683,10043,9992,10457) 
-- AND Batch_ID IN (2324,2357,2445,2517,2508,2599)
 
 
SELECT     dq.HospitalClaimDataFile_Filename, COUNT(dc.Claim_Key) AS Cnt
FROM         DimClaim AS dc LEFT OUTER JOIN
                      DimQueueStatus AS dq ON dc.QueueStatus_Key = dq.QueueStatus_Key
WHERE     (dq.HospitalClaimDataFile_Filename LIKE '%2014_Q4_I%')
GROUP BY dq.HospitalClaimDataFile_Filename
ORDER BY dq.HospitalClaimDataFile_Filename
COMPUTE SUM(COUNT(dc.Claim_Key))


SELECT     dq.HospitalClaimDataFile_Filename, COUNT(dc.Claim_Key) AS Cnt
FROM         DimClaim AS dc LEFT OUTER JOIN
                      DimQueueStatus AS dq ON dc.QueueStatus_Key = dq.QueueStatus_Key
WHERE     (dq.HospitalClaimDataFile_Filename LIKE '%2014_Q4_O%')
GROUP BY dq.HospitalClaimDataFile_Filename
ORDER BY dq.HospitalClaimDataFile_Filename
COMPUTE SUM(COUNT(dc.Claim_Key))

---- Inpatient  2014 - total:  172168
---- Outpatient 2014 - total: 1217494

SELECT QueueStatus_Key, Batch_ID, HospitalClaimDataFile_ID, SubmissionPurpose, DQA_Claim_Count, THCIC_Hospital_ID,Hospital,QueuedToDRG,QueuedToDRGDate,ProcessedDRG,ProcessedDRGDate
FROM IQSC_DataWarehouse.dbo.DimQueueStatus
WHERE QueueStatus_Key IN (10649,10738)