ALTER DATABASE HHRA SET SINGLE_USER
--DBCC CHECKDB ('HHRA') WITH NO_INFOMSGS
--DBCC CHECKDB ('HHRA') WITH PHYSICAL_ONLY

DBCC CHECKDB ('HHRA', REPAIR_ALLOW_DATA_LOSS)
DBCC CHECKDB ('HHRA') WITH TABLOCK, ALL_ERRORMSGS, NO_INFOMSGS;

DBCC CHECKCONSTRAINTS
ALTER DATABASE HHRA SET MULTI_USER


DBCC PAGE(13,1,14136,2)

XLVerAct
CHG_PM01
SY02500
SVC30231

------------------------------------------------------

USE master
GO

DECLARE @Database VARCHAR(255)
DECLARE @cmd NVARCHAR(500)  
DECLARE @Table VARCHAR(255)  

DECLARE DatabaseCursor CURSOR FOR  
SELECT name FROM master.dbo.sysdatabases   
WHERE name  IN ('HHRA')
ORDER BY name  

OPEN DatabaseCursor  

FETCH NEXT FROM DatabaseCursor INTO @Database  
WHILE @@FETCH_STATUS = 0  
BEGIN

	SET @cmd = 'USE ' + @Database
	EXEC (@cmd) 
   
	SET @cmd = 'DECLARE TableCursor CURSOR FOR  
	SELECT name FROM ' + @Database + '.sys.tables ORDER BY name desc'
	EXEC (@cmd)
	
	OPEN TableCursor  

	FETCH NEXT FROM TableCursor INTO @Table  
	WHILE @@FETCH_STATUS = 0  
	BEGIN
		SELECT @Database + '.dbo.' + @Table
		SET @cmd = 'DBCC CHECKTABLE(' + @Database + '.dbo.' + @Table + ')'
		EXEC (@cmd)
		
		FETCH NEXT FROM TableCursor INTO @Table  
	END  
	CLOSE TableCursor 
	  
	DEALLOCATE TableCursor 
FETCH NEXT FROM DatabaseCursor INTO @Database  
END  

CLOSE DatabaseCursor   
DEALLOCATE DatabaseCursor 

-----------------------------------------------------------------

WITH Waits AS
 (SELECT wait_type, wait_time_ms / 1000. AS wait_time_s,
 100. * wait_time_ms / SUM(wait_time_ms) OVER() AS pct,
 ROW_NUMBER() OVER(ORDER BY wait_time_ms DESC) AS rn
 FROM sys.dm_os_wait_stats
 WHERE wait_type NOT IN ('CLR_SEMAPHORE','LAZYWRITER_SLEEP','RESOURCE_QUEUE','SLEEP_TASK',
 'SLEEP_SYSTEMTASK','SQLTRACE_BUFFER_FLUSH','WAITFOR', 'LOGMGR_QUEUE','CHECKPOINT_QUEUE',
 'REQUEST_FOR_DEADLOCK_SEARCH','XE_TIMER_EVENT','BROKER_TO_FLUSH','BROKER_TASK_STOP','CLR_MANUAL_EVENT',
 'CLR_AUTO_EVENT','DISPATCHER_QUEUE_SEMAPHORE', 'FT_IFTS_SCHEDULER_IDLE_WAIT',
 'XE_DISPATCHER_WAIT', 'XE_DISPATCHER_JOIN', 'SQLTRACE_INCREMENTAL_FLUSH_SLEEP',
 'ONDEMAND_TASK_QUEUE', 'BROKER_EVENTHANDLER', 'SLEEP_BPOOL_FLUSH'))
 SELECT W1.wait_type,
 CAST(W1.wait_time_s AS DECIMAL(12, 2)) AS wait_time_s,
 CAST(W1.pct AS DECIMAL(12, 2)) AS pct,
 CAST(SUM(W2.pct) AS DECIMAL(12, 2)) AS running_pct
 FROM Waits AS W1
 INNER JOIN Waits AS W2
 ON W2.rn <= W1.rn
 GROUP BY W1.rn, W1.wait_type, W1.wait_time_s, W1.pct
 HAVING SUM(W2.pct) - W1.pct < 99 OPTION (RECOMPILE); -- percentage threshold