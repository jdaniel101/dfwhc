select * from sys.indexes

--select * from sys.dm_db_index_physical_stats
SELECT * FROM sys.dm_db_index_physical_stats(DB_ID(N'IQSC_DataWarehouse'), NULL, NULL, NULL , 'LIMITED');

select * from sys.dm_db_index_usage_stats

select * from sys.dm_db_index_operational_stats(DB_ID(N'IQSC_DataWarehouse'), NULL, NULL, NULL , 'LIMITED');

select * from sys.dm_os_performance_counters 