USE IQSC_DataWarehouse 

DECLARE @TableName varchar(255)
DECLARE @RowCounts int

DECLARE TableCursor CURSOR FOR 
SELECT     t.name AS TableName, p.rows AS RowCounts--, s.name AS SchemaName, , SUM(a.total_pages) * 8 AS TotalSpaceKB, SUM(a.used_pages) * 8 AS UsedSpaceKB, 
                      --(SUM(a.total_pages) - SUM(a.used_pages)) * 8 AS UnusedSpaceKB
FROM         sys.tables AS t INNER JOIN
                      sys.indexes AS i ON t.object_id = i.object_id INNER JOIN
                      sys.partitions AS p ON i.object_id = p.object_id AND i.index_id = p.index_id INNER JOIN
                      sys.allocation_units AS a ON p.partition_id = a.container_id LEFT OUTER JOIN
                      sys.schemas AS s ON t.schema_id = s.schema_id
WHERE     (t.name NOT LIKE 'dt%') AND (t.is_ms_shipped = 0) AND (i.object_id > 255) AND (p.rows > 0)
GROUP BY t.name, s.name, p.rows
ORDER BY RowCounts DESC

OPEN TableCursor 

FETCH NEXT FROM TableCursor INTO @TableName 
WHILE @@FETCH_STATUS = 0 
BEGIN 
DBCC DBREINDEX(@TableName,' ',90) 
FETCH NEXT FROM TableCursor INTO @TableName 
END 

CLOSE TableCursor 
DEALLOCATE TableCursor

 
