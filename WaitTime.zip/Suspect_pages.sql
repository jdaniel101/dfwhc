USE msdb
GO


select * from dbo.suspect_pages
select distinct database_id from dbo.suspect_pages
order by last_update_date

--database_id = 8

select * from sys.databases
where database_id in (13)


SELECT 'DBCC TRACEON(3604) DBCC PAGE(' + CAST(database_id AS VARCHAR(3)) + ','
					+ CAST(file_id AS VARCHAR(3))  + ','
					+ CAST(page_id AS VARCHAR(5))  + ',0) DBCC TRACEOFF(3604) '				
FROM [msdb].[dbo].[suspect_pages]; 
GO

EXEC sp_resetstus 'HHRA'
ALTER DATABASE HHRA SET EMERGENCY
DBCC CHECKDB('HHRA')
ALTER DATABASE HHRA SET SINGLE_USER WITH ROLLBACK IMMEDIATE
DBCC CheckDB ('HHRA', REPAIR_ALLOW_DATA_LOSS)
ALTER DATABASE HHRA SET MULTI_USER