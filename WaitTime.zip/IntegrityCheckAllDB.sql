DECLARE @name VARCHAR(50) -- database name  

DECLARE db_cursor CURSOR FOR  
SELECT name 
FROM master.dbo.sysdatabases 
WHERE name NOT IN ('master','model','msdb','tempdb')  

OPEN db_cursor   
FETCH NEXT FROM db_cursor INTO @name   

WHILE @@FETCH_STATUS = 0   
BEGIN   
		EXECUTE dbo.DatabaseIntegrityCheck
			 @Databases = @name,
			 @CheckCommands = 'CHECKDB',
			 @PhysicalOnly = 'Y',
			 @ExtendedLogicalChecks = 'Y'

       FETCH NEXT FROM db_cursor INTO @name   
END   

CLOSE db_cursor   
DEALLOCATE db_cursor 