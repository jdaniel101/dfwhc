USE DBA_Maintenance
GO

----------------------------------------

--SELECT 'Start' --Give me a rowcount of 1
--WHILE @@ROWCOUNT > 0
--BEGIN
--	DELETE TOP (100000)
--	FROM OSPerfCounters
--	WHERE dateadded < (GetDate() - 400)
--END

SELECT datename(dw,cast(DateAdded as date)) AS 'DAY', cast(DateAdded as date) AS DATE1, AVG(Batch_Requests_Sec) as Batch_Requests_Sec, 
		AVG(Cache_Hit_Ratio) AS Cache_Hit_Ratio, AVG(CAST(Free_Pages as bigint)) AS Free_Pages, AVG(Lazy_Writes_Sec) AS Lazy_Writes_Sec, 
		AVG(Memory_Grants_Pending) AS Memory_Grants_Pending, AVG(Deadlocks) AS Deadlocks, AVG(Page_Life_Exp) AS Page_Life_Exp, 
		AVG(Page_Lookups_Sec) AS Page_Lookups_Sec, AVG(Page_Reads_Sec) AS Page_Reads_Sec, AVG(Page_Writes_Sec) AS Page_Writes_Sec, 
		AVG(SQL_Compilations_Sec) AS SQL_Compilations_Sec, AVG(SQL_Recompilations_Sec) AS SQL_Recompilations_Sec, 
		AVG(CAST(ServerMemoryTarget_KB AS bigint)) AS ServerMemoryTarget_KB, AVG(CAST(ServerMemoryTotal_KB AS bigint)) AS ServerMemoryTotal_KB,
		AVG(Transactions_Sec) AS Transactions_Sec, AVG(Cast(Batch_Requests_Sec as numeric))/AVG(Cast(Transactions_Sec as numeric)) AS PercentperTransSec
FROM OSPerfCounters
GROUP BY cast(DateAdded as date)
ORDER BY cast(DateAdded as date)