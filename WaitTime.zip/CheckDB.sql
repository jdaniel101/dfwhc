EXEC master.sys.sp_MSforeachdb '
IF ''?'' <> ''master'' AND ''?'' <> ''model'' AND ''?'' <> ''msdb'' AND ''?'' <> ''tempdb''
BEGIN
	SELECT ''?'' 
	
	DBCC CHECKCATALOG(''?'')

	DBCC CHECKALLOC(''?'')	
	
	DBCC CHECKDB(''?'') WITH ALL_ERRORMSGS   
	
END'